ANTICIPY v6 — TWO STEPS

1. Open Terminal, paste:
       bash ~/Downloads/anticipy-v6/DAEMON-INSTALLER/install.sh
   (adjust path if you unzipped elsewhere — type Mac password when sudo asks)

2. Chrome → chrome://extensions → Developer Mode ON → "Load unpacked"
   → pick the folder named EXTENSION-LOAD-THIS-IN-CHROME
   (NOT the parent anticipy-v6 folder)

The extension card should say "Anticipy Bridge v6 — 6.0.0".
Click its icon — popup shows "daemon connected" or the exact error.
