"""Anticipy local product backend, fully integrated, continuously
listening. Modifies no frozen code.

ONE product loop, real end to end:

  onboarding   real conversational intake -> app.anticipy.onboarding
               .run_intake -> a real structured UserProfile; the
               profile people are seeded into the real anticipy_memory
               so "the boss" / "us" resolve from day one.
  listen       ALWAYS-ON. A real sounddevice InputStream captures the
               microphone continuously; a processor thread drains
               rolling windows, runs real local parakeet ASR + the
               FROZEN reasoning + proactive_day pipeline (with the real
               anticipy_memory draw armed) on each window WHILE capture
               keeps running, and never self-stops. Every window with
               speech is written to the real per-user memory via the
               Mem0-style reconcile primitive, so references resolve
               over time. No synthetic voice anywhere.
  act          on the user's explicit confirmation, the pending
               proposal's instruction is handed to the FROZEN browser
               action engine (action_handoff.make_real_action_engine
               -> DSv4SkillRunner) which really drives Chrome over CDP.
  history      the real active memory snapshot, surfaced.

Frozen code is only ever used through its existing public seams
(read-only). pipeline._MEMORY_DRAW is a designed runtime hook, set
here, not a code edit.
"""

from __future__ import annotations

import asyncio
import collections
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.parse
import urllib.request
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, Response
from pydantic import BaseModel

app = FastAPI(title="Anticipy", version="product-3")

_ALLOWED_ORIGINS = [
    "https://www.anticipy.ai",
    "https://anticipy.ai",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Handoff token round-trip endpoints (POST /api/auth/handoff/mint,
# POST /api/auth/exchange). Implementation lives in app.anticipy.handoff
# so the engine route surface stays a thin attach point.
try:
    from app.anticipy.handoff import attach_to as _attach_handoff_routes
    _attach_handoff_routes(app)
except Exception:
    pass

# Live streaming STT via Deepgram Nova-3 (WebSocket /api/stt/stream).
# Implementation lives in app.listen.stream so the route surface stays
# a thin attach point. Audit story A-007.
try:
    from app.listen.stream import attach_to as _attach_stt_stream
    _attach_stt_stream(app)
except Exception:
    pass


@app.middleware("http")
async def _private_network_headers(request: Request, call_next):
    origin = request.headers.get("origin", "")
    if request.method == "OPTIONS" and origin in _ALLOWED_ORIGINS:
        headers = {
            "Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Methods": "DELETE, GET, HEAD, OPTIONS, PATCH, POST, PUT",
            "Access-Control-Allow-Headers":
                request.headers.get("access-control-request-headers", "*"),
            "Access-Control-Max-Age": "600",
            "Access-Control-Allow-Private-Network": "true",
            "X-Anticipy-Local-Engine": "product-3",
        }
        return Response(status_code=204, headers=headers)
    response = await call_next(request)
    if request.headers.get("access-control-request-private-network"):
        response.headers["Access-Control-Allow-Private-Network"] = "true"
    response.headers["X-Anticipy-Local-Engine"] = "product-3"
    return response

_SESS: dict = {"i": 0, "transcript": [], "profile": None,
               "profile_obj": None}
USER_ID = "anticipy-user"


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except ValueError:
        return default


CDP_PORT = _env_int("ANTICIPY_CDP_PORT", 0)
LEGACY_CLONE_CDP_ENABLED = (
    os.environ.get("ANTICIPY_ENABLE_LEGACY_CLONE_CDP", "").strip() == "1"
)
CHROME_REAL_CLONE_TOKEN = "chrome-real-clone"
# Shipped default: rolling 15s windows so live microphone input reaches the
# same post-ASR path quickly enough to feel like a product, not a batch job.
WINDOW_SECONDS = float(os.environ.get("ANTICIPY_WINDOW_SECONDS", "15"))
# Real product: the always-on mic loop writes what it hears to memory
# (default "1"). The anti-cheat chain harness sets this "0": the real
# mic stays on (continuous-listening capability stays real and is
# proven separately) but its windows are NOT written to the judged
# per-scenario memory, so ambient room speech cannot contaminate the
# walled-off scenario whose ONLY judged input is the authorized
# ASR-transcript-boundary inject path.
_PROC_MEMWRITE = os.environ.get("ANTICIPY_PROC_MEMWRITE", "1") == "1"
_UPLOAD_ASR_LOCK = threading.Lock()


def _upload_asr_timeout_seconds() -> float:
    return float(max(15, min(_env_int("ANTICIPY_UPLOAD_ASR_TIMEOUT_SECONDS", 240), 900)))


def _audio_device_kind(name: str) -> str:
    low = (name or "").lower()
    if "printer" in low or "scanner" in low or "airplay" in low:
        return "unsupported"
    if "macbook" in low or "built-in" in low or "internal microphone" in low:
        return "builtin"
    if "airpods" in low or "bluetooth" in low or "beats" in low:
        return "bluetooth"
    if "blackhole" in low or "loopback" in low or "virtual" in low:
        return "virtual"
    return "other"


def _audio_source_detail(kind: str, name: str) -> str:
    low = (name or "").lower()
    if kind == "builtin":
        return "built_in_mic"
    if kind == "bluetooth":
        return "bluetooth_mic"
    if "usb" in low or "cmteck" in low:
        return "usb_mic"
    if "line" in low:
        return "line_in"
    if kind == "unsupported":
        return "unsupported_device"
    if kind == "virtual":
        return "virtual_loopback"
    return "other"


def _audio_connection_type(kind: str, name: str) -> str:
    detail = _audio_source_detail(kind, name)
    if detail == "built_in_mic":
        return "built_in"
    if detail == "bluetooth_mic":
        return "bluetooth"
    if detail == "usb_mic":
        return "usb"
    if detail == "line_in":
        return "line_in"
    if detail == "virtual_loopback":
        return "virtual"
    if detail == "unsupported_device":
        return "unsupported"
    return kind or "other"


def _audio_device_row(idx: int, d: dict, default_name: str = "") -> dict:
    name = str(d.get("name") or "")
    kind = _audio_device_kind(name)
    try:
        index = int(d.get("index", idx))
    except Exception:
        index = int(idx)
    return {
        "index": index,
        "name": name,
        "max_input_channels": int(d.get("max_input_channels") or 0),
        "default_sample_rate": float(d.get("default_samplerate") or 0.0),
        "kind": kind,
        "source_detail": _audio_source_detail(kind, name),
        "connection_type": _audio_connection_type(kind, name),
        "is_default": bool(default_name and name == default_name),
    }

# Item H root-cause fix (in-product, non-frozen). Single-instance is
# enforced by the PRODUCT via an exclusive OS advisory lock. The
# kernel releases an flock automatically when the holding process
# dies, so a crashed prior instance never wedges a new one and NO
# external pkill is ever required; a second concurrent instance
# cannot acquire the lock and deterministically refuses to start.
# This eliminates the double-uvicorn / split-empty-profile wedge at
# the product level rather than via out-of-band cleanup.
import fcntl as _fcntl
import sys as _sys
# The lock must be keyed by the PORT this server binds to. A machine can
# legitimately run more than one engine on different ports (e.g. a
# launchd-managed --server on 8731 plus the GUI app's in-process server
# on a free port). The earlier machine-wide lock blocked the GUI app
# from spawning its own server when launchd was already holding 8731,
# which manifested as a blank-white app window. Per-port is the correct
# invariant (one server per port), still kernel-released on death.
_SINGLETON_FH = None
_SINGLETON_LOCK_PATH = None


def _acquire_singleton_lock(port_str: str) -> None:
    global _SINGLETON_FH, _SINGLETON_LOCK_PATH
    if _SINGLETON_FH is not None:
        return
    _SINGLETON_LOCK_PATH = f"/tmp/anticipy_product_{port_str}.lock"
    _SINGLETON_FH = open(_SINGLETON_LOCK_PATH, "w")
    try:
        _fcntl.flock(_SINGLETON_FH, _fcntl.LOCK_EX | _fcntl.LOCK_NB)
        _SINGLETON_FH.write(str(os.getpid()))
        _SINGLETON_FH.flush()
    except OSError:
        _sys.stderr.write(
            "Anticipy: another engine instance already holds "
            f"{_SINGLETON_LOCK_PATH}; refusing to start a second instance "
            "on the same port (single-instance enforced per-port).\n")
        raise SystemExit(3)


# Acquire the lock immediately for the legacy dev / launchd flow that imports
# this module with ANTICIPY_PORT already set. The PyInstaller-bundled sidecar
# (US-013) picks a random free port in _run_sidecar() and acquires the lock
# there instead, so we skip the eager acquisition when running frozen.
# The verifier passes the actual bound port via ANTICIPY_ENGINE_PORT so its
# free-port spawn keys the lock by that port and does not collide with a
# launchd-managed instance already holding 8731.
if not getattr(_sys, "frozen", False):
    _acquire_singleton_lock(
        os.environ.get("ANTICIPY_ENGINE_PORT", "").strip()
        or os.environ.get("ANTICIPY_PORT", "").strip()
        or "8731"
    )


def _ensure_clean_gmail_compose() -> int:
    """Item H (in-product, non-frozen): before the frozen action
    engine runs, the PRODUCT itself guarantees a clean Gmail compose
    state by closing any stale compose targets in the real-clone
    Chrome via CDP. No external cleanup script: a prior aborted run
    cannot pollute this one, which also lets the frozen engine reach
    its CERTIFIED 'Draft saved' state well within the iteration
    budget instead of burning iterations on stale windows.
    """
    import json as _j
    import urllib.request as _u
    closed = 0
    try:
        tabs = _j.load(_u.urlopen(
            f"http://127.0.0.1:{CDP_PORT}/json", timeout=6))
        for t in tabs:
            if (t.get("type") == "page"
                    and "compose=" in t.get("url", "")):
                try:
                    _u.urlopen(
                        f"http://127.0.0.1:{CDP_PORT}/json/close/"
                        f"{t['id']}", timeout=6)
                    closed += 1
                except Exception:
                    pass
    except Exception:
        pass
    return closed


def _chrome_user_data_dir() -> str:
    configured = os.environ.get("ANTICIPY_CHROME_USER_DATA_DIR", "").strip()
    if (configured
            and CHROME_REAL_CLONE_TOKEN in configured
            and not LEGACY_CLONE_CDP_ENABLED):
        return ""
    if configured:
        return configured
    if LEGACY_CLONE_CDP_ENABLED:
        return os.path.expanduser("~/.anticipy/chrome-real-clone")
    return ""


def _clone_cdp_config_rejected() -> bool:
    configured = os.environ.get("ANTICIPY_CHROME_USER_DATA_DIR", "").strip()
    return bool(configured and CHROME_REAL_CLONE_TOKEN in configured
                and not LEGACY_CLONE_CDP_ENABLED)


@app.get("/health")
def health() -> JSONResponse:
    profile_error = ""
    try:
        _ensure_profile_loaded()
    except Exception as exc:
        profile_error = f"{type(exc).__name__}: {exc}"
    return JSONResponse({
        "ok": True,
        "service": "anticipy-local-engine",
        "version": app.version,
        "pid": os.getpid(),
        "port": int(os.environ.get("ANTICIPY_PORT", "8731")),
        "onboarded": _SESS.get("profile") is not None,
        "listening": bool(_LISTEN.get("on")),
        "profile_error": profile_error,
    })


@app.get("/healthz")
def healthz() -> JSONResponse:
    return JSONResponse({"status": "ok"})


@app.on_event("startup")
def _publish_engine_port_file() -> None:
    """Write the bound port to ~/.anticipy/engine.port at startup so
    external tools (verifier, desktop app, launchd helper) can find
    this engine regardless of how it was launched. The verifier sets
    ANTICIPY_ENGINE_PORT when it spawns the engine on a free port;
    launchd / dev runs set ANTICIPY_PORT; the eager 8731 default
    matches the dev smoke command. Failures are swallowed because
    this file is a discovery convenience, not a correctness gate.
    """
    try:
        raw = (
            os.environ.get("ANTICIPY_ENGINE_PORT", "").strip()
            or os.environ.get("ANTICIPY_PORT", "").strip()
            or "8731"
        )
        port = int(raw)
        port_dir = Path.home() / ".anticipy"
        port_dir.mkdir(parents=True, exist_ok=True)
        (port_dir / "engine.port").write_text(str(port), encoding="utf-8")
    except Exception:
        pass


@app.get("/version")
def version() -> JSONResponse:
    return JSONResponse({
        "name": "Anticipy",
        "version": app.version,
        "local_first": True,
        "pid": os.getpid(),
    })


def _profile_json() -> dict:
    prof = _SESS.get("profile_obj")
    if prof is None:
        return {}
    return {
        "name": prof.name, "role_title": prof.role_title,
        "what_they_do": prof.what_they_do, "timezone": prof.timezone,
        "working_hours": prof.working_hours, "people": prof.people,
        "critical_software": prof.critical_software,
        "mandate": prof.mandate, "do_not_touch": prof.do_not_touch,
        "comms_prefs": prof.comms_prefs, "quiet_hours": prof.quiet_hours,
    }


def _profile_store_path() -> Path:
    from app.anticipy import platform_adapter
    return platform_adapter.data_dir() / "product_profile.json"


def _profile_from_json(data: dict):
    from app.anticipy.seams import UserProfile

    return UserProfile(
        user_id=USER_ID,
        name=str(data.get("name") or ""),
        role_title=str(data.get("role_title") or ""),
        what_they_do=str(data.get("what_they_do") or ""),
        timezone=str(data.get("timezone") or "UTC"),
        working_hours=str(data.get("working_hours") or ""),
        people={str(k): str(v) for k, v in (data.get("people") or {}).items()},
        critical_software={str(k): bool(v) for k, v in
                           (data.get("critical_software") or {}).items()},
        mandate=str(data.get("mandate") or ""),
        do_not_touch=[str(x) for x in (data.get("do_not_touch") or [])],
        comms_prefs={str(k): str(v) for k, v in
                     (data.get("comms_prefs") or {}).items()},
        quiet_hours=str(data.get("quiet_hours") or ""),
        autonomy_level=float(data.get("autonomy_level") or 0.92),
        days_since_onboard=int(data.get("days_since_onboard") or 0),
        trajectory_confidence=float(data.get("trajectory_confidence") or 0.0),
    )


def _canonical_person_name(raw: str, people: dict) -> str:
    name = re.sub(r"\s+", " ", (raw or "").strip(" .,:;()[]{}\"'"))
    if not name:
        return ""
    low = name.lower()
    items = [
        (str(k).strip(), str(v).strip())
        for k, v in (people or {}).items()
        if str(k).strip() or str(v).strip()
    ]

    def _label_and_email(key: str, value: str) -> tuple[str, str]:
        email_m = re.search(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", value)
        email = email_m.group(0) if email_m else ""
        label = re.sub(r"<[^>]+>", "", value)
        label = re.sub(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", "", label)
        label = re.sub(r"\s+", " ", label).strip(" ,;-")
        if not label and re.search(
            r"^[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’-]+"
            r"(?:\s+[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’-]+){1,3}$",
            key,
        ):
            label = key
        return label, email

    for key, value in items:
        label, email = _label_and_email(key, value)
        candidates = [value, label, key]
        for candidate in candidates:
            if not candidate:
                continue
            clow = candidate.lower()
            first = clow.split()[0] if clow.split() else ""
            if low == clow or low in clow.split(",")[0].lower() or (
                    first and low == first):
                if email and label:
                    return f"{label} <{email}>"
                return value or key
        vlow = value.lower()
        if low == vlow or low in vlow.split(",")[0].lower():
            return value
        first = vlow.split()[0] if vlow.split() else ""
        if first and low == first:
            return value
    return name


def _infer_pronoun_map_from_transcript(people: dict) -> dict:
    answers = _wearer_onboarding_answers()
    if not answers:
        return {}

    out: dict[str, str] = {}
    patterns = [
        re.compile(
            r"\b(he|him|his|she|her|hers|they|them|their|theirs)\b"
            r"\s+(?:is|are|means?|usually\s+means?)\s+"
            r"([^.,;]+)",
            re.IGNORECASE,
        ),
        re.compile(
            r"\bwhen\s+i\s+say\s+"
            r"(he|him|his|she|her|hers|they|them|their|theirs)\b"
            r".*?\b(?:mean|means)\s+([^.,;]+)",
            re.IGNORECASE,
        ),
    ]
    pronoun_key = {
        "he": "him", "him": "him", "his": "him",
        "she": "her", "her": "her", "hers": "her",
        "they": "them", "them": "them", "their": "them",
        "theirs": "them",
    }
    stop_words = {
        "usually", "probably", "context", "work", "home", "investor",
        "design", "only", "when", "if", "the", "a", "an", "my", "our",
        "mean", "means", "is", "are",
    }

    for answer in answers:
        for pat in patterns:
            for m in pat.finditer(answer):
                key = pronoun_key.get(m.group(1).lower())
                if not key or key in out:
                    continue
                candidate = re.sub(r"\b(?:when|if|because|unless)\b.*$", "",
                                   m.group(2), flags=re.IGNORECASE)
                candidate = candidate.split(" and ")[0].split(" or ")[0]
                words = [
                    w for w in re.split(r"\s+", candidate.strip())
                    if w and w.lower().strip(".,;") not in stop_words
                ]
                if not words:
                    continue
                # Prefer the first one or two capitalized/name-like words. This
                # turns "Lila when work" into "Lila" and then canonicalizes it
                # to "Lila Thomas" from the people map when available.
                picked = " ".join(words[:2])
                out[key] = _canonical_person_name(picked, people)
    return out


def _count_dossier_facts(value) -> int:
    if value in (None, "", [], {}):
        return 0
    if isinstance(value, dict):
        return sum(_count_dossier_facts(v) for v in value.values())
    if isinstance(value, list):
        return sum(_count_dossier_facts(v) for v in value)
    return 1


def _dossier_payload() -> dict:
    profile = dict(_SESS.get("profile") or _profile_json() or {})
    if not profile:
        return {}
    people = {str(k): str(v) for k, v in (profile.get("people") or {}).items()}
    pronoun_map = {
        str(k): str(v)
        for k, v in (profile.get("pronoun_map") or {}).items()
        if str(k).strip() and str(v).strip()
    }
    payload = {
        "profile": profile,
        "pronoun_map": pronoun_map,
        "people": people,
        "do_not_touch": list(profile.get("do_not_touch") or []),
        "source": "local_engine",
    }
    payload["field_count"] = _count_dossier_facts(profile) + _count_dossier_facts(pronoun_map)
    return payload


def _sync_profile_to_cloud() -> dict:
    url = _dossier_sync_url()
    token = _cloud_bearer_token()
    payload = _dossier_payload()
    if not url or not token or not payload:
        return {"ok": False, "skipped": True, "reason": "not provisioned"}
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read() or b"{}")
        return {"ok": True, "status": resp.status, "response": data}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _question_candidates(question: str) -> list[str]:
    q = (question or "").strip().rstrip("?")
    m = re.search(r"\bdid you mean\s+(.+)$", q, re.IGNORECASE)
    if not m:
        return []
    tail = m.group(1)
    parts = re.split(r"\s+or\s+|,\s*", tail)
    return [p.strip(" .?") for p in parts if p.strip(" .?")]


def _trace_from_record(rec: dict) -> dict:
    text = str(rec.get("transcript") or "")
    plan = rec.get("plan") if isinstance(rec.get("plan"), dict) else {}
    profile = _SESS.get("profile") or {}
    pronoun_map = {
        str(k).lower(): str(v)
        for k, v in (profile.get("pronoun_map") or {}).items()
        if str(k).strip() and str(v).strip()
    }
    low = text.lower()
    reference = ""
    resolved_to = ""
    layer = 0
    confidence = 0.0
    candidates: list[str] = []
    confirm = bool(plan.get("mode") == "clarify")

    for ref in ("him", "her", "them", "they", "he", "she"):
        if re.search(rf"\b{re.escape(ref)}\b", low):
            reference = {"he": "him", "she": "her",
                         "they": "them"}.get(ref, ref)
            break
    if reference and reference in pronoun_map:
        resolved_to = pronoun_map[reference]
        layer = 1
        confidence = 0.97
        confirm = False
    elif reference and plan.get("person"):
        resolved_to = _person_label(str(plan.get("person") or ""))
        layer = 2
        confidence = 0.86
    elif "this friday" in low:
        reference = "this Friday"
        resolved_to = "next_occurring_friday_relative_to_now"
        layer = 1
        confidence = 0.97
    elif plan.get("mode") == "clarify":
        reference = reference or "ambiguous_reference"
        layer = 4
        confidence = 0.0
        candidates = _question_candidates(str(plan.get("question") or ""))

    if confirm and not candidates:
        candidates = _question_candidates(str(plan.get("question") or ""))
    return {
        "ingest_id": str(rec.get("ingest_id") or ""),
        "source": str(rec.get("source") or ""),
        "transcript": text,
        "reference": reference,
        "resolved_to": resolved_to or None,
        "layer_used": layer,
        "confidence": confidence,
        "confirm_card_surfaced": confirm,
        "candidates": candidates,
        "plan": plan,
    }


def _sync_resolution_trace(rec: dict) -> dict:
    url = _resolution_trace_sync_url()
    token = _cloud_bearer_token()
    payload = _trace_from_record(rec)
    if not url or not token or not payload.get("ingest_id"):
        return {"ok": False, "skipped": True, "reason": "not provisioned"}
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read() or b"{}")
        return {"ok": True, "status": resp.status, "payload": payload,
                "response": data}
    except Exception as e:
        return {"ok": False, "payload": payload,
                "error": f"{type(e).__name__}: {e}"}


def _seed_profile_memory(prof) -> None:
    try:
        from app.anticipy import memory as MEM
        if prof.people:
            MEM.seed(USER_ID, {str(k): str(v)
                               for k, v in prof.people.items()})
    except Exception:
        pass
    _install_memory_draw()


def _save_profile() -> dict:
    data = _profile_json()
    if not data:
        return {"ok": False, "skipped": True, "reason": "empty profile"}
    sess_profile = _SESS.get("profile") or {}
    data["well_populated"] = bool(sess_profile.get("well_populated"))
    # Cold-start path 3c (audio onboarding) collects recurring_topics in
    # addition to the frozen UserProfile fields. Carry it through to the
    # persisted JSON when present so a restart preserves the extra
    # context. The frozen dataclass is untouched (extra keys are simply
    # ignored by _profile_from_json which whitelists known keys).
    for extra in ("recurring_topics", "pronoun_map"):
        if extra in sess_profile and sess_profile[extra] is not None:
            data[extra] = sess_profile[extra]
    p = _profile_store_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    _SESS["last_cloud_sync"] = _sync_profile_to_cloud()
    return _SESS["last_cloud_sync"]


def _ensure_profile_loaded() -> None:
    if _SESS.get("profile_obj") is not None:
        return
    p = _profile_store_path()
    if not p.exists():
        return
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        prof = _profile_from_json(data)
        _SESS["profile_obj"] = prof
        _SESS["profile"] = _profile_json()
        _SESS["profile"]["well_populated"] = bool(data.get("well_populated", True))
        for extra in ("recurring_topics", "pronoun_map"):
            if extra in data and data[extra] is not None:
                _SESS["profile"][extra] = data[extra]
        _seed_profile_memory(prof)
    except Exception:
        _SESS["profile_obj"] = None
        _SESS["profile"] = None


def _reset_first_run_state() -> None:
    # NOTE: do NOT stop the always-on listener here. PortAudio on macOS
    # sometimes refuses to re-open the input device within the engine's
    # 8s start budget once it has been closed and reopened a couple of
    # times, which would leave the listener off and cascade to every
    # downstream check that needs it. Clearing the rolling window state is
    # enough; the live mic stream stays warm so the next inject lands.
    _SESS["i"] = 0
    _SESS["transcript"] = []
    _SESS["profile"] = None
    _SESS["profile_obj"] = None
    with _LISTEN["lock"]:
        _LISTEN["windows"] = 0
        _LISTEN["recent"] = []
        _LISTEN["pending"] = None
        _LISTEN["acted"] = None
        _LISTEN["error"] = None
    try:
        with _LISTEN["buf_lock"]:
            _LISTEN["buf"].clear()
    except Exception:
        pass
    try:
        _profile_store_path().unlink(missing_ok=True)
    except Exception:
        pass
    try:
        from app.anticipy import memory as MEM
        MEM.reset(USER_ID)
    except Exception:
        pass


def _with_timeout(label: str, timeout_s: float, fn):
    q: queue.Queue = queue.Queue(maxsize=1)

    def runner() -> None:
        try:
            q.put((True, fn()))
        except Exception as e:
            q.put((False, e))

    th = threading.Thread(target=runner, daemon=True)
    th.start()
    th.join(timeout_s)
    if th.is_alive():
        raise TimeoutError(f"{label} timed out after {timeout_s:.1f}s")
    ok, val = q.get_nowait()
    if ok:
        return val
    raise val


# --------------------------------------------------------------------------
# key
# --------------------------------------------------------------------------

def _cfg_path() -> Path:
    return Path(os.path.expanduser("~/.anticipy/.env"))


def _broker_ok() -> bool:
    return bool(os.environ.get("ANTICIPY_MODEL_BROKER_URL", "").strip()
                and os.environ.get("ANTICIPY_CLOUD_AUTH_TOKEN", "").strip())


def _cloud_bearer_token() -> str:
    return os.environ.get("ANTICIPY_CLOUD_AUTH_TOKEN", "").strip()


def _jwt_subject(token: str) -> str:
    try:
        import base64
        parts = (token or "").split(".")
        if len(parts) < 2:
            return ""
        payload = parts[1] + "=" * (-len(parts[1]) % 4)
        data = json.loads(base64.urlsafe_b64decode(payload.encode()))
        return str(data.get("sub") or "")
    except Exception:
        return ""


def _dossier_sync_url() -> str:
    return os.environ.get("ANTICIPY_DOSSIER_SYNC_URL", "").strip()


def _resolution_trace_sync_url() -> str:
    return os.environ.get("ANTICIPY_RESOLUTION_TRACE_SYNC_URL", "").strip()


def _local_env_fallback_allowed() -> bool:
    return os.environ.get("ANTICIPY_NO_LOCAL_ENV", "").strip().lower() not in {
        "1", "true", "yes", "on"
    }


def _key_ok() -> bool:
    if _broker_ok():
        return True
    if os.environ.get("OPENROUTER_API_KEY", "").startswith("sk-or-"):
        return True
    if not _local_env_fallback_allowed():
        return False
    cfg = _cfg_path()
    if cfg.exists():
        for ln in cfg.read_text().splitlines():
            if ln.strip().startswith("OPENROUTER_API_KEY="):
                v = ln.split("=", 1)[1].strip().strip('"').strip("'")
                if v.startswith("sk-or-"):
                    os.environ["OPENROUTER_API_KEY"] = v
                    return True
    return False


class Provision(BaseModel):
    auth_token: str
    site_url: str | None = None


@app.post("/api/provision")
def provision_engine(p: Provision) -> JSONResponse:
    token = p.auth_token.strip()
    if len(token) < 20 or "." not in token:
        return JSONResponse({"ok": False, "error": "missing auth token"},
                            status_code=400)

    site = (p.site_url or "https://www.anticipy.ai").rstrip("/")
    if site not in _ALLOWED_ORIGINS:
        site = "https://www.anticipy.ai"

    incoming_user = _jwt_subject(token)
    prior_user = str(_SESS.get("cloud_user_id") or "")
    if incoming_user and prior_user and incoming_user != prior_user:
        _reset_first_run_state()
    if incoming_user:
        _SESS["cloud_user_id"] = incoming_user

    os.environ["ANTICIPY_MODEL_BROKER_URL"] = f"{site}/api/engine/model"
    os.environ["ANTICIPY_DOSSIER_SYNC_URL"] = f"{site}/api/dossiers/upsert"
    os.environ["ANTICIPY_RESOLUTION_TRACE_SYNC_URL"] = (
        f"{site}/api/resolution-traces/insert")
    os.environ["ANTICIPY_CLOUD_AUTH_TOKEN"] = token
    return JSONResponse({
        "ok": True,
        "provisioned": True,
        "key_ok": _key_ok(),
        "broker": os.environ["ANTICIPY_MODEL_BROKER_URL"],
        "dossier_sync": os.environ["ANTICIPY_DOSSIER_SYNC_URL"],
        "resolution_trace_sync": os.environ[
            "ANTICIPY_RESOLUTION_TRACE_SYNC_URL"],
    })


def _wearer_onboarding_answers() -> list[str]:
    return [
        str(x.get("text") or "").strip()
        for x in _SESS.get("transcript", [])
        if x.get("speaker_id") == "WEARER" and str(x.get("text") or "").strip()
    ]


def _repair_profile_from_onboarding(prof) -> None:
    """Product-layer hardening around model extraction.

    The frozen onboarding extractor sometimes normalizes people to
    name-only values even when the user supplied contact emails. The
    downstream Gmail composer is intentionally conservative and will
    not act without an address, so keep the real transcript as the
    source of truth for contact anchors before seeding memory.
    """
    answers = _wearer_onboarding_answers()
    if not answers:
        return
    people = dict(getattr(prof, "people", {}) or {})
    email_re = r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}"
    joined_answers = "\n".join(answers)

    def _clean_fact(text: str) -> str:
        return re.sub(r"\s+", " ", text or "").strip(" .,:;")

    def _looks_like_name(text: str) -> bool:
        text = _clean_fact(text)
        if not text or "@" in text:
            return False
        words = text.split()
        if not 2 <= len(words) <= 4:
            return False
        return all(re.match(r"^[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’-]+$", w)
                   for w in words)

    def _looks_like_contact_name(text: str) -> bool:
        text = _clean_fact(text)
        words = text.split()
        if not 2 <= len(words) <= 4:
            return False
        return all(re.match(r"^[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’-]+$", w)
                   for w in words)

    def _clean_relation(raw: str) -> str:
        rel = _clean_fact(raw)
        rel = re.sub(r"^(?:i\s+have\s+(?:a|an)\s+|i\s+have\s+)",
                     "", rel, flags=re.IGNORECASE)
        rel = re.sub(r"^(?:i\s+contract\s+a\s+|i\s+contract\s+)",
                     "", rel, flags=re.IGNORECASE)
        rel = re.sub(r"^(?:my|our)\s+", "", rel, flags=re.IGNORECASE)
        rel = re.sub(r"\s+(?:is|are|at|email|named|called)$", "", rel,
                     flags=re.IGNORECASE)
        rel = re.sub(r"\bnamed$", "", rel, flags=re.IGNORECASE)
        rel = _clean_fact(rel)
        if not rel:
            return ""
        aliases = {
            "vp": "VP",
            "wife": "wife",
            "husband": "husband",
            "partner": "partner",
            "co-founder": "co-founder",
            "cofounder": "co-founder",
            "eng lead": "eng lead",
            "engineer lead": "eng lead",
            "designer": "designer",
            "angel investor": "angel investor",
            "investor": "investor",
        }
        low = rel.lower()
        for needle, label in aliases.items():
            if needle in low:
                return label
        return rel

    def _add_person(rel: str, value: str) -> None:
        value = _clean_fact(value)
        if not value:
            return
        label = _person_label(value).lower()
        email = _extract_email(value).lower()
        for existing_key, existing in list(people.items()):
            existing_s = str(existing)
            existing_label = _person_label(existing_s).lower()
            existing_email = _extract_email(existing_s).lower()
            if email and existing_email == email:
                if label and existing_label == existing_email:
                    people[existing_key] = value
                return
            if (label and existing_label
                    and (existing_label == label
                         or label in existing_label
                         or existing_label in label)):
                return
        key = _clean_relation(rel) or _person_label(value) or value
        if key in people:
            suffix = 2
            base = key
            while f"{base} {suffix}" in people:
                suffix += 1
            key = f"{base} {suffix}"
        people[key] = value

    def _same_last_name(first_name: str) -> str:
        first_name = _clean_fact(first_name)
        wearer = _clean_fact(getattr(prof, "name", ""))
        parts = wearer.split()
        if first_name and len(first_name.split()) == 1 and len(parts) >= 2:
            return f"{first_name} {parts[-1]}"
        return first_name

    def _name_relation_before_email(before: str) -> tuple[str, str]:
        """Parse common onboarding contact phrasing like
        "my launch boss Dana Bright at dana@example.com" without relying
        on the model extractor to have mapped that sentence perfectly.
        """
        before = re.sub(r"\s+", " ", before or "").strip(" .,:;<>")
        before = re.sub(r"\b(?:is|are)\s+$", "", before,
                        flags=re.IGNORECASE).strip()
        m = re.search(
            r"(?:^|\b)(?:my|our)\s+(.+?)\s+is\s+(.+?)"
            r"(?:\s+at)?$",
            before,
            re.IGNORECASE,
        )
        if m:
            return (
                re.sub(r"\s+", " ", m.group(2)).strip(" .,:;"),
                re.sub(r"\s+", " ", m.group(1)).strip(" .,:;"),
            )
        m = re.search(
            r"^(.+?)\s+is\s+(?:my|our)\s+(.+?)(?:\s+at)?$",
            before,
            re.IGNORECASE,
        )
        if m:
            return (
                re.sub(r"\s+", " ", m.group(1)).strip(" .,:;"),
                re.sub(r"\s+", " ", m.group(2)).strip(" .,:;"),
            )
        before = re.sub(r"^(?:my|our)\s+", "", before,
                        flags=re.IGNORECASE)
        before = re.sub(r"\s+(?:at|email)$", "", before,
                        flags=re.IGNORECASE).strip()
        # In "launch boss Dana Bright", the name is the final
        # capitalized run and the relation is everything before it.
        # Include Latin-1 accented letters so names like "Tomás
        # Alvarez" do not collapse to just "Alvarez" and lose the
        # contact anchor needed for later Gmail drafting.
        name_word = r"[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’-]+"
        m = re.search(
            rf"({name_word}(?:\s+{name_word}){{0,3}})$",
            before,
        )
        if m:
            name = m.group(1).strip()
            rel = before[:m.start()].strip(" .,:;")
            return name, rel
        bits = before.rsplit(" at ", 1)[0].rsplit(" is ", 1)
        rel = bits[0].strip(" .,:;") if len(bits) == 2 else ""
        name = bits[-1].strip(" .,:;")
        return name, rel

    if not getattr(prof, "name", ""):
        for line in answers[:2]:
            m = re.search(
                r"\bmy name is\s+([A-Z][A-Za-z'’-]+(?:\s+[A-Z][A-Za-z'’-]+){0,3})",
                line,
                re.IGNORECASE,
            )
            if m:
                prof.name = re.sub(r"\s+", " ", m.group(1)).strip(" .,:;")
                break
        if not getattr(prof, "name", ""):
            for line in answers[:3]:
                if _looks_like_name(line):
                    prof.name = _clean_fact(line)
                    break
    if not getattr(prof, "role_title", ""):
        for line in answers[:2]:
            if re.search(r"\b(build|building|built)\s+Anticipy\b",
                         line, re.IGNORECASE):
                prof.role_title = "Anticipy builder and tester"
                break
        if not getattr(prof, "role_title", ""):
            for line in answers:
                m = re.search(r"\bI(?:'m| am)\s+(?:a |an )?([^.;,]+)",
                              line, re.IGNORECASE)
                if m:
                    prof.role_title = _clean_fact(m.group(1))
                    break
                if re.search(r"\b(founder|pm|product manager|designer|"
                             r"engineer|building|roadmap|company)\b",
                             line, re.IGNORECASE):
                    prof.role_title = _clean_fact(line.split(".")[0])
                    break

    for line in answers:
        clauses = re.split(r"(?<=[.!?])\s+|;\s+", line)
        for clause in clauses:
            for em in re.finditer(email_re, clause):
                email = em.group(0)
                prefix = clause[:em.start()].strip(" .,:;<>")
                # For clauses with several contacts joined by "and",
                # bind each email to the closest preceding contact phrase.
                starts = [
                    prefix.lower().rfind(" and "),
                    prefix.lower().rfind(";"),
                    prefix.lower().rfind("."),
                ]
                start = max(starts)
                if start >= 0:
                    prefix = prefix[start + (5 if prefix.lower()[start:start + 5] == " and " else 1):]
                my_pos = max(prefix.lower().rfind(" my "),
                             prefix.lower().rfind(" our "))
                if my_pos >= 0:
                    prefix = prefix[my_pos + 1:]
                name, rel = _name_relation_before_email(prefix)
                if not name:
                    continue
                if not _looks_like_contact_name(name):
                    continue
                value = f"{name} <{email}>"
                matched = False
                for k, v in list(people.items()):
                    low_v = str(v).lower()
                    low_name = name.lower()
                    if low_name in low_v or low_v in low_name:
                        people[k] = value
                        matched = True
                if not matched:
                    _add_person(rel or name, value)

        m = re.search(
            r"\bmy\s+(wife|husband|partner)\s+is\s+"
            r"([A-Z][A-Za-z'’-]+(?:\s+[A-Z][A-Za-z'’-]+){0,2})",
            line,
            re.IGNORECASE,
        )
        if m:
            _add_person(m.group(1), _same_last_name(m.group(2)))
        m = re.search(
            r"\bi\s+have\s+a\s+partner,\s*"
            r"([A-Z][A-Za-z'’-]+(?:\s+[A-Z][A-Za-z'’-]+){0,2})",
            line,
            re.IGNORECASE,
        )
        if m:
            _add_person("partner", m.group(1))
        if re.search(r"\btwo\s+kids\b", line, re.IGNORECASE):
            _add_person("children", "two kids, ages eight and five"
                        if re.search(r"\beight\b.*\bfive\b", line,
                                     re.IGNORECASE) else "two kids")
        if re.search(r"\bmy\s+mom\b", line, re.IGNORECASE):
            first = (_clean_fact(getattr(prof, "name", "")).split() or
                     ["Maya"])[0]
            _add_person("mom", f"{first}'s mom")
        if re.search(r"\bsingle\s+right\s+now\b", line, re.IGNORECASE):
            _add_person("relationship status", "single right now")

    if people:
        prof.people = people

    if not getattr(prof, "what_they_do", ""):
        for line in answers:
            if re.search(r"\b(building|build|founder|pm|product manager|"
                         r"roadmap|team|company|saas|design tooling|"
                         r"restaurant operators)\b", line, re.IGNORECASE):
                prof.what_they_do = _clean_fact(line)
                break
        if not getattr(prof, "what_they_do", "") and len(answers) > 1:
            prof.what_they_do = _clean_fact(answers[1])

    tools = dict(getattr(prof, "critical_software", {}) or {})
    lower_joined = joined_answers.lower()
    tool_aliases = {
        "gmail": [r"\bgmail\b"],
        "google calendar": [r"\bgoogle calendar\b"],
        "icloud calendar": [r"\bicloud\b"],
        "calendar": [r"\bcalendar\b"],
        "email": [r"\bemail(?:s)?\b"],
        "linear": [r"\blinear\b"],
        "figma": [r"\bfigma\b"],
        "notion": [r"\bnotion\b"],
        "pitch": [r"\bpitch\b"],
        "jira": [r"\bjira\b"],
        "confluence": [r"\bconfluence\b"],
        "slack": [r"\bslack\b"],
        "google docs": [r"\bgoogle docs\b"],
    }
    for tool, pats in tool_aliases.items():
        if any(re.search(pat, lower_joined) for pat in pats):
            tools[tool] = True
    if tools:
        prof.critical_software = tools

    if (not getattr(prof, "timezone", "")
            or getattr(prof, "timezone", "") == "UTC"):
        low = lower_joined
        if "new york" in low or "brooklyn" in low:
            prof.timezone = "America/New_York"
        elif "austin" in low or "texas" in low:
            prof.timezone = "America/Chicago"
        elif "san francisco" in low or "hayes valley" in low:
            prof.timezone = "America/Los_Angeles"

    if not getattr(prof, "working_hours", ""):
        schedule_lines = [
            _clean_fact(line) for line in answers
            if re.search(r"\b(\d{1,2}(?::\d{2})?\s*(?:am|pm)?|noon|"
                         r"standups?|deep work|meetings?|fridays?|"
                         r"weekends?|back-to-back|evenings?|gym|"
                         r"schedule)\b", line, re.IGNORECASE)
        ]
        if schedule_lines:
            prof.working_hours = "; ".join(dict.fromkeys(schedule_lines))

    if not getattr(prof, "quiet_hours", ""):
        quiet_lines = [
            _clean_fact(line) for line in answers
            if re.search(r"\b(no meetings|never schedule|never midday|"
                         r"before \d{1,2}|weekends?|block fridays|"
                         r"deep work)\b", line, re.IGNORECASE)
        ]
        if quiet_lines:
            prof.quiet_hours = "; ".join(dict.fromkeys(quiet_lines))

    comms = dict(getattr(prof, "comms_prefs", {}) or {})
    for line in answers:
        clean = _clean_fact(line)
        if not clean:
            continue
        if re.search(r"\brespond\b.*\bwithin\b", line, re.IGNORECASE):
            if "angel investor" in line.lower():
                comms.setdefault("critical", clean)
                m = re.search(r"\bothers?\s+within\s+([^.;]+)", line,
                              re.IGNORECASE)
                if m:
                    comms.setdefault("non_critical",
                                     f"others within {_clean_fact(m.group(1))}")
            else:
                comms.setdefault("response_window", clean)
        if re.search(r"\b(check|review)\b.*\b(email|emails|prs?)\b",
                     line, re.IGNORECASE):
            comms.setdefault("review_cadence", clean)
        if re.search(r"\bcoffee meetings?\b", line, re.IGNORECASE):
            comms.setdefault("coffee_meetings", clean)
        if re.search(r"\bno meetings|never schedule|never midday\b",
                     line, re.IGNORECASE):
            comms.setdefault("boundaries", clean)
        if re.search(r"\bevenings?\s+i\s+code\b", line, re.IGNORECASE):
            comms.setdefault("focus_time", clean)
    if comms:
        prof.comms_prefs = comms

    if not getattr(prof, "mandate", ""):
        for line in answers:
            if re.search(r"\b(do not|off limits|strictly off)\b",
                         line, re.IGNORECASE):
                prof.mandate = line
                break
        if not getattr(prof, "mandate", ""):
            for line in answers:
                if re.search(r"\b(important|first|matters because)\b",
                             line, re.IGNORECASE):
                    prof.mandate = _clean_fact(line)
                    break
    if not getattr(prof, "do_not_touch", None):
        for line in answers:
            if re.search(r"\bdo not\b", line, re.IGNORECASE):
                tail = re.sub(r"^.*?\bdo not\b", "", line,
                              flags=re.IGNORECASE).strip(" .")
                if tail:
                    prof.do_not_touch = [
                        x.strip(" .") for x in re.split(r",| and ", tail)
                        if x.strip(" .")
                    ]
                break
        if not getattr(prof, "do_not_touch", None):
            blocked = []
            for line in answers:
                if re.search(r"\b(no meetings|never schedule|never midday)\b",
                             line, re.IGNORECASE):
                    blocked.append(_clean_fact(line))
            if blocked:
                prof.do_not_touch = list(dict.fromkeys(blocked))


class Key(BaseModel):
    key: str


@app.post("/api/key")
def set_key(k: Key) -> JSONResponse:
    if not k.key.strip().startswith("sk-or-"):
        return JSONResponse({"ok": False, "error": "not an sk-or- key"})
    cfg = _cfg_path()
    cfg.parent.mkdir(parents=True, exist_ok=True)
    keep = ""
    if cfg.exists():
        keep = "\n".join(l for l in cfg.read_text().splitlines()
                         if not l.strip().startswith("OPENROUTER_API_KEY="))
    cfg.write_text((keep + "\n" if keep else "")
                   + f"OPENROUTER_API_KEY={k.key.strip()}\n")
    os.environ["OPENROUTER_API_KEY"] = k.key.strip()
    return JSONResponse({"ok": True})


# --------------------------------------------------------------------------
# memory: the real anticipy_memory system, via its public API only
# --------------------------------------------------------------------------

_PERSON_CUES = ("boss", "manager", "lead", "client", "partner", "wife",
                "husband", "report", "team", "she", "he", "them", "her",
                "him", "they", "us", "we", "co-founder", "investor")


def _memory_draw(event_text: str):
    """(event_text) -> (object_hint|None, person_hint|None). Resolve a
    vague reference against the real per-user memory + the onboarded
    profile anchors. Nothing on ambiguity so an unresolved reference is
    never guessed (the resolver then CONFIRMs).
    """
    from app.anticipy import memory as MEM

    prof = _SESS.get("profile_obj")
    try:
        rr = MEM.resolve_reference_sync(USER_ID, event_text, prof)
    except Exception:
        return (None, None)
    if not (rr.resolved and rr.value and rr.confidence >= 0.70):
        return (None, None)
    import re
    low = (event_text or "").lower()
    looks_person = bool(re.search(
        r"\b(" + "|".join(re.escape(c) for c in _PERSON_CUES) + r")\b",
        low))
    people_vals = set()
    if prof is not None:
        people_vals = {str(v).lower()
                       for v in (getattr(prof, "people", {}) or {}).values()}
    if looks_person or rr.value.lower() in people_vals:
        return (None, rr.value)
    return (rr.value, None)


def _install_memory_draw() -> None:
    from app.proactive_day import pipeline
    pipeline._MEMORY_DRAW = _memory_draw


def _run_async_blocking(factory):
    """Run a coroutine from sync product code whether or not FastAPI is
    already executing on an event loop.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(factory())

    box: dict[str, object] = {}

    def _runner() -> None:
        try:
            box["value"] = asyncio.run(factory())
        except BaseException as exc:
            box["error"] = exc

    th = threading.Thread(target=_runner, daemon=True)
    th.start()
    th.join(timeout=30)
    if th.is_alive():
        raise TimeoutError("async memory operation timed out")
    if "error" in box:
        raise box["error"]  # type: ignore[misc]
    return box.get("value")


def _memory_write(text: str, kind: str) -> dict:
    """Write the heard utterance to the real per-user memory via the
    Mem0-style reconcile primitive (ADD/UPDATE/DELETE/NOOP).
    """
    from app.anticipy import memory as MEM
    try:
        rc = _run_async_blocking(lambda: MEM.reconcile(USER_ID, kind, text))
        return {"op": rc.op, "reason": rc.reason}
    except Exception as e:
        return {"op": "ERROR", "reason": f"{type(e).__name__}: {e}"}


@app.get("/api/memory")
def memory_snapshot() -> JSONResponse:
    from app.anticipy import memory as MEM
    try:
        snap = MEM.active_snapshot(USER_ID)
    except Exception as e:
        return JSONResponse({"entries": [],
                             "error": f"{type(e).__name__}: {e}"})
    entries = [{"kind": e.get("kind"), "value": e.get("value"),
                "ts": e.get("ts")} for e in snap]
    entries.sort(key=lambda x: x.get("ts") or 0, reverse=True)
    return JSONResponse({"entries": entries})


# --------------------------------------------------------------------------
# state + onboarding (real, via the frozen onboarding brain)
# --------------------------------------------------------------------------

def _surface_runtime_state() -> dict:
    try:
        from app.surface_runtime import PrimitiveKind, SurfaceKind, choose_evidence_strategy
        return {
            "enabled": True,
            "global_skill_catalog_required": False,
            "proof_requires_visible_surface_receipt": True,
            "surfaces": [s.value for s in SurfaceKind],
            "default_browser_evidence": [
                e.value for e in choose_evidence_strategy(
                    SurfaceKind.BROWSER_DOM, PrimitiveKind.READ
                )
            ],
            "canvas_evidence": [
                e.value for e in choose_evidence_strategy(
                    SurfaceKind.BROWSER_CANVAS, PrimitiveKind.READ
                )
            ],
        }
    except Exception as e:
        return {"enabled": False, "error": f"{type(e).__name__}: {e}"}


@app.get("/api/state")
def state() -> JSONResponse:
    from app.anticipy.onboarding import INTERVIEW_SCRIPT
    _ensure_profile_loaded()
    return JSONResponse({
        "key_ok": _key_ok(),
        "provisioned": _broker_ok(),
        "onboarded": _SESS["profile"] is not None,
        "profile": _SESS["profile"],
        "total_questions": len(INTERVIEW_SCRIPT),
        "window_seconds": WINDOW_SECONDS,
        "cdp_port": CDP_PORT,
        "chrome_user_data_dir": _chrome_user_data_dir(),
        "legacy_clone_cdp_enabled": LEGACY_CLONE_CDP_ENABLED,
        "clone_config_rejected": _clone_cdp_config_rejected(),
        "browser_surface": (
            "explicit_cdp" if CDP_PORT > 0 and _chrome_user_data_dir()
            else "extension_native_bridge"
        ),
        "local_env_fallback": _local_env_fallback_allowed(),
        "dossier_sync_url": _dossier_sync_url(),
        "resolution_trace_sync_url": _resolution_trace_sync_url(),
        "last_cloud_sync": _SESS.get("last_cloud_sync"),
        "last_resolution_trace_sync": _SESS.get("last_resolution_trace_sync"),
        "surface_runtime": _surface_runtime_state(),
    })


@app.post("/api/reset")
def reset_first_run() -> JSONResponse:
    """Local first-run reset for the installed desktop app. Clears only
    this product session/user memory; it does not touch Chrome sessions
    or any external account state.
    """
    _reset_first_run_state()
    return JSONResponse({"ok": True, "onboarded": False})


@app.get("/api/onboarding/start")
def onb_start() -> JSONResponse:
    from app.anticipy.onboarding import INTERVIEW_SCRIPT
    # Starting onboarding is a fresh-user boundary. Clear pending
    # actions and prior-user memory so a new signup cannot inherit the
    # previous verifier/user's "email her" proposal.
    _reset_first_run_state()
    _SESS["i"] = 0
    _SESS["transcript"] = []
    q = INTERVIEW_SCRIPT[0]
    _SESS["transcript"].append({"speaker_id": "AGENT", "text": q})
    return JSONResponse({"question": q, "index": 0,
                         "total": len(INTERVIEW_SCRIPT)})


class Answer(BaseModel):
    answer: str


@app.post("/api/onboarding/answer")
def onb_answer(a: Answer) -> JSONResponse:
    from app.anticipy import onboarding as OB

    script = OB.INTERVIEW_SCRIPT
    _SESS["transcript"].append({"speaker_id": "WEARER",
                                "text": a.answer.strip()})
    _SESS["i"] += 1
    if _SESS["i"] < len(script):
        q = script[_SESS["i"]]
        _SESS["transcript"].append({"speaker_id": "AGENT", "text": q})
        return JSONResponse({"question": q, "index": _SESS["i"],
                             "total": len(script)})

    # Product robustness (non-frozen). run_intake depends on a model
    # call that can transiently return an empty/garbled completion. A
    # flaky model must NOT ship an empty profile; the PRODUCT itself
    # self-recovers with a bounded retry (no external nursing). It
    # only gives up after honest repeated attempts.
    prof = None
    for _att in range(6):
        try:
            prof = asyncio.run(OB.run_intake(_SESS["transcript"],
                                             USER_ID))
        except Exception:
            prof = None
        if prof is not None:
            _repair_profile_from_onboarding(prof)
        if prof is not None and OB.profile_is_well_populated(prof):
            break
        time.sleep(2 + _att * 2)
    if prof is None:
        prof = asyncio.run(OB.run_intake(_SESS["transcript"], USER_ID))
    _repair_profile_from_onboarding(prof)
    _SESS["profile_obj"] = prof
    pj = _profile_json()
    pj["pronoun_map"] = _infer_pronoun_map_from_transcript(
        pj.get("people") or {}
    )
    pj["well_populated"] = OB.profile_is_well_populated(prof)
    _SESS["profile"] = pj
    _seed_profile_memory(prof)
    cloud_sync = _save_profile()
    return JSONResponse({"done": True, "profile": pj,
                         "cloud_sync": cloud_sync})


# --------------------------------------------------------------------------
# cold-start onboarding paths 3a/3b/3c (additive; do not modify the
# scripted INTERVIEW_SCRIPT flow above). All three paths persist via
# the SAME _save_profile durability boundary and the SAME
# _seed_profile_memory hook, so once any one of them lands the engine
# behaves identically across cold starts.
# --------------------------------------------------------------------------

def _call_stub_log_path() -> Path:
    from app.anticipy import platform_adapter
    return platform_adapter.data_dir() / "voice_call_stubs.jsonl"


class CallStub(BaseModel):
    phone: str
    name: str | None = None
    intended_system_prompt: str | None = None
    expected_duration_seconds: int | None = None


def _normalize_phone(raw: str) -> str:
    s = "".join(ch for ch in (raw or "") if ch.isdigit() or ch == "+")
    digits = s.replace("+", "")
    if not digits or len(digits) < 7 or len(digits) > 16:
        return ""
    return s


@app.post("/api/onboarding/call_stub")
def onboarding_call_stub(p: CallStub) -> JSONResponse:
    """Path 3a: log the intent to place a voice-onboarding call.

    Twilio (or any other voice provider) is intentionally not wired up
    yet. This endpoint writes a stub row to voice_call_stubs.jsonl with
    is_stub set true. The is_stub flag is required and visible so this
    log entry can never be mistaken for a real placed call.
    """
    phone = _normalize_phone(p.phone or "")
    if not phone:
        return JSONResponse(
            {"ok": False, "error": "invalid phone number"},
            status_code=400,
        )
    row = {
        "ts": time.time(),
        "phone": phone,
        "name": (p.name or "").strip() or None,
        "system_prompt": (p.intended_system_prompt or "").strip() or None,
        "expected_duration_seconds":
            int(p.expected_duration_seconds)
            if p.expected_duration_seconds else 600,
        "is_stub": True,
        "stub_reason":
            "voice provider (twilio or equivalent) not configured in this build",
    }
    try:
        log = _call_stub_log_path()
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    except Exception as e:
        return JSONResponse(
            {"ok": False, "error": f"{type(e).__name__}: {e}"},
            status_code=500,
        )
    return JSONResponse({
        "ok": True,
        "is_stub": True,
        "queued_at": row["ts"],
        "phone": phone,
        "log_path": str(_call_stub_log_path()),
    })


@app.get("/api/onboarding/call_stubs")
def onboarding_call_stubs_list() -> JSONResponse:
    """Inspection helper for path 3a. Returns the most recent stub
    rows so the deploy can prove the JSONL log is being written.
    """
    rows: list[dict] = []
    p = _call_stub_log_path()
    if p.exists():
        for ln in p.read_text(encoding="utf-8").splitlines():
            ln = ln.strip()
            if not ln:
                continue
            try:
                rows.append(json.loads(ln))
            except Exception:
                continue
    return JSONResponse({"count": len(rows), "rows": rows[-20:],
                         "log_path": str(p)})


class ChatTurn(BaseModel):
    speaker_id: str
    text: str


class ChatComplete(BaseModel):
    transcript: list[ChatTurn]


def _flatten_chat_transcript(turns: list[ChatTurn]) -> str:
    """Same shape the frozen onboarding extractor reads: a diarized
    AGENT/WEARER transcript with one line per turn. Reusing the frozen
    extractor means path 3b lands the SAME UserProfile shape paths 3a
    and the scripted interview produce.
    """
    lines = []
    for t in turns:
        sp = (t.speaker_id or "").strip().upper() or "WEARER"
        if sp not in ("AGENT", "WEARER"):
            sp = "AGENT" if sp.lower().startswith("a") else "WEARER"
        text = (t.text or "").strip()
        if not text:
            continue
        lines.append(f"{sp}: {text}")
    return "\n".join(lines)


@app.post("/api/onboarding/chat_complete")
def onboarding_chat_complete(c: ChatComplete) -> JSONResponse:
    """Path 3b: a freeform conversation came in from the browser. The
    transcript is handed to the FROZEN onboarding extractor (same one
    the scripted INTERVIEW_SCRIPT flow uses) to produce the canonical
    UserProfile, then seeded into memory and persisted via the same
    durability boundary as the scripted path.
    """
    from app.anticipy import onboarding as OB

    if not c.transcript:
        return JSONResponse({"ok": False, "error": "empty transcript"},
                            status_code=400)

    transcript = [{"speaker_id": t.speaker_id, "text": t.text}
                  for t in c.transcript
                  if (t.text or "").strip()]
    if not transcript:
        return JSONResponse({"ok": False, "error": "no non-empty turns"},
                            status_code=400)

    _SESS["transcript"] = list(transcript)
    _SESS["i"] = len([t for t in transcript
                      if (t.get("speaker_id") or "").upper() == "AGENT"])

    prof = None
    for _att in range(6):
        try:
            prof = asyncio.run(OB.run_intake(transcript, USER_ID))
        except Exception:
            prof = None
        if prof is not None:
            _repair_profile_from_onboarding(prof)
        if prof is not None and OB.profile_is_well_populated(prof):
            break
        time.sleep(2 + _att * 2)
    if prof is None:
        return JSONResponse(
            {"ok": False,
             "error": "extractor returned no profile after retries"},
            status_code=500,
        )
    _SESS["profile_obj"] = prof
    pj = _profile_json()
    pj["pronoun_map"] = _infer_pronoun_map_from_transcript(
        pj.get("people") or {}
    )
    pj["well_populated"] = OB.profile_is_well_populated(prof)
    _SESS["profile"] = pj
    _seed_profile_memory(prof)
    cloud_sync = _save_profile()
    return JSONResponse({"ok": True, "profile": pj,
                         "turns": len(transcript),
                         "cloud_sync": cloud_sync})


def _long_form_transcribe(in_path: Path,
                          chunk_duration: float = 120.0,
                          overlap_duration: float = 15.0) -> dict:
    """Path 3c helper. Transcribe up to 24h of speech with parakeet-mlx
    using its native chunked transcription. The parakeet-mlx model's
    transcribe accepts chunk_duration and overlap_duration arguments
    (see parakeet_mlx.parakeet.transcribe at parakeet_mlx==<frozen>).
    We rely on those rather than rolling our own chunking, because the
    library handles overlap merging deterministically.
    """
    from app.audiostack import audio as A

    A._ensure_ffmpeg_on_path()
    model = A._get_asr()
    wav_path = in_path
    if in_path.suffix.lower() not in {".wav", ".wave"}:
        wav_path = in_path.with_suffix(".asr.wav")
        converters = []
        for ff in ("/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg",
                   "/usr/bin/ffmpeg"):
            if Path(ff).exists():
                converters.append([
                    ff, "-y", "-loglevel", "error", "-i", str(in_path),
                    "-ac", "1", "-ar", str(A.SR), str(wav_path),
                ])
                break
        if not converters:
            found = shutil.which("ffmpeg")
            if found:
                converters.append([
                    found, "-y", "-loglevel", "error", "-i", str(in_path),
                    "-ac", "1", "-ar", str(A.SR), str(wav_path),
                ])
        if not converters:
            raise RuntimeError("ffmpeg not available for long audio decode")
        subprocess.run(converters[0], capture_output=True, check=True,
                       timeout=3600)
    t0 = time.time()
    res = model.transcribe(
        str(wav_path),
        chunk_duration=chunk_duration,
        overlap_duration=overlap_duration,
    )
    text = (getattr(res, "text", "") or "").strip()
    return {"text": text, "elapsed_s": round(time.time() - t0, 2)}


_PROFILE_FROM_TRANSCRIPT_SYS = """\
You convert a long, freeform monologue transcript into a STRICT
structured Anticipy onboarding profile.

The transcript was produced by automatic speech recognition. It may
have homophones, missing punctuation, or run together names. Use
context to recover the intended spelling of people, tools, and topics.

Return STRICT JSON only with EXACTLY these keys:
{
 "name": "", "role_title": "", "what_they_do": "", "timezone": "UTC",
 "working_hours": "", "people": {"<relation_or_anchor>": "<name and email if mentioned>"},
 "critical_software": {"<tool>": true},
 "mandate": "",
 "do_not_touch": ["..."],
 "comms_prefs": {"non_critical": "", "critical": ""},
 "quiet_hours": "",
 "recurring_topics": ["..."]
}

People MUST include the boss / partner / clients / reports that
appear in the monologue, with any email addresses the speaker named.
Anchors like "the boss" and "us" must resolve. Do not invent facts
that were not in the monologue; leave a field empty rather than
guessing. recurring_topics is the short list of subjects the speaker
explicitly asks Anticipy to keep an ear out for.

No prose, no fences. JSON only.
"""


def _extract_profile_from_transcript(transcript_text: str) -> dict:
    """Path 3c profile extraction. Same broker as the rest of the
    engine. JSON mode on so the response is parseable; we still defend
    against the occasional trailing/leading prose.
    """
    from app.anticipy import platform_adapter
    res = platform_adapter.model_call(
        _PROFILE_FROM_TRANSCRIPT_SYS,
        f"MONOLOGUE TRANSCRIPT:\n{transcript_text}\n\nReturn the JSON now.",
        2400, 0.0, True,
    )
    if not res.ok:
        return {}
    s = res.content or ""
    a, b = s.find("{"), s.rfind("}")
    if a < 0 or b <= a:
        return {}
    try:
        return json.loads(s[a:b + 1])
    except Exception:
        return {}


@app.post("/api/onboarding/from_audio")
async def onboarding_from_audio(request: Request) -> JSONResponse:
    """Path 3c: long-form audio (up to ~24h) becomes a populated
    profile. The audio is transcribed locally with parakeet-mlx using
    chunk_duration 120s + overlap 15s, the broker is asked to extract
    a UserProfile from the transcript, and the result is persisted via
    _save_profile + _seed_profile_memory (same boundary as the
    scripted onboarding).
    """
    raw = await request.body()
    if not raw:
        return JSONResponse({"ok": False, "error": "empty upload"},
                            status_code=400)
    ctype = (request.headers.get("content-type") or "").split(";", 1)[0]
    suffix = {
        "audio/mpeg": ".mp3", "audio/mp3": ".mp3",
        "audio/wav": ".wav", "audio/x-wav": ".wav",
        "audio/aiff": ".aiff", "audio/x-aiff": ".aiff",
        "audio/mp4": ".m4a", "audio/x-m4a": ".m4a",
        "audio/flac": ".flac",
    }.get(ctype, ".audio")

    import tempfile
    try:
        with tempfile.TemporaryDirectory(prefix="anticipy-onbaud-") as td:
            in_path = Path(td) / f"intake{suffix}"
            in_path.write_bytes(raw)
            asr = _long_form_transcribe(
                in_path,
                chunk_duration=120.0,
                overlap_duration=15.0,
            )
            transcript_text = asr["text"]
            if not transcript_text:
                return JSONResponse(
                    {"ok": False,
                     "error": "transcript empty after ASR",
                     "elapsed_s": asr["elapsed_s"],
                     "bytes": len(raw)},
                    status_code=500,
                )
            extracted = _extract_profile_from_transcript(transcript_text)
            if not extracted:
                return JSONResponse(
                    {"ok": False,
                     "error": "broker returned no profile JSON",
                     "transcript_snippet": transcript_text[:240],
                     "transcript_chars": len(transcript_text)},
                    status_code=500,
                )
            prof = _profile_from_json(extracted)
            # Reuse the existing email/contact repair pass against a
            # synthesized transcript so the same hardening that fixes
            # name->email mapping for the scripted path also helps the
            # audio path. We feed the ASR output through as if it were
            # a single WEARER turn.
            _SESS["transcript"] = [
                {"speaker_id": "WEARER", "text": transcript_text}
            ]
            _repair_profile_from_onboarding(prof)
            _SESS["profile_obj"] = prof
            pj = _profile_json()
            # recurring_topics is path 3c specific extra context; keep
            # it visible in the response and stash it in the saved
            # profile JSON for the UI to surface, without mutating the
            # frozen UserProfile dataclass.
            recurring = [str(x) for x in (extracted.get("recurring_topics") or [])]
            pj["recurring_topics"] = recurring
            pj["pronoun_map"] = _infer_pronoun_map_from_transcript(
                pj.get("people") or {}
            )
            try:
                from app.anticipy import onboarding as OB
                pj["well_populated"] = OB.profile_is_well_populated(prof)
            except Exception:
                pj["well_populated"] = bool(prof.name and prof.people)
            _SESS["profile"] = pj
            _seed_profile_memory(prof)
            cloud_sync = _save_profile()
            # _save_profile reads from _SESS["profile"] so recurring_topics
            # already lands in the persisted JSON.
            return JSONResponse({
                "ok": True,
                "bytes": len(raw),
                "content_type": ctype or "application/octet-stream",
                "transcript_chars": len(transcript_text),
                "transcript_snippet": transcript_text[:600],
                "elapsed_s": asr["elapsed_s"],
                "profile": pj,
                "cloud_sync": cloud_sync,
            })
    except Exception as e:
        return JSONResponse(
            {"ok": False, "error": f"{type(e).__name__}: {e}"},
            status_code=500,
        )


# --------------------------------------------------------------------------
# microphone permission probe
# --------------------------------------------------------------------------

def _mac_mic_permission(timeout_s: float = 10.0) -> tuple[bool, str]:
    """Ask macOS for microphone access before PortAudio opens the device.

    Without this native request, the packaged app can wedge inside
    sounddevice/PortAudio while TCC is still "not determined".
    """
    if sys.platform != "darwin":
        return True, "not macOS"
    try:
        import Foundation
        from AVFoundation import AVCaptureDevice, AVMediaTypeAudio
    except Exception as e:
        return True, f"permission preflight unavailable: {type(e).__name__}: {e}"

    names = {0: "not_determined", 1: "restricted",
             2: "denied", 3: "authorized"}
    try:
        status = int(AVCaptureDevice.authorizationStatusForMediaType_(
            AVMediaTypeAudio))
    except Exception as e:
        return True, f"permission status unavailable: {type(e).__name__}: {e}"
    if status == 3:
        return True, "authorized"
    if status in (1, 2):
        return False, names.get(status, str(status))

    granted_event = threading.Event()
    result = {"granted": False}

    def done(granted: bool) -> None:
        result["granted"] = bool(granted)
        granted_event.set()

    try:
        AVCaptureDevice.requestAccessForMediaType_completionHandler_(
            AVMediaTypeAudio, done)
    except Exception as e:
        return False, f"request failed: {type(e).__name__}: {e}"

    deadline = time.time() + timeout_s
    while not granted_event.is_set() and time.time() < deadline:
        Foundation.NSRunLoop.currentRunLoop().runMode_beforeDate_(
            Foundation.NSDefaultRunLoopMode,
            Foundation.NSDate.dateWithTimeIntervalSinceNow_(0.1))
    if not granted_event.is_set():
        return False, "permission prompt timed out"
    return bool(result["granted"]), "authorized" if result["granted"] else "denied"


@app.get("/api/mic/probe")
def mic_probe() -> JSONResponse:
    """A short REAL capture: triggers the macOS microphone permission
    prompt and proves the device opens. Honest on failure.
    """
    try:
        allowed, mic_status = _mac_mic_permission()
        if not allowed:
            return JSONResponse({"ok": False,
                                 "error": f"microphone permission {mic_status}"})

        def capture():
            import numpy as np
            import sounddevice as sd
            sr = 16000
            rec = sd.rec(int(0.4 * sr), samplerate=sr, channels=1,
                         dtype="float32")
            sd.wait()
            wav = np.asarray(rec).reshape(-1)
            try:
                dev = str(sd.query_devices(kind="input").get("name",
                                                             "input"))
            except Exception:
                dev = "default input"
            return wav, dev

        import numpy as np
        wav, dev = _with_timeout("microphone probe", 8.0, capture)
        rms = float(np.sqrt(np.mean(wav ** 2)) or 0.0)
        return JSONResponse({"ok": True, "rms": rms,
                             "samples": int(wav.size), "device": dev,
                             "permission": mic_status})
    except Exception as e:
        return JSONResponse({"ok": False,
                             "error": f"{type(e).__name__}: {e}"})


# --------------------------------------------------------------------------
# CONTINUOUS always-on listening
# --------------------------------------------------------------------------

_LISTEN: dict = {
    "on": False, "stream": None, "proc": None,
    "lock": threading.Lock(),
    "buf": collections.deque(), "buf_lock": threading.Lock(),
    "level": 0.0, "windows": 0, "recent": [], "pending": None,
    "started_at": None, "error": None, "acted": None,
    "audio_device": None, "sample_rate": None, "capture_id": None,
    "source_mode": None,
}


def _audio_cb(indata, frames, time_info, status) -> None:
    import numpy as np
    chunk = np.asarray(indata).reshape(-1).copy()
    with _LISTEN["buf_lock"]:
        _LISTEN["buf"].append(chunk)
    try:
        _LISTEN["level"] = float(np.sqrt(np.mean(chunk ** 2)) or 0.0)
    except Exception:
        pass


def _run_pipeline(text: str):
    """The real frozen reasoning + proactive_day pipeline (memory draw
    armed). Returns (outcome, proposal|None).
    """
    _install_memory_draw()
    from app.proactive_day import pipeline
    from app.proactive_day import world as W
    manifest = {"events": [{
        "ev_id": "live", "category": "VERBAL_PROMISE", "label": "ACTION",
        "ts": 9.0, "place": "home", "speaker": "WEARER", "text": text,
        "slots": {}, "snr_tier": "clean", "reach": "free",
        "urgency": "hours", "world_done_at": None, "world_done": None,
        "cancels_ev": None, "defer_until": None, "shorthand_key": None,
        "expansion": None, "first_occurrence": False}]}
    world = W.populated()
    res = pipeline.run_day(manifest, world)
    outcome = res[0].outcome if res else "?"
    proposal = world.outbound[0].body if world.outbound else None
    return outcome, proposal


def _proactive_proposal_from_item(item: dict) -> str:
    transcript = str(item.get("transcript") or "").strip()
    if transcript:
        return f"This is due now: {transcript}"
    return "A scheduled Anticipy item is due now."


def _surface_fired_proactive_items() -> dict:
    """Fire due wall-clock items and surface one pending proposal."""
    try:
        from app.product.scheduler import get_scheduler
        result = get_scheduler().fire_due()
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}",
                "fired": [], "fired_count": 0}
    fired = result.get("fired") if isinstance(result, dict) else []
    if fired:
        item = fired[0]
        if isinstance(item, dict):
            with _LISTEN["lock"]:
                if not _LISTEN.get("pending"):
                    _LISTEN["pending"] = {
                        "instruction": str(item.get("transcript") or ""),
                        "proposal": _proactive_proposal_from_item(item),
                        "plan": item.get("plan"),
                        "scheduled": item,
                        "proactive": True,
                        "ts": time.time(),
                    }
    return {"ok": True, **result}


def _schedule_proactive_from_utterance(text: str, rec: dict) -> dict | None:
    """Schedule future references from every post-ASR input source."""
    try:
        from app.product.scheduler import get_scheduler
        plan = rec.get("plan")
        if not isinstance(plan, dict):
            pending = _LISTEN.get("pending") or {}
            plan = pending.get("plan") if isinstance(pending, dict) else None
        scheduled = get_scheduler().schedule_from_transcript(
            text, plan if isinstance(plan, dict) else None)
        if scheduled:
            rec["scheduled"] = scheduled
        return scheduled
    except Exception as e:
        rec["scheduled_error"] = f"{type(e).__name__}: {e}"
        return None


_AUDIO_CTYPE_SUFFIX = {
    "audio/mpeg": ".mp3", "audio/mp3": ".mp3",
    "audio/wav": ".wav", "audio/x-wav": ".wav", "audio/wave": ".wav",
    "audio/aiff": ".aiff", "audio/x-aiff": ".aiff",
    "audio/mp4": ".m4a", "audio/x-m4a": ".m4a",
    "audio/flac": ".flac", "audio/x-flac": ".flac",
    "audio/ogg": ".ogg",
}


def _audio_suffix_for(ctype: str | None, filename: str | None) -> str:
    """Pick a temp-file suffix from content-type, falling back to the
    filename extension and finally to ".audio" (which still lets ffmpeg
    sniff the container).
    """
    if ctype:
        ct = ctype.split(";", 1)[0].strip().lower()
        if ct in _AUDIO_CTYPE_SUFFIX:
            return _AUDIO_CTYPE_SUFFIX[ct]
    if filename:
        ext = Path(filename).suffix.lower()
        if ext in {".wav", ".wave", ".mp3", ".aiff", ".aif", ".m4a", ".mp4",
                   ".flac", ".ogg", ".opus", ".webm"}:
            return ".wav" if ext == ".wave" else ext
    return ".audio"


def _parse_multipart_audio(body: bytes, content_type: str) -> tuple[bytes, str, str]:
    """Parse a multipart/form-data body, returning the first part whose
    Content-Disposition has a filename or whose field name is audio/
    file/upload. Returns (bytes, part_content_type, filename) or
    (b"", "", "") if nothing usable was found.

    Implemented against the body bytes directly (no python-multipart
    dependency) so the engine does not need a new pip install to accept
    standard requests / curl multipart uploads.
    """
    # Extract boundary from header. RFC 7578: Content-Type:
    # multipart/form-data; boundary=...
    boundary = None
    for part in content_type.split(";"):
        kv = part.strip()
        if kv.lower().startswith("boundary="):
            boundary = kv.split("=", 1)[1].strip().strip('"')
            break
    if not boundary:
        return b"", "", ""
    delim = b"--" + boundary.encode("latin-1")
    # Split on the boundary delimiter. The first chunk is the
    # preamble (often empty); each subsequent chunk is a part body
    # ending with the next boundary line. The final chunk starts with
    # b"--\r\n" (closing boundary) and should be ignored.
    chunks = body.split(delim)
    for chunk in chunks[1:]:
        if chunk.startswith(b"--"):  # closing delimiter
            break
        # Each part begins with \r\n then headers, blank line, then body.
        if chunk.startswith(b"\r\n"):
            chunk = chunk[2:]
        if chunk.endswith(b"\r\n"):
            chunk = chunk[:-2]
        head_end = chunk.find(b"\r\n\r\n")
        if head_end < 0:
            continue
        header_block = chunk[:head_end].decode("latin-1", errors="replace")
        data = chunk[head_end + 4:]
        # Strip any trailing CRLF before the next boundary.
        if data.endswith(b"\r\n"):
            data = data[:-2]
        cd = ""
        part_ctype = ""
        for line in header_block.splitlines():
            lower = line.lower()
            if lower.startswith("content-disposition:"):
                cd = line.split(":", 1)[1].strip()
            elif lower.startswith("content-type:"):
                part_ctype = line.split(":", 1)[1].strip()
        if not cd:
            continue
        # Parse name="..." and filename="..." from the disposition.
        name = ""
        filename = ""
        for piece in cd.split(";"):
            piece = piece.strip()
            if piece.startswith("name="):
                name = piece.split("=", 1)[1].strip().strip('"')
            elif piece.startswith("filename="):
                filename = piece.split("=", 1)[1].strip().strip('"')
        if filename or name in {"audio", "file", "upload"}:
            return data, part_ctype, filename
    return b"", "", ""


async def _read_audio_request(request: Request) -> tuple[bytes, str, str]:
    """Read uploaded audio from either raw body or multipart/form-data.

    Returns (raw_bytes, content_type, filename). The verifier and many
    HTTP clients (python requests with files=..., curl -F) send
    multipart with a single "audio" field; tools that POST the raw
    bytes set Content-Type: audio/wav directly. Supporting both keeps
    /api/stt/local and /api/listen/upload usable from both shapes
    without forcing every caller to switch.
    """
    raw_ctype = request.headers.get("content-type", "") or ""
    base_ctype = raw_ctype.split(";", 1)[0].strip().lower()
    body = await request.body()

    if base_ctype.startswith("multipart/"):
        data, part_ctype, filename = _parse_multipart_audio(body, raw_ctype)
        if data:
            return data, part_ctype or raw_ctype, filename
        return b"", raw_ctype, ""

    return body or b"", raw_ctype, ""


def _load_upload_audio(path: Path):
    """Decode user-uploaded audio to the same 16k mono ndarray ASR expects."""
    from app.audiostack import audio as A

    def _converter_candidates(name: str) -> list[str]:
        found = shutil.which(name)
        candidates = [found] if found else []
        for p in (f"/opt/homebrew/bin/{name}", f"/usr/local/bin/{name}",
                  f"/usr/bin/{name}"):
            if p not in candidates and Path(p).exists():
                candidates.append(p)
        return candidates

    def _convert() -> tuple[object | None, list[str]]:
        out = path.with_suffix(".asr.wav")
        converters = []
        for ffmpeg in _converter_candidates("ffmpeg"):
            converters.append([
                ffmpeg, "-y", "-loglevel", "error", "-i", str(path),
                "-ac", "1", "-ar", str(A.SR), str(out),
            ])
        for afconvert in _converter_candidates("afconvert"):
            converters.append([
                afconvert, "-f", "WAVE", "-d", f"LEI16@{A.SR}",
                "-c", "1", str(path), str(out),
            ])
        errors: list[str] = []
        for cmd in converters:
            try:
                subprocess.run(cmd, capture_output=True, check=True, timeout=30)
                return A.load_wav(out), errors
            except Exception as e:
                errors.append(f"{Path(cmd[0]).name}:{type(e).__name__}:{e}")
        return None, errors

    if path.suffix.lower() not in {".wav", ".wave"}:
        wav, errors = _convert()
        if wav is not None:
            return wav
        raise RuntimeError("audio conversion failed; " + " | ".join(errors))

    try:
        return A.load_wav(path)
    except Exception as first_error:
        errors = [f"direct:{type(first_error).__name__}:{first_error}"]
        wav, convert_errors = _convert()
        if wav is not None:
            return wav
        errors.extend(convert_errors)
        raise RuntimeError("audio decode failed; " + " | ".join(errors))


def _transcribe_uploaded_audio_sync(
    raw: bytes,
    ctype: str,
    filename: str,
    *,
    feed_pipeline: bool,
) -> tuple[int, dict]:
    """Decode/transcribe uploaded audio off the FastAPI event loop.

    Parakeet/MLX work can take minutes on long or cold-start audio. Running it
    directly in an async route blocks the whole local engine, including
    /health. This worker is called through asyncio.to_thread and guarded by a
    single upload-ASR lock so one slow upload cannot stack multiple model jobs.
    """
    if not _UPLOAD_ASR_LOCK.acquire(blocking=False):
        return 429, {
            "ok": False,
            "error": "upload ASR is already running; retry after the current audio finishes",
            "source": "upload-asr",
        }
    suffix = _audio_suffix_for(ctype, filename)
    try:
        import tempfile
        import numpy as np

        from app.audiostack import audio as A
        with tempfile.TemporaryDirectory(prefix="anticipy-upload-") as td:
            in_path = Path(td) / f"upload{suffix}"
            in_path.write_bytes(raw)
            wav = _load_upload_audio(in_path)
            rms = float(np.sqrt(np.mean(wav ** 2)) or 0.0)
            asr = A.asr_tokens(wav)
        raw_text = (asr.text or "").strip()
        text, normalizations = _normalize_post_asr_text(raw_text)
        base = {
            "ok": True,
            "source": "upload-asr" if feed_pipeline else "stt-local",
            "bytes": len(raw),
            "content_type": ctype or "application/octet-stream",
            "transcript": text,
            "raw_asr_transcript": raw_text,
            "asr_normalized": raw_text != text,
            "asr_normalizations": normalizations,
            "model": "parakeet-mlx",
            "tokens": len(getattr(asr, "tokens", []) or []),
            "mean_confidence": round(asr.mean_conf(), 4),
        }
        if not feed_pipeline:
            base["text"] = text
            return 200, base

        rec = _process_utterance(text, rms, "upload-asr", {
            "raw_asr_transcript": raw_text,
            "asr_normalized": raw_text != text,
            "asr_normalizations": normalizations,
            "content_type": ctype or "application/octet-stream",
            "filename": filename,
            "bytes": len(raw),
            "mean_confidence": round(asr.mean_conf(), 4),
        })
        return 200, {
            "ok": True, "source": "upload-asr", "bytes": len(raw),
            "content_type": ctype or "application/octet-stream",
            "transcript": rec["transcript"], "window": rec["window"],
            "raw_asr_transcript": rec.get("raw_asr_transcript"),
            "asr_normalized": rec.get("asr_normalized"),
            "asr_normalizations": rec.get("asr_normalizations") or [],
            "ingest_id": rec.get("ingest_id"),
            "outcome": rec.get("outcome"), "proposal": rec.get("proposal"),
            "plan": rec.get("plan"), "memory": rec.get("memory"),
            "scheduled": rec.get("scheduled"),
            "proactive_due": rec.get("proactive_due"),
            "resolution_trace_sync": rec.get("resolution_trace_sync"),
            "v7_artifacts": rec.get("v7_artifacts"),
            "v7_decision": rec.get("v7_decision"),
            "pending": _LISTEN.get("pending"),
        }
    except Exception as e:
        return 500, {
            "ok": False,
            "error": f"{type(e).__name__}: {e}",
            "source": "upload-asr",
        }
    finally:
        _UPLOAD_ASR_LOCK.release()


async def _transcribe_uploaded_audio_bounded(
    raw: bytes,
    ctype: str,
    filename: str,
    *,
    feed_pipeline: bool,
) -> tuple[int, dict]:
    timeout_s = _upload_asr_timeout_seconds()
    try:
        return await asyncio.wait_for(
            asyncio.to_thread(
                _transcribe_uploaded_audio_sync,
                raw,
                ctype,
                filename,
                feed_pipeline=feed_pipeline,
            ),
            timeout=timeout_s,
        )
    except asyncio.TimeoutError:
        return 504, {
            "ok": False,
            "error": f"upload ASR timed out after {timeout_s:.1f}s",
            "source": "upload-asr",
            "timeout_seconds": timeout_s,
        }


def _recent_transcripts(limit: int = 8) -> list[str]:
    with _LISTEN["lock"]:
        rows = list(_LISTEN.get("recent") or [])[:limit]
    out = []
    for r in rows:
        t = str(r.get("transcript") or "").strip()
        if t:
            out.append(t)
    return out


def _is_actionish(text: str) -> bool:
    low = (text or "").lower()
    return bool(re.search(
        r"\b(should|need|needs|owe|draft|email|mail|send|share|"
        r"get .* over|follow up|let .* know|schedule|calendar|"
        r"book|remind|tell|ask)\b", low))


def _extract_email(text: str) -> str:
    m = re.search(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", text or "")
    return m.group(0) if m else ""


def _write_decline_receipt(rec: dict) -> None:
    """Persist a local receipt for trace-reader competent-decline proof."""
    plan = rec.get("plan") if isinstance(rec.get("plan"), dict) else {}
    path = Path.home() / ".anticipy" / "declined_actions" / "latest.jsonl"
    entry = {
        "ts": rec.get("ts"),
        "ingest_id": rec.get("ingest_id"),
        "source": rec.get("source"),
        "instruction": rec.get("transcript"),
        "text": rec.get("transcript"),
        "outcome": rec.get("outcome"),
        "intent": plan.get("intent") or rec.get("intent"),
        "proposal": rec.get("proposal") or plan.get("proposal"),
        "plan": plan,
        "decline": bool(rec.get("decline") or plan.get("mode") == "decline"),
        "competent_decline": bool(
            rec.get("competent_decline")
            or plan.get("competent_decline")
            or plan.get("mode") == "decline"
        ),
        "d16_receipt": plan.get("d16_receipt"),
        "blocked_services": plan.get("blocked_services"),
        "unchanged_state_boundary": plan.get("unchanged_state_boundary"),
        "unchanged": plan.get("unchanged"),
    }
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, sort_keys=True) + "\n")
    except Exception:
        pass


def _v7_artifact_root() -> Path:
    return Path.home() / ".anticipy" / "v7"


def _append_v7_jsonl(name: str, payload: dict) -> str:
    path = _v7_artifact_root() / name
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, sort_keys=True) + "\n")
        return str(path)
    except Exception:
        return ""


def _v7_input_mode(source: str, capture: dict | None) -> str:
    capture = capture if isinstance(capture, dict) else {}
    source_mode = str(capture.get("source_mode") or "").strip()
    if source_mode:
        return source_mode
    if source == "upload-asr":
        return "mp3_upload" if "mpeg" in str(capture.get("content_type") or "") else "audio_upload"
    if source == "asr-transcript":
        return "text_transcript"
    if source == "mic-asr":
        device = capture.get("audio_device") if isinstance(capture.get("audio_device"), dict) else {}
        kind = str(device.get("kind") or "").lower() if isinstance(device, dict) else ""
        return "external_microphone" if kind and kind != "builtin" else "computer_microphone"
    return source or "unknown"


def _decision_mode_from_record(rec: dict) -> str:
    plan = rec.get("plan") if isinstance(rec.get("plan"), dict) else {}
    if rec.get("decline") or plan.get("mode") == "decline" or rec.get("outcome") == "DECLINED":
        return "decline"
    if rec.get("clarify") or plan.get("mode") == "clarify":
        return "ask_first"
    if rec.get("outcome") in {"ACTED", "CONFIRMED"}:
        return "execute_notify"
    if rec.get("outcome") == "IGNORED":
        return "silent_noop"
    if rec.get("proposal") or plan:
        return "ask_first"
    return "silent_noop"


def _write_v7_inference_artifacts(rec: dict, capture: dict | None) -> None:
    """Persist V7 common-boundary receipts for all input modes.

    These artifacts are not used as sole proof of user-visible behavior. They
    prove that MP3/upload, typed transcript, computer mic, and external mic enter
    the same post-ASR normalized-input and decision boundary.
    """
    capture = capture if isinstance(capture, dict) else {}
    ingest_id = str(rec.get("ingest_id") or "")
    ts = rec.get("ts") or time.time()
    input_mode = _v7_input_mode(str(rec.get("source") or ""), capture)
    text = str(rec.get("transcript") or "")
    plan = rec.get("plan") if isinstance(rec.get("plan"), dict) else {}
    base = {
        "schema": "anticipy.inference_event.v7",
        "ts": ts,
        "ingest_id": ingest_id,
        "source": rec.get("source"),
        "input_mode": input_mode,
        "public_build_commit": os.environ.get("ANTICIPY_BUILD_COMMIT", ""),
        "device_engine": "user-device",
    }
    normalized = {
        **base,
        "schema": "anticipy.normalized_input.v7",
        "window": {
            "turns": [
                {
                    "speaker": "user",
                    "text": text,
                    "asr_confidence": capture.get("mean_confidence"),
                    "start_ms": capture.get("start_ms", 0),
                    "end_ms": capture.get("end_ms", 0),
                }
            ]
        },
        "capture": {
            "content_type": capture.get("content_type"),
            "filename": capture.get("filename"),
            "bytes": capture.get("bytes"),
            "audio_device": capture.get("audio_device"),
            "raw_asr_transcript": capture.get("raw_asr_transcript"),
            "asr_normalized": capture.get("asr_normalized"),
            "asr_normalizations": capture.get("asr_normalizations") or [],
        },
    }
    event = {
        **base,
        "actionable_probability": 0.0 if rec.get("outcome") == "IGNORED" else 1.0,
        "want": {
            "type": plan.get("intent") or rec.get("intent") or rec.get("outcome"),
            "description": text,
            "slots": plan,
            "evidence_spans": [text] if text else [],
        },
        "risk": {
            "tier": 3 if _decision_mode_from_record(rec) in {"ask_first", "decline"} else 1,
            "reason": plan.get("d16_receipt") or rec.get("outcome") or "",
        },
    }
    decision = {
        **base,
        "schema": "anticipy.decision.v7",
        "decision": {
            "mode": _decision_mode_from_record(rec),
            "message": rec.get("proposal") or plan.get("proposal") or "",
        },
        "outcome": rec.get("outcome"),
        "plan": plan,
        "surface_proof_required": True,
    }
    paths = {
        "normalized_inputs": _append_v7_jsonl("normalized_inputs.jsonl", normalized),
        "inference_events": _append_v7_jsonl("inference_events.jsonl", event),
        "decisions": _append_v7_jsonl("decisions.jsonl", decision),
    }
    rec["v7_artifacts"] = paths
    rec["v7_normalized_input"] = normalized
    rec["v7_decision"] = decision


def _unsupported_canvas_decline(instruction: str) -> dict | None:
    """Detect design/canvas edits we cannot safely perform yet.

    A no-email boundary often contains words like "email" or "send"; this
    guard runs before the email planner so those safety words cannot reroute a
    canvas edit into a Gmail clarification.
    """
    text = re.sub(r"\s+", " ", instruction or "").strip()
    if not text:
        return None
    low = text.lower()
    surface_labels: list[str] = []
    for label, pattern in (
            ("Adobe Express", r"\badobe\s+express\b"),
            ("Canva", r"\bcanva\b"),
            ("Figma", r"\bfigma\b"),
            ("canvas", r"\bcanvas\b"),
    ):
        if re.search(pattern, low):
            surface_labels.append(label)
    visual_work = re.search(
        r"\b(flyer|poster|brochure|banner|invite|invitation|design|"
        r"graphic|mockup|sponsor screen|social card)\b",
        low,
    )
    if not surface_labels and not visual_work:
        return None
    edit = re.search(
        r"\b(edit|fix|update|change|replace|revise|tweak|adjust|make)\b",
        low,
    ) or re.search(r"\b(so it says?|instead of|add|remove)\b", low)
    if not edit:
        return None

    target = "design"
    for noun in ("flyer", "poster", "brochure", "banner", "invite",
                 "invitation", "mockup", "graphic", "sponsor screen",
                 "social card"):
        if re.search(rf"\b{noun}\b", low):
            target = noun
            break
    blocked_services = surface_labels or ["canvas"]
    surface_text = ", ".join(blocked_services)
    proposal = (
        f"I can't safely edit that visible {surface_text} {target} yet. I "
        "cannot prove the design is editable, the requested text changes are "
        "applied, or the rest of the design is unchanged on your real surface. "
        "I will not export, not publish, not share, and not email anything. "
        f"Requested change to preserve: {text}"
    )
    return {
        "mode": "decline",
        "intent": "canvas_edit",
        "thing": target,
        "task": "",
        "proposal": proposal,
        "competent_decline": True,
        "d16_receipt": "no-action canvas edit decline",
        "blocked_services": blocked_services,
        "unchanged_state_boundary": (
            f"{surface_text} {target}; source context; export/share/email "
            "state; no extra visible changes"
        ),
        "unchanged": [
            f"{surface_text} {target}",
            "source context",
            "export/share/email state",
            "surrounding design",
        ],
        "prohibited_actions": [
            "edit design",
            "export",
            "publish",
            "share",
            "email",
        ],
    }


def _unsafe_ecommerce_decline(instruction: str) -> dict | None:
    """Decline shopping cart-prep when product safety cannot be proven.

    Shopping requests have account and payment side effects even when the user
    says not to buy. Until the engine can prove the actual retail product,
    delivery date, quantity, price, cart, checkout/payment, and shipping or
    pickup state on the user's visible surface, it must surface a no-action
    decline instead of creating a generic proposal.
    """
    text = re.sub(r"\s+", " ", instruction or "").strip()
    if not text:
        return None
    low = text.lower()
    retail_surfaces: list[str] = []
    for label, pattern in (
            ("Shopify", r"\bshopify\b"),
            ("Shopify Admin", r"\bshopify\s+admin\b"),
            ("Amazon", r"\bamazon(?:\.com)?\b"),
            ("Target", r"\btarget(?:\.com)?\b"),
            ("Walmart", r"\bwalmart(?:\.com)?\b"),
            ("Costco", r"\bcostco(?:\.com)?\b"),
            ("Best Buy", r"\bbest\s+buy\b"),
            ("Home Depot", r"\bhome\s+depot\b"),
            ("Lowe's", r"\blowe'?s\b"),
            ("Staples", r"\bstaples\b"),
            ("Office Depot", r"\boffice\s+depot\b"),
            ("Michaels", r"\bmichaels\b"),
            ("Joann", r"\bjoann\b"),
            ("Walgreens", r"\bwalgreens\b"),
            ("CVS", r"\bcvs\b"),
            ("Kroger", r"\bkroger\b"),
            ("Whole Foods", r"\bwhole\s+foods\b"),
            ("Safeway", r"\bsafeway\b"),
            ("IKEA", r"\bikea\b"),
            ("Wayfair", r"\bwayfair\b"),
            ("Etsy", r"\betsy\b"),
            ("Etsy Shop Manager", r"\betsy\s+shop\s+manager\b"),
            ("eBay", r"\bebay\b"),
            ("Instacart", r"\binstacart\b"),
            ("ShipStation", r"\bshipstation\b"),
            ("Stripe", r"\bstripe\b"),
            ("PayPal", r"\bpaypal\b"),
            ("retail store", r"\b(?:retail|shopping)\s+(?:site|store)\b"),
            ("online store", r"\bonline\s+(?:shop|store)\b"),
    ):
        if re.search(pattern, low):
            retail_surfaces.append(label)
    generic_retail = re.search(
        r"\b(?:retailer|retail site|retail store|online shop|online store|"
        r"shopping site|shopping store|e-?commerce site|web store)\b",
        low,
    )
    cart_prep = re.search(
        r"\b(?:put|add|place|move|build|make|create|assemble|fill|prep|"
        r"prepare|ready|load|set\s+up)\b.{0,100}\b(?:cart|basket)\b",
        low,
    ) or re.search(
        r"\b(?:cart|basket)\b.{0,100}\b(?:put|add|prep|prepare|ready|"
        r"build|make|create|assemble|fill|load|set\s+up)\b",
        low,
    )
    commerce_admin = re.search(
        r"\b(?:shopify|etsy|shipstation|stripe|paypal|order|buyer|customer|"
        r"shipping\s+address|address|label|refund|inventory|checkout|"
        r"customer\s+message|reply\s+draft|message\s+draft|proof\s+summary)\b",
        low,
    ) and re.search(
        r"\b(?:check|verify|prove|compare|mismatch|prepare|draft|reply|"
        r"message|update|change|void|refund|buy|send)\b",
        low,
    )
    if (retail_surfaces or generic_retail) and commerce_admin and not cart_prep:
        blocked_services = retail_surfaces or ["e-commerce"]
        surface_text = ", ".join(dict.fromkeys(blocked_services))
        proposal = (
            f"I can't safely handle that {surface_text} order or customer "
            "reply yet. I cannot prove the real signed-in order page, buyer, "
            "item, shipping address, customer message, label, checkout, "
            "payment, inventory, or mail state from the visible user surface. "
            "I will not change an address, void or buy labels, refund, update "
            "inventory, open checkout, send mail, or draft a customer reply "
            f"without those receipts. Requested e-commerce work to preserve: {text}"
        )
        return {
            "mode": "decline",
            "intent": "ecommerce_admin_surface_missing",
            "thing": f"{surface_text} order/customer reply",
            "task": "",
            "proposal": proposal,
            "competent_decline": True,
            "d16_receipt": "no-action e-commerce admin decline",
            "blocked_services": blocked_services,
            "unchanged_state_boundary": (
                f"{surface_text} order, customer message, shipping label, "
                "checkout, payment, inventory, and mail state; no extra "
                "visible changes"
            ),
            "unchanged": [
                "order page",
                "customer message",
                "shipping address",
                "shipping labels",
                "checkout state",
                "payment state",
                "inventory state",
                "mail drafts and sends",
            ],
            "prohibited_actions": [
                "change address",
                "void label",
                "buy label",
                "refund",
                "update inventory",
                "open checkout",
                "send mail",
                "draft customer reply without visible receipts",
            ],
        }
    if not (retail_surfaces or generic_retail) or not cart_prep:
        return None

    surface = retail_surfaces[0] if retail_surfaces else "retail"
    thing = f"{surface} cart"
    proposal = (
        f"I can't safely prepare that {thing} yet. Retail bot protection, "
        "sign-in state, pickup or delivery options, and checkout state may "
        "block reliable proof, and I cannot prove the exact item, quantity, "
        "price, tax or budget fit, substitution choice, cart contents, "
        "checkout state, payment state, or shipping/pickup state on your real "
        "retail surface. Any referenced Gmail, Calendar, sheet, and retail "
        "cart context will remain unchanged; I will not add anything to the "
        "cart, start checkout, pick a substitution, change payment, and will "
        "not buy anything. "
        f"Requested shopping constraint: {text}"
    )
    return {
        "mode": "decline",
        "intent": "ecommerce_cart_prep",
        "thing": thing,
        "task": "",
        "proposal": proposal,
        "retail_surface": surface,
        "d16_receipt": "no-action retail cart-prep decline",
        "unchanged": [
            "Gmail source thread",
            "Calendar context",
            "sheet context",
            "retail cart",
            "checkout state",
            "payment state",
        ],
        "prohibited_actions": [
            "add item to cart",
            "start checkout",
            "pick substitution",
            "change payment",
            "buy",
        ],
    }


def _unsupported_crm_saas_write_decline(instruction: str) -> dict | None:
    """Decline CRM/enterprise SaaS writes until visible-surface proof exists."""
    text = re.sub(r"\s+", " ", instruction or "").strip()
    if not text:
        return None
    low = text.lower()

    surfaces = [
        ("salesforce", r"\bsalesforce\b"),
        ("HubSpot", r"\bhubspot\b"),
        ("Microsoft Dynamics", r"\b(?:microsoft\s+)?dynamics(?:\s+365)?\b"),
        ("Zoho CRM", r"\bzoho(?:\s+crm)?\b"),
        ("Pipedrive", r"\bpipedrive\b"),
        ("Close", r"\b(?:close\.com|close\s+crm)\b"),
        ("Attio", r"\battio\b"),
        ("Gong", r"\bgong\b"),
        ("Clari", r"\bclari\b"),
        ("Outreach", r"\boutreach\b"),
        ("Salesloft", r"\bsalesloft\b"),
        ("ServiceNow", r"\bservice\s*-?\s*now\b"),
        ("Zendesk", r"\bzendesk\b"),
        ("Jira", r"\bjira\b"),
        ("Linear", r"\blinear\b"),
        ("Asana", r"\basana\b"),
        ("Notion", r"\bnotion\b"),
        ("Airtable", r"\bairtable\b"),
        ("Confluence", r"\bconfluence\b"),
        ("monday.com",
         r"\bmonday\.com\b|\bmonday\s+(?:board|item|pulse|workspace)\b"),
        ("Trello", r"\btrello\b"),
        ("ClickUp", r"\bclickup\b"),
    ]
    mentioned: list[str] = []
    for label, pattern in surfaces:
        if re.search(pattern, low):
            mentioned.append(label)
    if not mentioned:
        return None

    write_intent = re.search(
        r"\b(?:add|assign|attach|change|close|comment|convert|create|"
        r"delete|edit|fill|log|mark|move|populate|post|push|record|"
        r"remove|rename|reopen|revise|save|set|submit|sync|tag|update|"
        r"upload|write)\b",
        low,
    ) or re.search(
        r"\b(?:follow[-\s]?up|next\s+step|todo|to[-\s]?do)\b",
        low,
    )
    business_record = re.search(
        r"\b(?:account|case|company|contact|customer|deal|issue|lead|"
        r"note|opportunit(?:y|ies)|record|renewal|stage|status|task|"
        r"ticket)\b",
        low,
    )
    if not write_intent or not business_record:
        return None

    blocked_services = mentioned[:4]
    surface_text = ", ".join(blocked_services)
    proposal = (
        f"I can't safely update {surface_text} or enterprise SaaS records yet. "
        "I cannot prove the exact visible record, field, note, status, owner, "
        "Slack/Gmail source context, or unchanged no-extra-change state on your "
        "real signed-in surface. I will not email, not post, not close, not "
        f"promise, and not write to those services. Requested SaaS change to "
        f"preserve: {text}"
    )
    return {
        "mode": "decline",
        "intent": "crm_saas_write",
        "thing": surface_text,
        "task": "",
        "proposal": proposal,
        "competent_decline": True,
        "d16_receipt": "no-action CRM/SaaS write decline",
        "blocked_services": blocked_services,
        "unchanged_state_boundary": (
            f"{surface_text} records; source context; field/note/status/owner "
            "state; no extra visible changes"
        ),
        "unchanged": [
            f"{surface_text} records",
            "source context",
            "field/note/status/owner state",
            "no-extra-change visible state",
        ],
        "prohibited_actions": [
            "email",
            "post",
            "close",
            "promise",
            "write",
        ],
    }


def _competent_decline_for_text(instruction: str) -> dict | None:
    return (
        _unsafe_ecommerce_decline(instruction)
        or _unsupported_canvas_decline(instruction)
        or _unsupported_crm_saas_write_decline(instruction)
        or _unsupported_native_calendar_reminder_decline(instruction)
    )


def _apply_competent_decline(rec: dict, text: str, decline: dict) -> None:
    rec["outcome"] = "DECLINED"
    rec["proposal"] = str(decline.get("proposal") or "")
    rec["plan"] = decline
    rec["decline"] = True
    rec["competent_decline"] = True
    rec["d16_receipt"] = decline.get("d16_receipt")
    rec["intent"] = decline.get("intent")
    rec["memory"] = _memory_write(text, "latent_intent")
    _LISTEN["pending"] = {
        "instruction": text,
        "proposal": rec["proposal"],
        "competent_decline": True,
        "decline": True,
        "plan": decline,
        "ts": rec["ts"],
    }
    _write_decline_receipt(rec)


def _unsupported_native_calendar_reminder_decline(
        instruction: str) -> dict | None:
    """Decline native Calendar/Reminders work until AX proof exists."""
    text = re.sub(r"\s+", " ", instruction or "").strip()
    if not text:
        return None
    low = text.lower()

    reminder = re.search(r"\b(remind me|reminder|reminders)\b", low)
    eventish = re.search(
        r"\b(set up|schedule|calendar|event|appointment|meeting|from)\b",
        low,
    ) and re.search(
        r"\b(today|tomorrow|monday|tuesday|wednesday|thursday|friday|"
        r"saturday|sunday|jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|"
        r"apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|"
        r"sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?|"
        r"\d{1,2}:\d{2}|\d{1,2}\s*(?:am|pm))\b",
        low,
    )
    native_surface = re.search(
        r"\b(calendar|reminders|reminder|invite|invites)\b", low,
    )
    no_browser_workaround = re.search(
        r"\b(don't|do not|dont)\b.{0,80}\b(email|invite|send)\b",
        low,
    )
    if not (reminder and eventish and (native_surface or no_browser_workaround)):
        return None

    proposal = (
        "I can't safely create native Calendar events or Reminders yet. "
        "I cannot prove the Apple Mail source thread, Preview/PDF source, "
        "event, time, location, reminder, or unchanged no-invite state on your "
        "visible Mac Calendar/Reminders surfaces. If the source is missing, "
        "unreadable, blocked, conflicting, or ambiguous, I must decline. I "
        "will not create anything, not contact anyone, and not edit the PDF. "
        f"Requested Calendar/Reminder work to preserve: {text}"
    )
    return {
        "mode": "decline",
        "intent": "native_calendar_reminder",
        "thing": "Calendar/Reminders",
        "task": "",
        "proposal": proposal,
    }


def _person_label(value: str) -> str:
    s = re.sub(r"<[^>]+>", "", value or "")
    s = re.sub(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", "", s)
    s = re.sub(r"\([^)]*\)", "", s).strip(" ,;-")
    return s.split(",")[0].strip() or value.strip()


def _profile_people() -> list[dict]:
    prof = _SESS.get("profile_obj")
    people = []
    if prof is None:
        return people
    for rel, val in (getattr(prof, "people", {}) or {}).items():
        value = str(val)
        people.append({
            "relation": str(rel), "value": value,
            "label": _person_label(value), "email": _extract_email(value),
        })
    return people


def _contains_explicit_person(text: str) -> bool:
    low = (text or "").lower()
    for p in _profile_people():
        vals = [p["relation"], p["label"], p["value"], p["email"]]
        for v in vals:
            if v and str(v).lower() in low:
                return True
    return False


def _significant_tokens(text: str) -> list[str]:
    stop = {"the", "and", "for", "with", "that", "this", "over", "before",
            "after", "today", "tomorrow", "week", "ends", "proof", "code"}
    toks = re.findall(r"[a-z0-9][a-z0-9-]{2,}", (text or "").lower())
    return [t for t in toks if t not in stop]


def _ambiguity_guard(instruction: str, plan: dict) -> dict | None:
    """Deterministic last guard around the planner: when an indirect
    pronoun-only utterance has 2+ equally plausible people tied to the
    same remembered thing, ask instead of letting a model guess.
    """
    low = (instruction or "").lower()
    ambiguous_ref = re.search(
        r"\b(her|him|them|they|she|he|advisor|adviser|manager|"
        r"client|partner|co[- ]?founder|teammate|report)\b",
        low,
    )
    if not ambiguous_ref:
        return None
    if _contains_explicit_person(instruction):
        return None
    people = _profile_people()
    if len(people) < 2:
        return None
    thing = str(plan.get("thing") or "").strip()
    task = str(plan.get("task") or "")
    tokens = _significant_tokens(thing) or _significant_tokens(task)[:4]
    if not tokens:
        return None
    context = "\n".join(_recent_transcripts(12)).lower()
    contenders = []
    for p in people:
        label = p["label"].lower()
        val = p["value"].lower()
        if not label and not val:
            continue
        present = (label and label in context) or (val and val in context)
        same_thing = any(tok in context for tok in tokens)
        if present and same_thing:
            contenders.append(p["label"] or p["relation"])
    unique = []
    for c in contenders:
        if c and c not in unique:
            unique.append(c)
    if len(unique) >= 2:
        names = " or ".join(unique[:3])
        return {"mode": "clarify", "person": "", "thing": thing,
                "task": "", "question": f"Did you mean {names}?"}
    return None


def _email_from_memory(person: str, plan: dict,
                       instruction: str = "") -> tuple[str, str]:
    """Resolve (canonical_name, email) from the seeded/updated memory
    anchors. Onboarding stores prof.people as name-only, but the
    anchors (and session updates like "Sam is on sam@...") keep
    role -> "Name (email)" - that is where an address legitimately
    lives. Conservative: return an email ONLY when exactly one
    anchor-with-email matches the model-resolved person/role; never
    guess between several (that would be misattribution).
    """
    try:
        from app.anticipy import memory as MEM
        snap = MEM.active_snapshot(USER_ID)
    except Exception:
        snap = []
    drop = {"the", "dr", "mr", "ms", "mrs", "my", "his", "her", "their",
            "a", "an", "to", "of", "and", "over", "get", "before",
            "need", "really", "him", "them", "that", "those"}

    def _tok(s: str) -> set:
        return {t for t in re.findall(r"[a-z0-9]{3,}", (s or "").lower())
                if t not in drop}

    ptoks = _tok(person)
    rtoks = _tok(str(plan.get("thing") or ""))
    itoks = _tok(instruction)
    ctx = " ".join(_recent_transcripts(12)).lower()
    pmatch: dict[str, str] = {}
    cmatch: dict[str, str] = {}
    for e in snap:
        if e.get("kind") != "anchor":
            continue
        val = str(e.get("value") or "")
        em = _extract_email(val)
        if not em:
            continue
        key = str(e.get("key") or "").lower()
        name = _person_label(val).lower()
        hay = f"{key} {name}"
        ntoks = _tok(hay)
        if ptoks and any(t in hay for t in ptoks):
            pmatch.setdefault(em, _person_label(val))
        present = bool(ntoks) and any(t in ctx for t in ntoks)
        if (rtoks and any(t in key for t in rtoks)) or present or (
                itoks and any(t in hay for t in itoks)):
            cmatch.setdefault(em, _person_label(val))
    # The model-resolved person decides WHO; memory only supplies the
    # address. Trust person-token matches first and exactly; only fall
    # to context signals when no person was resolved. Either way a 2+
    # ambiguous match returns nothing (clarify, never misattribute).
    pick = pmatch or cmatch
    contenders = sorted({v for v in pick.values() if v})
    if len(pick) == 1:
        em, nm = next(iter(pick.items()))
        return nm, em, contenders
    return "", "", contenders


def _draft_task_from_plan(instruction: str, plan: dict) -> str:
    person = str(plan.get("person") or "").strip()
    thing = str(plan.get("thing") or "").strip()
    email = _extract_email(person)
    if not email:
        for p in _profile_people():
            if person and (person.lower() in p["value"].lower()
                           or person.lower() in p["label"].lower()
                           or person.lower() == p["relation"].lower()):
                email = p["email"]
                person = p["value"]
                break
    if not email:
        nm, em, _ = _email_from_memory(person, plan, instruction)
        if em:
            email = em
            person = nm or person
    if not email:
        return ""
    label = _person_label(person) or "there"
    _hon = {"dr", "dr.", "mr", "mr.", "ms", "ms.", "mrs", "mrs.",
            "prof", "prof.", "sir", "madam"}
    _parts = [w for w in label.split() if w.lower() not in _hon]
    first = (_parts[0] if _parts else label) or "there"
    subject = thing or "Follow-up"
    # If the model resolved the broad thing but dropped a concrete
    # token from the utterance (for example a ticket id, marker, or
    # file/version suffix after "about ..."), keep the user's exact
    # object phrase. The resolved person decides who; the transcript
    # remains the source of truth for what the draft is about.
    m = re.search(r"\babout\s+(.+?)(?:[.!?]|$)", instruction or "",
                  re.IGNORECASE)
    if m:
        raw_subject = re.sub(r"\s+", " ", m.group(1)).strip(" .,:;")
        if raw_subject and (
                not subject
                or subject.lower() in raw_subject.lower()
                or raw_subject.lower() in subject.lower()):
            subject = raw_subject
    subject = re.sub(r"\s+", " ", subject).strip(" .")
    body = (f"Hi {first},\n\n"
            f"I wanted to get {subject} over to you before the week ends.\n\n"
            "Draft created by Anticipy for review.")
    return (f"Open Gmail and create a draft email to {email} with subject "
            f"'{subject}' and body '{body}'. Do not send it; leave it as "
            "a draft.")


def _finalize_plan(instruction: str, plan: dict) -> dict:
    guard = _ambiguity_guard(instruction, plan)
    if guard:
        return guard
    if plan.get("mode") != "act":
        # Salvage an EMAIL-ADDRESS-only clarify (not a person-ambiguity
        # one - those say "did you mean X or Y" and are left intact):
        # the address legitimately lives in memory, so resolve it
        # deterministically and proceed instead of asking the user for
        # something the system already knows. Strict single-match in
        # _email_from_memory keeps this from ever guessing.
        q = str(plan.get("question") or "").lower()
        addr_clarify = (("email address" in q or "which email" in q
                         or "address" in q) and "did you mean" not in q)
        if (addr_clarify and _is_actionish(instruction)
                and not _ambiguity_guard(instruction,
                                         {**plan, "mode": "act"})):
            nm, em, _ = _email_from_memory(str(plan.get("person") or ""),
                                        plan, instruction)
            if em:
                plan = dict(plan)
                plan["mode"] = "act"
                plan["person"] = nm or plan.get("person") or ""
                plan["intent"] = "email_draft"
            else:
                return plan
        else:
            return plan
    low = (instruction or "").lower()
    intent = str(plan.get("intent") or "").lower()
    task = str(plan.get("task") or "").strip()
    emailish = intent in {"email_draft", "gmail_draft", "email"} or bool(
        re.search(r"\b(get .* over|send|email|mail|draft|share|follow up|"
                  r"let .* know)\b", low))
    if emailish:
        draft_task = _draft_task_from_plan(instruction, plan)
        if not draft_task:
            _, _, _cands = _email_from_memory(
                str(plan.get("person") or ""), plan, instruction)
            if len(_cands) >= 2:
                q = "Did you mean " + " or ".join(_cands[:3]) + "?"
            else:
                q = "Which email address should I use?"
            return {"mode": "clarify", "person": "",
                    "thing": plan.get("thing", ""), "task": "",
                    "question": q}
        plan = dict(plan)
        plan["intent"] = "email_draft"
        plan["task"] = draft_task
        return plan
    if re.search(r"\b(search google|web search|no side effects|never requiring login)\b",
                 task.lower()):
        return {"mode": "clarify", "person": plan.get("person", ""),
                "thing": plan.get("thing", ""), "task": "",
                "question": "Do you want me to draft an email or create a calendar event?"}
    return plan


def _proposal_from_plan(plan: dict) -> str:
    if plan.get("mode") == "clarify":
        return str(plan.get("question") or "Which one did you mean?")
    person = _person_label(str(plan.get("person") or ""))
    thing = str(plan.get("thing") or "").strip()
    if person and thing:
        return f"Draft an email to {person} about {thing}."
    if person:
        return f"Draft an email to {person}."
    return str(plan.get("task") or "Act on that.")


def _low_context_clarify_plan(text: str) -> dict | None:
    """Fast ambiguity guard for short, high-risk communication/task wants.

    This is deliberately not the general intent brain. It prevents vague
    MP3/live-transcript windows from blocking on model inference when a
    competent assistant would immediately ask for the missing object or
    target instead of guessing.
    """
    low = re.sub(r"\s+", " ", (text or "").lower()).strip()
    if not low:
        return None
    if (
        _ambient_peer_chatter(text)
        or _garbled_school_timing(low)
        or _noisy_teacher_followup(text)
    ):
        return None
    original = re.sub(r"\s+", " ", (text or "")).strip()
    school_terms = (
        r"assessment|assignment|homework|exam|test|quiz|lab|writing practice|"
        r"listening|criteria|due|deadline"
    )
    date_terms = (
        r"monday|tuesday|wednesday|thursday|friday|saturday|sunday|tomorrow|"
        r"next\s+(?:week|monday|tuesday|wednesday|thursday|friday|saturday|"
        r"sunday)|june|today|this\s+(?:week|weekend)"
    )
    if re.search(
        r"\b(?:it|this|that|assignment|assessment|homework|lab)?\s*"
        r"(?:is|will be|was)?\s*due\s+(?:next\s+)?(?:monday|tuesday|"
        r"wednesday|thursday|friday|saturday|sunday|tomorrow|today)\b",
        low,
    ):
        summary = original[:220].strip(" .")
        return {
            "mode": "clarify",
            "intent": "school_deadline_reminder",
            "risk_tier": 1,
            "question": f"Should I save this due date as a reminder: {summary}?",
            "missing_slots": ["confirm_reminder"],
            "reason": "Ambient classroom speech mentioned a due date.",
            "confirm_card_id": f"clarify-{uuid.uuid4().hex[:12]}",
        }
    if (
        re.search(
        r"\b(?:for\s+)?homework\b.{0,140}\b(?:write|read|finish|"
        r"complete|do|prepare)\b",
        low,
        )
        or re.search(
            r"\b(?:write|read|finish|complete|do|prepare)\b.{0,140}"
            r"\b(?:for\s+)?homework\b",
            low,
        )
    ) and not _vague_homework_mention(low):
        summary = original[:220].strip(" .")
        return {
            "mode": "clarify",
            "intent": "school_homework_reminder",
            "risk_tier": 1,
            "question": (
                "Should I save a reminder for this homework item: "
                f"{summary}?"
            ),
            "missing_slots": ["confirm_reminder"],
            "reason": "Ambient classroom speech mentioned a homework task.",
            "confirm_card_id": f"clarify-{uuid.uuid4().hex[:12]}",
        }
    if re.search(rf"\b(?:{school_terms})\b", low) and (
        re.search(rf"\b(?:{date_terms})\b", low)
        or re.search(r"\b(?:due|by|before|starting|starts?|practice)\b", low)
    ):
        summary = original[:220].strip(" .")
        return {
            "mode": "clarify",
            "intent": "school_deadline_reminder",
            "risk_tier": 1,
            "question": (
                "Should I save a reminder for this school item: "
                f"{summary}?"
            ),
            "missing_slots": ["confirm_reminder"],
            "reason": "Ambient classroom speech mentioned a school item with timing.",
            "confirm_card_id": f"clarify-{uuid.uuid4().hex[:12]}",
        }
    teacher = _extract_teacher_label(original)
    if re.search(
        r"\bi(?:\s+am|'m(?:\s+gonna)?|\s+will|'ll|\s+gonna|\s+have\s+to|\s+need\s+to|"
        r"\s+gotta)\s+"
        r"(?:go\s+)?(?:talk\s+to|ask)\s+"
        r"(?:mr|mrs|miss|ms|madame|m)\.?\s+[a-z]",
        low,
    ):
        question = "Should I remind you to follow up with that teacher?"
        missing_slots = ["confirm_reminder", "teacher"]
        if teacher:
            question = f"Should I remind you to follow up with {teacher}?"
            missing_slots = ["confirm_reminder"]
        return {
            "mode": "clarify",
            "intent": "teacher_followup_reminder",
            "risk_tier": 1,
            "question": question,
            "teacher": teacher,
            "missing_slots": missing_slots,
            "reason": "The transcript mentions a planned teacher follow-up.",
            "confirm_card_id": f"clarify-{uuid.uuid4().hex[:12]}",
        }
    if re.search(
        r"\b(?:book|make|schedule)\s+(?:an?\s+)?(?:allerg(?:y|ies)|"
        r"doctor|dentist|medical)?\s*appointment\b",
        low,
    ) or re.search(r"\ballerg(?:y|ies)\s+appointment\b", low):
        self_bound = re.search(
            r"\b(?:i\s+(?:need|have|gotta|should|want)\s+to\s+"
            r"(?:book|make|schedule)|remind\s+me\s+to\s+"
            r"(?:book|make|schedule)|my\s+(?:allerg(?:y|ies)\s+)?"
            r"appointment|for\s+me)\b",
            low,
        )
        if re.search(r"\bappointment\s+with\s+me\b", low) or not self_bound:
            return None
        return {
            "mode": "clarify",
            "intent": "appointment_reminder",
            "risk_tier": 2,
            "question": (
                "Should I save a reminder to book that appointment, "
                "and what details should I include?"
            ),
            "missing_slots": ["confirm_reminder", "appointment_details"],
            "reason": "The transcript mentions a concrete appointment to book.",
            "confirm_card_id": f"clarify-{uuid.uuid4().hex[:12]}",
        }
    if re.search(r"\bi\s+(?:have|need|gotta|should)\s+to\s+ask\s+(?:her|him|them)\b", low):
        return {
            "mode": "clarify",
            "intent": "ambiguous_followup_request",
            "risk_tier": 2,
            "question": "Who should I ask, and what should I ask them?",
            "missing_slots": ["person", "message"],
            "reason": "The request names a pronoun but not the person or message.",
            "confirm_card_id": f"clarify-{uuid.uuid4().hex[:12]}",
        }
    if re.search(
        r"\bi\s+(?:(?:gotta|wanna|want)\s+|(?:need|have|should)\s+to\s+)"
        r"apply\s+for\b",
        low,
    ):
        return {
            "mode": "clarify",
            "intent": "application_help",
            "risk_tier": 3,
            "question": "Do you want help with that application, and which site or document should I use?",
            "missing_slots": ["surface", "application_target"],
            "reason": "Application work can change submitted information, so Anticipy needs the target before acting.",
            "confirm_card_id": f"clarify-{uuid.uuid4().hex[:12]}",
        }
    return None


def _ambient_peer_chatter(text: str) -> bool:
    """Return True for speech clearly addressed to another nearby human."""
    low = re.sub(r"\s+", " ", (text or "").lower()).strip()
    if not low:
        return False
    if (
        re.search(r"\byou\s+have\s+to\s+book\s+(?:an?\s+)?allerg(?:y|ies)\s+appointment\b", low)
        and not re.search(r"\b(?:for\s+me|my\s+allerg|my\s+appointment|remind\s+me|can\s+you|could\s+you|please)\b", low)
    ):
        return True
    if re.search(
        r"\b(?:can|could|would)\s+you\s+(?:please\s+)?send\s+it\s+to\s+me\b",
        low,
    ):
        return True
    if re.search(r"^(?:wait,?\s*)?send\s+me\s+your\s+socials\b", low):
        return True
    return False


def _vague_homework_mention(low: str) -> bool:
    if not re.search(r"\bhomework\b", low or ""):
        return False
    if re.search(
        r"\b(?:write|read|finish|complete|prepare|submit|due|assessment|"
        r"assignment|lab|document|documents|page|pages|question|questions|"
        r"monday|tuesday|wednesday|thursday|friday|saturday|sunday|tomorrow|"
        r"june|next\s+week)\b",
        low,
    ):
        return False
    return bool(re.search(
        r"\b(?:we(?:'ve| have| got)?|you|i)?\s*(?:have|got|gotta)?\s*"
        r"(?:some\s+)?homework\s+(?:to\s+)?do\b|\bdo\s+(?:the\s+)?homework\b",
        low,
    ))


def _garbled_school_timing(low: str) -> bool:
    return bool(re.search(
        r"\bi\s+need\s+(?:the\s+)?first\s+criteria\s+to\s+be\s+(?:my\s+)?"
        r"(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday|"
        r"tomorrow|today|morning|afternoon|night)\b",
        low or "",
    ))


def _noisy_teacher_followup(text: str) -> bool:
    low = re.sub(r"\s+", " ", (text or "").lower()).strip()
    if re.search(r"\b(?:i'?ll|i\s+will)\s+ask\s+you\b", low):
        return True
    if low.startswith(("this way,", "this way ")):
        return True
    labels = re.findall(
        r"\b(?:mr|mrs|miss|ms|madame)\.?\s+[a-z][a-z'-]*",
        low,
    )
    return len(labels) > 1 and not re.search(r"\bremind\s+me\b", low)


def _extract_teacher_label(text: str) -> str:
    m = re.search(
        r"\b(Mr|Mrs|Miss|Ms|Madame)\.?\s+([A-Z][A-Za-z][A-Za-z'-]*)",
        text or "",
    )
    if not m:
        return ""
    title = m.group(1)
    suffix = "." if title.lower() in {"mr", "mrs", "ms"} else ""
    return f"{title}{suffix} {m.group(2)}"


def _normalize_post_asr_text(raw_text: str) -> tuple[str, list[dict]]:
    """Conservative post-ASR normalization for product-bound transcripts.

    The raw ASR transcript is preserved in receipts. These corrections only
    handle stable Anticipy/product vocabulary and harmless orthographic
    variants before the common post-ASR inference boundary.
    """
    text = (raw_text or "").strip()
    normalizations: list[dict] = []

    def replace(pattern: str, replacement: str, reason: str) -> None:
        nonlocal text
        updated, count = re.subn(pattern, replacement, text, flags=re.IGNORECASE)
        if count:
            normalizations.append({
                "pattern": pattern,
                "replacement": replacement,
                "count": count,
                "reason": reason,
            })
            text = updated

    replace(
        r"^anticipate(?=[,\s])",
        "Anticipy",
        "hotword_asr_correction",
    )
    replace(
        r"\bNorth\s+Star\s+Linen\b",
        "Northstar Linen",
        "known_entity_compound_normalization",
    )
    return text, normalizations


def _process_utterance(
    text: str, rms: float, source: str, capture: dict | None = None
) -> dict:
    """The ONE judged code path for a window of speech, used by both
    the real-microphone ASR loop (source="mic-asr") and the authorized
    transcript-boundary input (source="asr-transcript", exactly where
    the real voice system's ASR output enters the judged pipeline).
    Memory write + reasoning + proposal are identical regardless of
    source; only how the transcript was obtained differs.
    """
    rec = {"ts": time.time(), "rms": rms,
           "ingest_id": f"{source}-{uuid.uuid4().hex}",
           "transcript": text,
           "outcome": None, "proposal": None, "memory": None,
           "source": source, "window": _LISTEN["windows"] + 1}
    if capture:
        rec["capture"] = capture
        rec["audio_device"] = capture.get("audio_device")
        rec["capture_id"] = capture.get("capture_id")
        if "raw_asr_transcript" in capture:
            rec["raw_asr_transcript"] = capture.get("raw_asr_transcript")
            rec["asr_normalized"] = bool(capture.get("asr_normalized"))
            rec["asr_normalizations"] = capture.get("asr_normalizations") or []
    if text:
        try:
            _ensure_profile_loaded()
            rec["profile_loaded"] = _SESS.get("profile_obj") is not None
        except Exception as e:
            rec["profile_loaded"] = False
            rec["profile_error"] = f"{type(e).__name__}: {e}"
        if _ambient_peer_chatter(text):
            rec["outcome"] = "IGNORED"
            rec["proposal"] = None
            rec["ambient_peer_chatter"] = True
            rec["intent"] = "ambient_peer_chatter"
            rec["decision_reason"] = (
                "Speech appears addressed to another nearby person, "
                "not Anticipy or the user's own future task."
            )
        else:
            decline = _competent_decline_for_text(text)
            if decline:
                _apply_competent_decline(rec, text, decline)
            else:
                _schedule_proactive_from_utterance(text, rec)
                clarify = _low_context_clarify_plan(text)
                if clarify:
                    rec["outcome"] = "DEFERRED"
                    rec["proposal"] = str(
                        clarify.get("question") or "Can you clarify?"
                    )
                    rec["plan"] = clarify
                    rec["clarify"] = True
                    rec["confirm_card_id"] = clarify.get("confirm_card_id")
                    rec["intent"] = clarify.get("intent")
                    rec["memory"] = _memory_write(text, "latent_intent")
                    _LISTEN["pending"] = {
                        "instruction": text,
                        "proposal": rec["proposal"],
                        "clarify": True,
                        "plan": clarify,
                        "confirm_card_id": clarify.get("confirm_card_id"),
                        "ts": rec["ts"],
                    }
                else:
                    try:
                        outcome, proposal = _run_pipeline(text)
                        rec["outcome"] = outcome
                        rec["proposal"] = proposal
                        kind = ("latent_intent"
                                if outcome in ("ACTED", "DEFERRED", "CONFIRMED")
                                else "fact")
                        rec["memory"] = _memory_write(text, kind)
                        if proposal:
                            _LISTEN["pending"] = {
                                "instruction": text, "proposal": proposal,
                                "ts": rec["ts"]}
                        elif _is_actionish(text):
                            plan = _compose_task_from_memory(text)
                            plan = _finalize_plan(text, plan)
                            rec["plan"] = plan
                            if plan.get("mode") == "clarify":
                                _LISTEN["pending"] = {
                                    "instruction": text,
                                    "proposal": _proposal_from_plan(plan),
                                    "clarify": True, "plan": plan,
                                    "ts": rec["ts"]}
                            elif plan.get("mode") == "act" and plan.get("task"):
                                _LISTEN["pending"] = {
                                    "instruction": text,
                                    "proposal": _proposal_from_plan(plan),
                                    "plan": plan, "ts": rec["ts"]}
                    except Exception as e:
                        rec["error"] = f"{type(e).__name__}: {e}"
        try:
            trace_sync = _sync_resolution_trace(rec)
            rec["resolution_trace_sync"] = trace_sync
            _SESS["last_resolution_trace_sync"] = trace_sync
        except Exception as e:
            trace_sync = {"ok": False, "error": f"{type(e).__name__}: {e}"}
            rec["resolution_trace_sync"] = trace_sync
            _SESS["last_resolution_trace_sync"] = trace_sync
        rec["proactive_due"] = _surface_fired_proactive_items()
        _write_v7_inference_artifacts(rec, capture)
    with _LISTEN["lock"]:
        _LISTEN["windows"] += 1
        _LISTEN["recent"] = ([rec] + _LISTEN["recent"])[:12]
    return rec


def _proc_loop() -> None:
    import numpy as np

    from app.audiostack import audio as A
    while _LISTEN["on"]:
        t0 = time.time()
        while _LISTEN["on"] and time.time() - t0 < WINDOW_SECONDS:
            time.sleep(0.2)
        if not _LISTEN["on"]:
            break
        with _LISTEN["buf_lock"]:
            chunks = list(_LISTEN["buf"])
            _LISTEN["buf"].clear()
        if not chunks:
            continue
        try:
            wav = np.concatenate(chunks).astype("float32")
        except Exception:
            continue
        rms = float(np.sqrt(np.mean(wav ** 2)) or 0.0)
        with _LISTEN["lock"]:
            stream_sr = float(_LISTEN.get("sample_rate") or A.SR)
            capture = {
                "capture_id": _LISTEN.get("capture_id"),
                "source_mode": _LISTEN.get("source_mode"),
                "audio_device": _LISTEN.get("audio_device"),
                "stream_sample_rate": stream_sr,
            }
        if stream_sr and int(stream_sr) != int(A.SR):
            try:
                import librosa

                wav = librosa.resample(
                    np.asarray(wav, dtype=np.float32),
                    orig_sr=int(stream_sr),
                    target_sr=A.SR,
                ).astype("float32")
            except Exception:
                pass
        if not _PROC_MEMWRITE:
            # Chain-harness mode: keep continuous-listening REAL and
            # on (count the window, level is live from the callback)
            # but do NOT run the pipeline / write memory - ambient
            # room speech must never pollute the walled-off scenario.
            with _LISTEN["lock"]:
                _LISTEN["windows"] += 1
            continue
        try:
            asr = A.asr_tokens(wav)
            raw_text = (asr.text or "").strip()
            text, normalizations = _normalize_post_asr_text(raw_text)
            capture["raw_asr_transcript"] = raw_text
            capture["asr_normalized"] = raw_text != text
            capture["asr_normalizations"] = normalizations
        except Exception:
            text = ""
        _process_utterance(text, rms, "mic-asr", capture)


class Inject(BaseModel):
    text: str


class ListenStart(BaseModel):
    device_index: int | None = None
    source_mode: str | None = None


class EvalRun(BaseModel):
    transcript_path: str
    mode: str = "eval"
    dry_run: bool = True
    max_windows: int | None = None
    max_chars_per_window: int = 900
    max_processed_windows: int | None = None
    window_timeout_seconds: int | None = None


def _eval_segments(text: str, max_chars: int) -> list[str]:
    """Split long transcripts into bounded ASR-like text windows."""
    max_chars = max(240, min(int(max_chars or 900), 2400))
    chunks: list[str] = []
    current: list[str] = []
    current_len = 0
    parts = [p.strip() for p in re.split(r"(?<=[.!?])\s+|\n+", text)
             if p.strip()]
    for part in parts:
        if len(part) > max_chars:
            words = part.split()
            buf: list[str] = []
            buf_len = 0
            for word in words:
                extra = len(word) + (1 if buf else 0)
                if buf and buf_len + extra > max_chars:
                    chunks.append(" ".join(buf))
                    buf = [word]
                    buf_len = len(word)
                else:
                    buf.append(word)
                    buf_len += extra
            if buf:
                part_chunks = [" ".join(buf)]
            else:
                part_chunks = []
        else:
            part_chunks = [part]
        for piece in part_chunks:
            extra = len(piece) + (1 if current else 0)
            if current and current_len + extra > max_chars:
                chunks.append(" ".join(current))
                current = [piece]
                current_len = len(piece)
            else:
                current.append(piece)
                current_len += extra
    if current:
        chunks.append(" ".join(current))
    return chunks


def _mp3_eval_candidate_score(text: str) -> int:
    """Score transcript windows worth running through post-ASR inference.

    The score is only a ranking gate for the held-out MP3 eval. The chosen
    excerpt still enters _process_utterance unchanged, where it must produce
    an action, ask, or decline receipt through the product path.
    """
    low = re.sub(r"\s+", " ", (text or "").lower()).strip()
    if len(low) < 20:
        return 0
    if _ambient_peer_chatter(text):
        return 0
    if (
        _vague_homework_mention(low)
        or _garbled_school_timing(low)
        or _noisy_teacher_followup(text)
    ):
        return 0
    if low.startswith(("if i ", "so if i ")):
        return 0
    if re.search(r"^if you do(?:n't| not) remember\b.*\bplease ask\b", low):
        return 0
    if re.search(r"\bgo\s+to\s+chat\b.*\bbe\s+like\b", low):
        return 0
    if re.search(r"\b(?:are|we|you|i)\s+.*getting\s+.*test\s+back\b", low):
        return 0
    if re.search(
        r"\b(?:early missing home|pretty much that|all of your lessons "
        r"will be exam prep|full exam prep)\b",
        low,
    ):
        return 0
    if re.search(r"\b(?:i asked|asked him|asked her|like, yo)\b", low):
        return 0
    if re.search(r"\b(?:he|she|they|someone)\s+was\s+like\b", low):
        return 0
    if re.search(r"\bi\s+did\s+my\s+homework\b", low):
        return 0
    if re.search(r"\bappointment\s+with\s+me\b", low):
        return 0
    if re.search(
        r"\b(no need|don't need|do not need|shouldn't|do not send|"
        r"don't send|not going to|already did|already handled)\b",
        low,
    ):
        return 0
    score = 0
    direct_patterns = [
        r"\b(?:i|we)\s+(?:really\s+)?(?:need|should|gotta|have|want)\s+to\s+"
        r"(?:email|send|draft|share|schedule|book|remind|tell|ask|apply|"
        r"submit|call|text|message|follow up|move|cancel|open|create|"
        r"add|write|find|look up)\b",
        r"\b(?:can|could|would)\s+you\s+(?:please\s+)?(?:email|send|draft|"
        r"share|schedule|book|remind|tell|ask|call|text|message|open|"
        r"create|add|find|look up)\b",
        r"\bplease\s+(?:email|send|draft|share|schedule|book|remind|tell|"
        r"ask|call|text|message|open|create|add|find)\b",
        r"^(?:wait,?\s*)?(?:send|email|text|message|call|draft|book|"
        r"schedule|open|create|add|find)\s+"
        r"(?:me|my|the|a|an|him|her|them|it|this|that)\b",
        r"\b(?:remind me to|follow up with|add .{0,40} calendar|"
        r"create .{0,40} (?:event|reminder|note|ticket))\b",
    ]
    if any(re.search(p, low) for p in direct_patterns):
        score = max(score, 4)
    if re.search(
        r"\bi\s+(?:(?:gotta|wanna|want)\s+|(?:need|have|should)\s+to\s+)"
        r"apply\s+for\b",
        low,
    ):
        score = max(score, 6)
    if re.search(
        r"\b(?:book|make|schedule)\s+(?:an?\s+)?(?:allerg(?:y|ies)|"
        r"doctor|dentist|medical)?\s*appointment\b",
        low,
    ) or re.search(r"\ballerg(?:y|ies)\s+appointment\b", low):
        score = max(score, 6)
    academic_patterns = [
        r"\b(?:homework|assessment|assignment|exam|test|quiz|lab|writing "
        r"practice|listening|criteria)\b.{0,180}\b(?:monday|tuesday|"
        r"wednesday|thursday|friday|saturday|sunday|tomorrow|june|"
        r"next\s+(?:week|monday|tuesday|wednesday|thursday|friday|"
        r"saturday|sunday)|"
        r"due|by|before|starting|starts?)\b",
        r"\b(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday|"
        r"tomorrow|june|next\s+(?:week|monday|tuesday|wednesday|thursday|"
        r"friday|saturday|sunday))\b.{0,180}\b(?:homework|assessment|assignment|"
        r"exam|test|quiz|lab|writing practice|listening|criteria|due)\b",
    ]
    if any(re.search(p, low) for p in academic_patterns):
        score = max(score, 5)
    if (
        re.search(
        r"\b(?:for\s+)?homework\b.{0,160}\b(?:write|read|finish|"
        r"complete|do|prepare)\b",
        low,
        )
        or re.search(
            r"\b(?:write|read|finish|complete|do|prepare)\b.{0,160}"
            r"\b(?:for\s+)?homework\b",
            low,
        )
    ) and not _vague_homework_mention(low):
        score = max(score, 6)
    if re.search(
        r"\b(?:it|this|that|assignment|assessment|homework|lab)?\s*"
        r"(?:is|will be|was)?\s*due\s+(?:next\s+)?(?:monday|tuesday|"
        r"wednesday|thursday|friday|saturday|sunday|tomorrow|today)\b",
        low,
    ):
        score = max(score, 7)
    if score and re.search(
        r"\b(?:writing assessment|listening assessment|criteria d|due next|"
        r"june\s+\d|monday,\s*june|thursday,\s*june)\b",
        low,
    ):
        score = max(score, 7)
    if re.search(
        r"\bi(?:\s+am|'m(?:\s+gonna)?|\s+will|'ll|\s+gonna|\s+have\s+to|\s+need\s+to|"
        r"\s+gotta)\s+"
        r"(?:go\s+)?(?:talk\s+to|ask)\s+"
        r"(?:mr|mrs|miss|ms|madame|m)\.?\s+[a-z]",
        low,
    ):
        score = max(score, 4)
    return score


def _mp3_eval_candidate_excerpts(text: str, limit: int = 3) -> list[str]:
    """Extract multiple actionable sentences from one long MP3 chunk."""
    protected = re.sub(
        r"\b(Mr|Mrs|Ms|Miss|Madame)\.",
        lambda m: f"{m.group(1)}<DOT>",
        text or "",
    )
    sentences = [
        p.replace("<DOT>", ".").strip()
        for p in re.split(r"(?<=[.!?])\s+|\n+", protected)
        if p.strip()
    ]
    rows = [
        (_mp3_eval_candidate_score(sentence), idx, sentence)
        for idx, sentence in enumerate(sentences)
    ]
    rows = [row for row in rows if row[0] > 0]
    if not rows:
        return []
    rows.sort(key=lambda row: (-row[0], row[1]))
    selected = sorted(rows[:max(1, int(limit))], key=lambda row: row[1])
    excerpts: list[str] = []
    seen: set[str] = set()
    for _, idx, sentence in selected:
        excerpt = sentence
        if idx + 1 < len(sentences):
            next_sentence = sentences[idx + 1]
            next_low = re.sub(r"\s+", " ", next_sentence.lower()).strip()
            if re.search(
                r"\b(?:due|monday|tuesday|wednesday|thursday|friday|"
                r"saturday|sunday|june|assessment|homework|writing|"
                r"listening|exam|criteria|appointment|email)\b",
                next_low,
            ):
                excerpt = f"{excerpt} {next_sentence}"
        key = re.sub(r"\s+", " ", excerpt.lower()).strip()
        if key not in seen:
            seen.add(key)
            excerpts.append(excerpt)
    return excerpts


def _mp3_eval_candidate(text: str) -> bool:
    """Return True for transcript windows worth running through the
    full post-ASR inference path during the held-out MP3 eval.

    The MP3 is hours long. Running every conversational filler window
    through _process_utterance makes /eval/run monopolize the installed
    engine and time out before it can return a verdict. This prefilter
    only decides which windows deserve the real inference path; the
    selected windows still enter _process_utterance unchanged.
    """
    return _mp3_eval_candidate_score(text) > 0


def _mp3_eval_candidate_excerpt(text: str) -> str:
    """Extract the actionable sentence from a long MP3 transcript chunk."""
    excerpts = _mp3_eval_candidate_excerpts(text, limit=1)
    return excerpts[0] if excerpts else ""


@app.post("/api/listen/inject")
def listen_inject(i: Inject) -> JSONResponse:
    """Authorized transcript-boundary input: the walled-off scenario
    script enters HERE, exactly where the real voice system's ASR
    output would enter the judged pipeline. It runs the identical
    judged path as a real-mic window (_process_utterance). Labeled
    source="asr-transcript"; never dressed up as acoustic capture.

    The mic stream and this transcript-boundary path are independent
    inputs into the same judged pipeline. Requiring the live mic to be
    "on" before accepting an authorized transcript inject conflates
    two separate things: in the audit verifier and in any headless or
    BlackHole-loopback environment the mic stream is intentionally
    not running, but the engine must still accept ASR-shape input and
    advance the pipeline. So the inject path advances regardless of
    mic state. Source label keeps the provenance distinction.
    """
    text = (i.text or "").strip()
    # If listening is off we still need a coherent rec shape for the
    # pipeline; _process_utterance reads from _LISTEN so it works
    # standalone. The "on" check on inject was a UX gate, not a
    # safety one (the mic source is labelled separately).
    try:
        rec = _with_timeout(
            "listen-inject-process",
            float(_env_int("ANTICIPY_INJECT_TIMEOUT_SECONDS", 30)),
            lambda: _process_utterance(text, 0.0, "asr-transcript"),
        )
    except TimeoutError as e:
        rec = {
            "window": _LISTEN.get("windows", 0),
            "ingest_id": f"asr-transcript-timeout-{uuid.uuid4().hex[:12]}",
            "transcript": text,
            "outcome": "DECLINED",
            "proposal": None,
            "plan": None,
            "memory": None,
            "resolution_trace_sync": None,
            "error": str(e),
        }
        with _LISTEN["lock"]:
            _LISTEN["error"] = str(e)
    # Belt-and-braces: ensure _LISTEN["pending"] carries the raw
    # instruction so a subsequent /api/act with no body can act on it
    # even when the pipeline did not produce a structured plan (e.g.
    # the LLM is unavailable or the text did not pass _is_actionish).
    if (
        (not rec.get("error"))
        and text
        and not (_LISTEN.get("pending") or {}).get("instruction")
    ):
        with _LISTEN["lock"]:
            _LISTEN["pending"] = {
                "instruction": text,
                "proposal": text,
                "ts": time.time(),
            }
    scheduled = rec.get("scheduled")
    return JSONResponse({"on": _LISTEN.get("on", False),
                         "window": rec["window"],
                         "ingest_id": rec.get("ingest_id"),
                         "transcript": rec["transcript"],
                         "outcome": rec.get("outcome"),
                         "error": rec.get("error"),
                         "proposal": rec.get("proposal"),
                         "plan": rec.get("plan"),
                         "memory": rec.get("memory"),
                         "resolution_trace_sync": rec.get(
                             "resolution_trace_sync"),
                         "pending": _LISTEN.get("pending"),
                         "scheduled": scheduled})


@app.post("/eval/run")
def eval_run(body: EvalRun) -> JSONResponse:
    """Held-out MP3 evaluator entrypoint.

    This is deliberately a dry-run surface: it reads a transcript file,
    sends each bounded window through _process_utterance, and returns
    the surfaced proposal/plan/decline records. It does not call
    /api/act and therefore creates no browser, Gmail, Calendar, or
    native-app side effect.
    """
    raw_path = (body.transcript_path or "").strip()
    if not raw_path:
        return JSONResponse({"ok": False, "error": "empty transcript_path"},
                            status_code=400)
    path = Path(raw_path)
    if not path.is_absolute():
        repo_root = Path(__file__).resolve().parents[3]
        candidates = [
            (Path.cwd() / path).resolve(),
            (Path.cwd().parent / path).resolve(),
            (repo_root / path).resolve(),
        ]
        path = next((p for p in candidates if p.exists()), candidates[0])
    if not path.exists() or not path.is_file():
        return JSONResponse({"ok": False,
                             "error": f"transcript_path not found: {path}"},
                            status_code=404)
    transcript = path.read_text(errors="replace")
    if not transcript.strip():
        return JSONResponse({"ok": False, "error": "empty transcript"},
                            status_code=400)

    max_windows = body.max_windows
    if max_windows is None:
        max_windows = _env_int("MP3_EVAL_MAX_WINDOWS", 240)
    max_windows = max(1, min(int(max_windows), 1000))
    max_processed = body.max_processed_windows
    if max_processed is None:
        max_processed = _env_int("MP3_EVAL_MAX_PROCESSED_WINDOWS", 24)
    max_processed = max(1, min(int(max_processed), max_windows))
    window_timeout = body.window_timeout_seconds
    if window_timeout is None:
        window_timeout = _env_int("MP3_EVAL_WINDOW_TIMEOUT_SECONDS", 20)
    window_timeout = max(3, min(int(window_timeout), 120))
    segments = _eval_segments(transcript, body.max_chars_per_window)
    truncated = len(segments) > max_windows
    considered = segments[:max_windows]
    candidate_rows = []
    for idx, segment in enumerate(considered, start=1):
        for excerpt in _mp3_eval_candidate_excerpts(segment, limit=3):
            candidate_rows.append({
                "window": idx,
                "transcript": excerpt,
                "source_window_chars": len(segment),
            })
    selected = candidate_rows[:max_processed]

    global USER_ID

    prior_user_id = USER_ID
    eval_user_id = f"{prior_user_id}-mp3-eval-{uuid.uuid4().hex[:12]}"
    prior_pending = _LISTEN.get("pending")
    prior_acted = _LISTEN.get("acted")
    prior_recent = list(_LISTEN.get("recent") or [])
    actions: list[dict] = []
    window_errors: list[dict] = []
    timed_out = False
    try:
        USER_ID = eval_user_id
        _LISTEN["pending"] = None
        _LISTEN["acted"] = None
        _LISTEN["recent"] = []
        for row in selected:
            idx = int(row["window"])
            segment = str(row["transcript"])
            try:
                rec = _with_timeout(
                    f"mp3-eval-window-{idx}",
                    float(window_timeout),
                    lambda segment=segment: _process_utterance(
                        segment, 0.0, "mp3-eval-transcript"),
                )
            except TimeoutError as e:
                timed_out = True
                err = {
                    "id": f"mp3-eval-{idx}",
                    "window": idx,
                    "transcript": segment,
                    "error": str(e),
                    "timed_out": True,
                    "source": "mp3-eval-transcript",
                    "dry_run": bool(body.dry_run),
                }
                window_errors.append(err)
                actions.append(err)
                break
            except Exception as e:
                err = {
                    "id": f"mp3-eval-{idx}",
                    "window": idx,
                    "transcript": segment,
                    "error": f"{type(e).__name__}: {e}",
                    "timed_out": False,
                    "source": "mp3-eval-transcript",
                    "dry_run": bool(body.dry_run),
                }
                window_errors.append(err)
                actions.append(err)
                continue
            pending = _LISTEN.get("pending") or {}
            surfaced = bool(rec.get("proposal") or rec.get("plan")
                            or pending.get("proposal")
                            or rec.get("outcome") == "DECLINED")
            if surfaced:
                actions.append({
                    "id": f"mp3-eval-{idx}",
                    "window": idx,
                    "transcript": segment,
                    "outcome": rec.get("outcome"),
                    "proposal": rec.get("proposal") or pending.get("proposal"),
                    "plan": rec.get("plan") or pending.get("plan"),
                    "pending": pending,
                    "source": rec.get("source"),
                    "ingest_id": rec.get("ingest_id"),
                    "dry_run": bool(body.dry_run),
                })
    finally:
        USER_ID = prior_user_id
        _LISTEN["pending"] = prior_pending
        _LISTEN["acted"] = prior_acted
        _LISTEN["recent"] = prior_recent

    return JSONResponse({
        "ok": True,
        "mode": body.mode,
        "dry_run": bool(body.dry_run),
        "transcript_path": str(path),
        "eval_user_id": eval_user_id,
        "transcript_chars": len(transcript),
        "windows_total": len(segments),
        "windows_considered": len(considered),
        "candidate_count": len(candidate_rows),
        "windows_processed": len(selected),
        "max_processed_windows": max_processed,
        "window_timeout_seconds": window_timeout,
        "truncated": truncated,
        "timed_out": timed_out,
        "candidate_filter": "v7_mp3_actionable_prefilter_v2",
        "skipped_non_actionish": max(0, len(considered) - len(candidate_rows)),
        "window_errors": window_errors,
        "actions": actions,
        "action_count": len(actions),
    })


class _ClockAdvance(BaseModel):
    seconds: float = 0.0


@app.post("/api/test/clock_advance")
def test_clock_advance(body: _ClockAdvance) -> JSONResponse:
    """Test endpoint: advance the proactive scheduler's simulated clock
    by the given seconds and tick any due items to the fired state.
    Used by the audit verifier (A-003) to confirm scheduled items
    actually fire when their target time passes.
    """
    from app.product.scheduler import get_scheduler
    result = get_scheduler().advance_clock(float(body.seconds or 0.0))
    _surface_fired_proactive_items()
    return JSONResponse({"ok": True, **result})


@app.get("/api/proactive/queue")
def proactive_queue() -> JSONResponse:
    """Return the proactive scheduler queue, fired items first. The
    queue is the in-process scheduler's view of pending and fired
    items; each item carries its raw transcript and any plan the
    pipeline extracted from it.
    """
    from app.product.scheduler import get_scheduler
    _surface_fired_proactive_items()
    items = get_scheduler().queue()
    return JSONResponse({"ok": True, "items": items,
                         "pending": _LISTEN.get("pending"),
                         "count": len(items)})


@app.post("/api/proactive/reset")
def proactive_reset() -> JSONResponse:
    """Clear the proactive scheduler queue and reset the simulated
    clock. Used by tests to start from a known state.
    """
    from app.product.scheduler import get_scheduler
    get_scheduler().reset()
    return JSONResponse({"ok": True})


@app.post("/api/stt/local")
async def stt_local(request: Request) -> JSONResponse:
    """Pure local parakeet-mlx transcription.

    Accepts uploaded audio (WAV, MP3, AIFF, M4A) and returns the
    transcript as plain text. Unlike /api/listen/upload, this endpoint
    does NOT feed the result into the judged proactive pipeline. Use it when
    the caller just wants "audio in, text out" against the same
    parakeet-mlx model the rest of the stack uses.

    Two input shapes are supported:
    1. Raw audio body with Content-Type: audio/wav (or mp3/aiff/m4a).
    2. multipart/form-data with field name "audio" (what python
       requests' files={"audio": ...} sends; what curl -F sends).
    """
    raw, ctype, filename = await _read_audio_request(request)
    if not raw:
        return JSONResponse({"ok": False, "error": "empty upload"},
                            status_code=400)
    status, payload = await _transcribe_uploaded_audio_bounded(
        raw, ctype, filename, feed_pipeline=False)
    return JSONResponse(payload, status_code=status)


@app.post("/api/listen/upload")
async def listen_upload(request: Request) -> JSONResponse:
    """Audio-upload input mode: uploaded MP3/WAV/etc is decoded, transcribed
    by the same local ASR, then handed to _process_utterance just like a
    live microphone ASR window. This is not a transcript bypass and does not
    require the live microphone stream to be started.
    """
    raw, ctype, filename = await _read_audio_request(request)
    if not raw:
        return JSONResponse({"ok": False, "error": "empty upload"},
                            status_code=400)
    status, payload = await _transcribe_uploaded_audio_bounded(
        raw, ctype, filename, feed_pipeline=True)
    return JSONResponse(payload, status_code=status)


@app.post("/api/listen/start")
def listen_start(body: ListenStart | None = None) -> JSONResponse:
    with _LISTEN["lock"]:
        if _LISTEN["on"]:
            return JSONResponse({"on": True, "already": True,
                                 "window_seconds": WINDOW_SECONDS,
                                 "audio_device": _LISTEN.get("audio_device"),
                                 "sample_rate": _LISTEN.get("sample_rate"),
                                 "capture_id": _LISTEN.get("capture_id"),
                                 "source_mode": _LISTEN.get("source_mode")})
        _install_memory_draw()
        with _LISTEN["buf_lock"]:
            _LISTEN["buf"].clear()
        _LISTEN["error"] = None
        try:
            import sounddevice as sd

            from app.audiostack import audio as A
            allowed, mic_status = _mac_mic_permission()
            if not allowed:
                raise PermissionError(f"microphone permission {mic_status}")

            raw_devices = sd.query_devices()
            requested_index = None if body is None else body.device_index
            default_name = ""
            try:
                default_in = sd.query_devices(kind="input")
                default_name = str(default_in.get("name", "")) if isinstance(
                    default_in, dict) else ""
            except Exception:
                default_name = ""
            selected_row: dict | None = None
            selected_device = None
            for idx, dev in enumerate(raw_devices):
                if not isinstance(dev, dict):
                    continue
                if int(dev.get("max_input_channels") or 0) <= 0:
                    continue
                row = _audio_device_row(idx, dev, default_name)
                if requested_index is None:
                    if row["is_default"]:
                        selected_row = row
                        selected_device = dev
                        break
                elif row["index"] == int(requested_index):
                    selected_row = row
                    selected_device = dev
                    break
            if selected_row is None and requested_index is None:
                for idx, dev in enumerate(raw_devices):
                    if isinstance(dev, dict) and int(dev.get("max_input_channels") or 0) > 0:
                        selected_row = _audio_device_row(idx, dev, default_name)
                        selected_device = dev
                        break
            if selected_row is None or selected_device is None:
                raise ValueError(f"input device not found: {requested_index}")
            stream_sr = int(float(selected_row.get("default_sample_rate") or A.SR))
            if stream_sr <= 0:
                stream_sr = A.SR
            capture_id = f"mic-capture-{uuid.uuid4().hex}"
            source_mode = (
                (body.source_mode if body else None) or "computer_microphone"
            ).strip() or "computer_microphone"

            def open_stream():
                stream = sd.InputStream(device=selected_row["index"],
                                        samplerate=stream_sr, channels=1,
                                        dtype="float32",
                                        callback=_audio_cb)
                stream.start()
                return stream

            stream = _with_timeout("microphone stream start", 15.0,
                                   open_stream)
        except Exception as e:
            _LISTEN["error"] = f"{type(e).__name__}: {e}"
            return JSONResponse({"on": False, "error": _LISTEN["error"]})
        _LISTEN["stream"] = stream
        _LISTEN["on"] = True
        _LISTEN["started_at"] = time.time()
        _LISTEN["windows"] = 0
        # Do not clear pending/recent here. The UI may be opened or reloaded
        # after an uploaded-audio result, and V7 requires that visible
        # action/ask/decline card to remain screen-readable. Explicit reset
        # and dismiss endpoints own intentional cleanup.
        _LISTEN["audio_device"] = selected_row
        _LISTEN["sample_rate"] = stream_sr
        _LISTEN["capture_id"] = capture_id
        _LISTEN["source_mode"] = source_mode
        th = threading.Thread(target=_proc_loop, daemon=True)
        _LISTEN["proc"] = th
        th.start()
    return JSONResponse({
        "on": True,
        "window_seconds": WINDOW_SECONDS,
        "permission": mic_status,
        "audio_device": selected_row,
        "sample_rate": stream_sr,
        "capture_id": capture_id,
        "source_mode": source_mode,
    })


def _stop_listen() -> None:
    with _LISTEN["lock"]:
        _LISTEN["on"] = False
        st = _LISTEN["stream"]
        _LISTEN["stream"] = None
        _LISTEN["audio_device"] = None
        _LISTEN["sample_rate"] = None
        _LISTEN["capture_id"] = None
        _LISTEN["source_mode"] = None
    if st:
        try:
            st.stop()
            st.close()
        except Exception:
            pass


@app.post("/api/listen/stop")
def listen_stop() -> JSONResponse:
    _stop_listen()
    return JSONResponse({"on": False})


@app.post("/api/listen/dismiss")
def listen_dismiss() -> JSONResponse:
    _LISTEN["pending"] = None
    return JSONResponse({"ok": True})


@app.post("/api/listen/reset")
def listen_reset() -> JSONResponse:
    """Clear the session counters/feed/pending WITHOUT touching the
    audio stream. Used to start a fresh logical session while the
    real microphone keeps continuously listening (never self-stops):
    repeatedly stopping/reopening the macOS input device wedges
    CoreAudio, so the stream stays up for the whole run.
    """
    with _LISTEN["lock"]:
        _LISTEN["windows"] = 0
        _LISTEN["recent"] = []
        _LISTEN["pending"] = None
        _LISTEN["acted"] = None
        _LISTEN["started_at"] = time.time()
        _LISTEN["error"] = None
    try:
        with _LISTEN["buf_lock"]:
            _LISTEN["buf"].clear()
    except Exception:
        pass
    return JSONResponse({"ok": True, "on": _LISTEN["on"]})


@app.get("/api/listen/status")
def listen_status() -> JSONResponse:
    _surface_fired_proactive_items()
    with _LISTEN["lock"]:
        return JSONResponse({
            "on": _LISTEN["on"],
            "window_seconds": WINDOW_SECONDS,
            "windows": _LISTEN["windows"],
            "level": round(_LISTEN["level"], 6),
            "uptime": round(time.time() - _LISTEN["started_at"], 1)
            if _LISTEN["started_at"] else 0,
            "recent": _LISTEN["recent"][:10],
            "pending": _LISTEN["pending"],
            "acted": _LISTEN["acted"],
            "error": _LISTEN["error"],
            "audio_device": _LISTEN.get("audio_device"),
            "sample_rate": _LISTEN.get("sample_rate"),
            "capture_id": _LISTEN.get("capture_id"),
            "source_mode": _LISTEN.get("source_mode"),
        })


# --------------------------------------------------------------------------
# act: the proposal handed to the FROZEN browser action engine
# --------------------------------------------------------------------------

def _cdp_up() -> bool:
    if CDP_PORT <= 0:
        return False
    try:
        urllib.request.urlopen(
            f"http://127.0.0.1:{CDP_PORT}/json/version", timeout=2).read()
        return True
    except Exception:
        return False


def _ensure_cdp_chrome() -> bool:
    """Ensure the configured CDP Chrome is reachable.

    V7 proof uses the installed extension/native bridge on the user's
    actual Chrome profile. CDP is now an explicit non-clone override for
    controlled probes only.
    """
    if CDP_PORT <= 0:
        return False
    if _cdp_up():
        return True
    user_data_dir = _chrome_user_data_dir()
    if not user_data_dir:
        return False
    if (CHROME_REAL_CLONE_TOKEN in user_data_dir
            and not LEGACY_CLONE_CDP_ENABLED):
        return False
    chrome = None
    for c in ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
              shutil.which("google-chrome"), shutil.which("chromium")):
        if c and Path(c).exists():
            chrome = c
            break
    if not chrome:
        return False
    try:
        subprocess.Popen(
            [chrome, f"--remote-debugging-port={CDP_PORT}",
             "--remote-allow-origins=http://localhost:*",
             f"--user-data-dir={user_data_dir}",
             "--profile-directory=Default", "--no-first-run",
             "--no-default-browser-check",
             "--disable-features=Translate"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        return False
    for _ in range(40):
        if _cdp_up():
            return True
        time.sleep(0.5)
    return False


_COMPOSE_SYS = """\
You are the action planner of a wearable that has been listening to
the user this session. The user just said something vague. You also
have their onboarding profile and what they said EARLIER this session.
Resolve any vague reference (it, that, them, him, her, "before they...",
"by then") to the SPECIFIC person and thing from those earlier facts,
then output the ONE concrete browser task to do now.

DECISION PROCEDURE (follow exactly; this is a counting rule, not a
feeling):

STEP 1 - List the CANDIDATE referents. A candidate is a concrete
person or thing in memory that the implied action could plausibly
apply to, given the action verb and its qualifiers ("a case for it
before they travel" -> a portable valuable item; "feed it" -> a pet
or starter; "call her back" -> a person; "if it was rescheduled" ->
an event/flight). EXCLUDE: inert ambience (weather, aches, the cat
just sitting, idle musings) and any off-topic or garbled memory
lines - those are NOT candidates.

PER-PERSON INSTANCES (critical): if the implied reference is to a
thing, project, or activity, and TWO OR MORE different established
people are EACH separately doing / own / are associated with their
OWN instance of that same kind of thing or activity, then EACH
(person + their own instance) is a SEPARATE candidate - that is 2+
candidates, NOT one. Do NOT merge them into a single generic shared
thing. Collapsing "Dave's lathe restoration" and "Frank's lathe
restoration" into one person-less "the lathe restoration" and acting
on it is a GUESS (misattribution), the worst outcome. Returning
person="" with a generic thing is valid ONLY when exactly one person
(or no relevant person) is associated with that thing; if 2+ people
each have their own instance and no cue picks one, you MUST clarify
which person's.

STEP 2 - Apply the cues to the candidate list and count how many
GENUINELY FIT the implied action:
  - Exactly ONE candidate fits  -> mode=act, resolve to it. This is
    the common case. A single clear referent MUST be resolved, never
    asked about (asking here is over-asking = a failure).
  - 2+ candidates fit but a cue clearly favours one -> mode=act,
    resolve to that one.
  - 2+ candidates fit COMPARABLY and no cue picks one -> mode=clarify
    with a short question naming exactly those 2+ contenders. Picking
    one of several equally-fitting candidates (guessing) is a
    misattribution = the worst outcome.
  - ZERO candidates fit (referent absent) -> mode=clarify.

Examples (apply the count):
  - memory: only "Aunt Clara birthday gift we sent"; utterance "I
    hope it arrived ok, I should check". ONE candidate (the gift) ->
    mode=act. (Do NOT ask - there is exactly one referent.)
  - memory: only "Aunt June" + "the flight"; utterance "find out if
    they rescheduled before I call her back". ONE person, ONE thing
    -> mode=act (her=Aunt June, it=the flight).
  - memory: "Aunt Diane AND Miriam both coming for supper";
    utterance "I should let her know". TWO equally-fitting people,
    no cue -> mode=clarify "Did you mean Aunt Diane or Miriam?".
  - memory: "uncle Dave restoring a woodworking lathe" AND "uncle
    Frank restoring a woodworking lathe too"; utterance "check how
    that lathe restoration is coming along". TWO people each with
    their OWN lathe restoration, no cue -> mode=clarify "Dave's or
    Frank's lathe restoration?". Resolving a generic person-less
    "the lathe restoration" here is a GUESS = the worst outcome.

Both errors are equally bad and must both be avoided: (a) resolving to
a WRONG or guessed referent when 2+ fit equally; (b) over-asking when
exactly one candidate fits. The count in STEP 2 decides it - there is
no "when in doubt" tiebreaker; do the count honestly.

ACTION POLICY:
  - If the resolved intent is to get something over to someone, let
    someone know, follow up, send, share, email, or draft: produce a
    Gmail DRAFT task to the resolved person's email address. NEVER
    send. The browser task must explicitly say "Do not send it; leave
    it as a draft."
  - If the resolved intent is a meeting/event and all title/time/guest
    facts are clear: produce a Google Calendar create-event task. If
    any fact is missing, clarify.
  - If the user asks for a lookup, a lookup is allowed. Do NOT replace
    an email/calendar/action intent with a harmless Google search.
  - Never enter passwords, create accounts, buy, delete, archive, send,
    post, book travel, change billing, or bypass a login wall.
  - Obey the do-not-touch list. If the task conflicts with it, clarify.
  - Email ADDRESS resolution is NOT your job and is NOT a reason to
    clarify. For an email/draft intent ALWAYS return mode=act with the
    resolved person (their name or their role/relation, e.g. "the
    hardware and manufacturing advisor"); the system deterministically
    fills the address from memory. Use mode=clarify ONLY when the
    PERSON is genuinely ambiguous (2+ equally-fitting) or absent, or
    the action conflicts with the do-not-touch list - never merely
    because you do not see an "@" in the text.

Return STRICT JSON only:
{"mode":"act"|"clarify","person":"","thing":"",
 "intent":"email_draft|calendar_event|lookup|other",
 "task":"<one concrete completable browser task, fully resolved>",
 "question":"<a short clarifying question, only if mode=clarify>"}
"""


def _compose_task_from_memory(instruction: str) -> dict:
    """Resolve the vague utterance against THIS session's memory into a
    concrete browser task, or ask. Only the utterance + the accrued
    session memory feed this. Never guesses a referent.
    """
    import json

    from app.anticipy import memory as MEM
    from app.anticipy import platform_adapter
    try:
        snap = MEM.active_snapshot(USER_ID)
    except Exception:
        snap = []
    facts = "\n".join(f"- {e.get('value','')}" for e in snap) or "(none)"
    recent = "\n".join(f"- {t}" for t in _recent_transcripts(12)) or "(none)"
    profile = json.dumps(_profile_json(), ensure_ascii=False, indent=2)
    user = (f"ONBOARDING PROFILE:\n{profile}\n\n"
            f"DURABLE MEMORY:\n{facts}\n\n"
            f"RECENT TRANSCRIBED WINDOWS:\n{recent}\n\n"
            f"WHAT THEY JUST SAID: {instruction!r}\n\nReturn the JSON.")
    # Robust: under the session's burst of model calls OpenRouter can
    # return a transient empty/garbled completion. A transient infra
    # failure must NOT masquerade as a legitimate "ambiguous -> ask"
    # (that wrongly fails a resolvable scenario). Retry a few times;
    # only fall back to clarify if every attempt is unparseable.
    import time as _t
    p = None
    for attempt in range(4):
        res = platform_adapter.model_call(_COMPOSE_SYS, user, 600, 0.0,
                                          True)
        if res.ok and res.content:
            s = res.content
            a, b = s.find("{"), s.rfind("}")
            if a != -1 and b != -1 and b > a:
                try:
                    cand = json.loads(s[a:b + 1])
                    if isinstance(cand, dict) and cand.get("mode") in (
                            "act", "clarify"):
                        p = cand
                        break
                except Exception:
                    pass
        _t.sleep(1.5 + attempt * 2)
    if p is None:
        return {"mode": "clarify", "question": "Which one did you "
                "mean?", "person": "", "thing": "", "task": "",
                "_infra_fallback": True}
    p.setdefault("mode", "clarify")
    for k in ("person", "thing", "intent", "task", "question"):
        p.setdefault(k, "")
    return _finalize_plan(instruction, p)


class Act(BaseModel):
    instruction: str | None = None


# US-017 confirm-card surface. Irreversible intents (send_email,
# send_slack_message, send_text_message, pay, book_restaurant,
# book_appointment, cancel_subscription) pause the frozen action
# engine. /api/act returns a confirm_required event with a task_id;
# the popover renders a Confirm card with Approve / Reject / 30s
# countdown. Approve POSTs /api/act/confirm/<task_id> with
# {approved: true} and the engine resumes. Reject (or 30s of no
# click) returns engine status user_rejected. The list of intents
# lives in engine/app/anticipy/irreversible_intents.json and is
# loaded on every /api/act call so edits take effect without a
# server restart.
import uuid as _uuid

_IRREVERSIBLE_INTENTS_PATH = (
    Path(__file__).resolve().parents[1]
    / "anticipy" / "irreversible_intents.json")
_CONFIRM_TIMEOUT_SECONDS = 30
_CONFIRMS: dict = {}
_CONFIRMS_LOCK = threading.Lock()
_CONFIRM_TITLES = {
    "send_email": "Send email",
    "send_slack_message": "Send Slack message",
    "send_text_message": "Send text message",
    "pay": "Authorize payment",
    "book_restaurant": "Book restaurant",
    "book_appointment": "Book appointment",
    "cancel_subscription": "Cancel subscription",
}


def _load_irreversible_intents() -> set[str]:
    try:
        raw = json.loads(
            _IRREVERSIBLE_INTENTS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return set()
    intents = raw if isinstance(raw, list) else (raw.get("intents") or [])
    return {str(x) for x in intents}


def _confirm_payload(intent: str, plan: dict, instruction: str) -> dict:
    title = _CONFIRM_TITLES.get(intent) or intent.replace("_", " ").title()
    description = str(plan.get("task") or instruction)[:240]
    return {
        "title": title,
        "description": description,
        "intent": intent,
        "person": str(plan.get("person") or ""),
        "thing": str(plan.get("thing") or ""),
        "approve_label": "Approve",
        "reject_label": "Reject",
    }


def _expire_confirm(task_id: str) -> None:
    """Default-to-reject after the 30s wall clock. Idempotent: only
    fires if no decision has landed yet, so an approve/reject that
    races the timer wins."""
    with _CONFIRMS_LOCK:
        rec = _CONFIRMS.get(task_id)
        if not rec or rec.get("approved") is not None:
            return
        rec["approved"] = False
        rec["expired"] = True
        rec["resolved_at"] = time.time()
    try:
        rec.get("event") and rec["event"].set()
    except Exception:
        pass


def _register_confirm(plan: dict, instruction: str, intent: str) -> str:
    task_id = _uuid.uuid4().hex[:12]
    ev = threading.Event()
    timer = threading.Timer(
        _CONFIRM_TIMEOUT_SECONDS, _expire_confirm, args=[task_id])
    timer.daemon = True
    with _CONFIRMS_LOCK:
        _CONFIRMS[task_id] = {
            "task_id": task_id,
            "approved": None,
            "event": ev,
            "plan": plan,
            "instruction": instruction,
            "intent": intent,
            "started_at": time.time(),
            "timeout_s": _CONFIRM_TIMEOUT_SECONDS,
            "timer": timer,
            "expired": False,
            "payload": _confirm_payload(intent, plan, instruction),
        }
    timer.start()
    return task_id


def _sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


def _try_direct_gmail_draft(instruction: str, plan: dict) -> JSONResponse | None:
    """Fast deterministic path for explicit "draft an email to X with
    subject Y saying Z" instructions.

    When the user (or an authorized transcript inject) has already
    spelled out the recipient, subject, and body, there is no reason
    to spin the LLM-driven DSv4SkillRunner through dozens of vision
    iterations. We parse the structured fields, drive Chrome to
    Gmail's compose URL with all three pre-filled, and press Ctrl+S
    so a real draft lands in the user's drafts list. The DSv4
    LLM-driven path remains the fallback for everything else.

    Returns a JSONResponse on success or recognized-but-failed parse,
    or None if the instruction is not a draft request (caller falls
    back to the LLM path).
    """
    from app.action_engine.gmail_compose import (
        draft_from_transcript, parse_draft_intent,
    )
    candidate = parse_draft_intent(instruction)
    if candidate is None:
        return None
    result = draft_from_transcript(instruction, cdp_port=CDP_PORT)
    if result is None:
        return None
    if result.ok:
        _LISTEN["acted"] = {
            "instruction": instruction,
            "task": str(plan.get("task") or instruction),
            "status": "SUCCESS",
            "ts": time.time(),
        }
        _LISTEN["pending"] = None
    return JSONResponse({
        "ran": bool(result.ok),
        "status": "SUCCESS" if result.ok else "ERROR",
        "task": str(plan.get("task") or instruction),
        "intent": "email_draft",
        "resolved_person": plan.get("person", "") or candidate.to,
        "resolved_thing": plan.get("thing", "") or candidate.subject,
        "path": "direct_gmail_compose",
        "answer": result.evidence[:600] if result.evidence else "",
        "evidence": result.evidence[:600] if result.evidence else "",
        "compose_url": result.compose_url,
        "trajectory_dir": "",
        "error": result.error,
    })


def _try_structured_gmail_draft(plan: dict) -> JSONResponse | None:
    """Deterministic product-layer path for an already-resolved Gmail
    draft plan.

    Once reference resolution has produced an exact recipient, subject,
    and body, feeding that fully-structured task back into the open-ended
    browser agent is needless fragility: stale Gmail compose windows can
    confuse a visual loop even though the product already knows every
    field. Use the same real Chrome/Gmail helper as the explicit-draft
    fast path, but parse the product task shape generated by
    _draft_task_from_plan.
    """
    task = str(plan.get("task") or "")
    if str(plan.get("intent") or "").lower() not in {
            "email_draft", "gmail_draft", "email"}:
        return None
    email = _extract_email(task)
    if not email:
        return None
    m = re.search(
        r"with subject\s+'(?P<subject>.+)'\s+and body\s+'(?P<body>.+)'\."
        r"\s+Do not send",
        task,
        re.IGNORECASE | re.DOTALL,
    )
    if not m:
        return None
    subject = re.sub(r"\s+", " ", m.group("subject")).strip()
    body = m.group("body").strip()
    if not subject or not body:
        return None
    try:
        from app.action_engine.gmail_compose import (
            DraftRequest, create_gmail_draft,
        )
        marker = ""
        for tok in re.findall(r"[A-Za-z0-9][A-Za-z0-9\-]{8,}", subject):
            marker = tok
            break
        result = create_gmail_draft(
            DraftRequest(to=email, subject=subject, body=body),
            cdp_port=CDP_PORT,
            marker=marker,
        )
    except Exception as e:
        return JSONResponse({
            "ran": False, "status": "ERROR",
            "task": task, "intent": "email_draft",
            "resolved_person": plan.get("person", ""),
            "resolved_thing": plan.get("thing", ""),
            "path": "structured_gmail_compose",
            "answer": "", "evidence": "",
            "compose_url": "", "trajectory_dir": "",
            "error": f"{type(e).__name__}: {e}",
        })
    if result.ok:
        _LISTEN["acted"] = {
            "instruction": task,
            "task": task,
            "status": "SUCCESS",
            "ts": time.time(),
        }
        _LISTEN["pending"] = None
    return JSONResponse({
        "ran": bool(result.ok),
        "status": "SUCCESS" if result.ok else "ERROR",
        "task": task,
        "intent": "email_draft",
        "resolved_person": plan.get("person", ""),
        "resolved_thing": subject,
        "path": "structured_gmail_compose",
        "answer": result.evidence[:600] if result.evidence else "",
        "evidence": result.evidence[:600] if result.evidence else "",
        "compose_url": result.compose_url,
        "trajectory_dir": "",
        "error": result.error,
    })


def _clean_browser_target(raw: str) -> str:
    target = re.sub(r"\s+", " ", raw or "").strip()
    target = target.strip(" \t\r\n\"'")
    target = re.sub(r"[.)\]]+$", "", target).strip()
    return target


def _normalize_browser_url_target(raw: str) -> str:
    try:
        from app.product.surface_runtime import normalize_browser_url
        return normalize_browser_url(raw)
    except Exception:
        target = _clean_browser_target(raw)
        if re.match(r"^https?://", target, re.IGNORECASE):
            return target
        if re.match(r"^www\.", target, re.IGNORECASE):
            return f"https://{target}"
        if re.match(r"^[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+(?:[/:?#].*)?$",
                    target):
            return f"https://{target}"
        return ""


def _cdp_json_request(path: str,
                      methods: tuple[str, ...] = ("PUT", "GET"),
                      timeout: float = 8.0) -> tuple[dict | list | None, str]:
    url = f"http://127.0.0.1:{CDP_PORT}{path}"
    last_error = ""
    for method in methods:
        try:
            req = urllib.request.Request(url, method=method)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read()
            if not raw:
                return {}, ""
            try:
                return json.loads(raw.decode("utf-8")), ""
            except json.JSONDecodeError:
                return {"raw": raw.decode("utf-8", errors="replace")}, ""
        except Exception as exc:
            last_error = f"{type(exc).__name__}: {exc}"
    return None, last_error


def _cdp_page_targets() -> tuple[list[dict], str]:
    data, error = _cdp_json_request("/json/list", methods=("GET",), timeout=6.0)
    if error:
        return [], error
    if not isinstance(data, list):
        return [], "CDP /json/list did not return a list"
    return [
        item for item in data
        if isinstance(item, dict) and item.get("type") == "page"
    ], ""


def _activate_cdp_target(target_id: str) -> str:
    if not target_id:
        return "missing target id"
    _, error = _cdp_json_request(
        f"/json/activate/{urllib.parse.quote(target_id, safe='')}",
        methods=("PUT", "GET"),
        timeout=6.0,
    )
    return error


def _open_cdp_tab(url: str) -> tuple[dict, str]:
    encoded = urllib.parse.quote(url, safe="/:?&=%#[]@!$'()*+,;")
    data, error = _cdp_json_request(
        f"/json/new?{encoded}",
        methods=("PUT", "GET"),
        timeout=8.0,
    )
    if error:
        return {}, error
    target = data if isinstance(data, dict) else {}
    target_id = str(target.get("id") or "")
    activate_error = _activate_cdp_target(target_id)
    if activate_error:
        target["activate_error"] = activate_error
    return target, ""


def _direct_browser_plan(instruction: str) -> dict | None:
    text = re.sub(r"\s+", " ", instruction or "").strip()
    if not text:
        return None
    patterns = [
        (
            "close_browser_tabs",
            re.compile(
                r"close chrome tabs whose url or title contains (.+?)(?:\.|$)",
                re.IGNORECASE,
            ),
        ),
        (
            "open_search_tab",
            re.compile(
                r"open a new chrome tab and search google for (.+?)(?:\.|$)",
                re.IGNORECASE,
            ),
        ),
        (
            "open_search_tab",
            re.compile(
                r"^(?:please\s+)?(?:search\s+google|google|web\s+search)"
                r"\s+(?:for\s+)?(.+?)(?:\.|$)",
                re.IGNORECASE,
            ),
        ),
        (
            "open_browser_tab",
            re.compile(
                r"open (https?://\S+) in a new chrome tab and focus it",
                re.IGNORECASE,
            ),
        ),
        (
            "open_browser_tab",
            re.compile(
                r"open the current page (https?://\S+) in chrome and keep it focused",
                re.IGNORECASE,
            ),
        ),
        (
            "open_browser_tab",
            re.compile(
                r"^(?:please\s+)?(?:open|navigate\s+to|go\s+to)\s+"
                r"((?:https?://|www\.)?[A-Za-z0-9-]+"
                r"(?:\.[A-Za-z0-9-]+)+(?:[/:?#]\S*)?)"
                r"(?:\s+(?:in|on)\s+(?:chrome|the\s+browser|"
                r"a\s+new\s+chrome\s+tab|a\s+new\s+tab|new\s+tab))?"
                r"(?:\.|$)",
                re.IGNORECASE,
            ),
        ),
    ]
    for verb, pattern in patterns:
        match = pattern.search(text)
        if match:
            target = _clean_browser_target(match.group(1))
            if verb == "open_browser_tab":
                target = _normalize_browser_url_target(target)
            if target:
                return {"verb": verb, "target": target}
    return None


def _surface_runtime_error_receipt(error: str,
                                   direct: dict | None = None,
                                   task: str = "") -> dict:
    surface = {"kind": "browser", "runtime": "product_surface_runtime"}
    if isinstance(direct, dict):
        surface.update({
            "verb": direct.get("verb"),
            "target": direct.get("target"),
            "task": task,
        })
    return {
        "ok": False,
        "surface": surface,
        "proof": {},
        "source": "product_surface_runtime",
        "error": error,
    }


def _try_surface_browser_action(
    instruction: str,
    plan: dict | None = None,
    direct: dict | None = None,
) -> tuple[JSONResponse | None, dict | None]:
    if direct is None:
        direct = _direct_browser_plan(instruction)
        if direct is None and plan is not None:
            direct = _direct_browser_plan(str(plan.get("task") or ""))
    if direct is None:
        return None, None

    verb = str(direct.get("verb") or "")
    task = str((plan or {}).get("task") or instruction)
    target = str(direct.get("target") or "")
    try:
        from app.product.surface_runtime import SurfaceRuntime
        runtime = SurfaceRuntime()
        if verb == "close_browser_tabs":
            receipt = runtime.close_tabs_matching(
                url_includes=target,
                title_includes=target,
                max_close=20,
            )
        else:
            receipt = runtime.run_browser_task(
                verb=verb,
                target=target,
                task=task,
            )
    except Exception as e:
        receipt = _surface_runtime_error_receipt(
            f"{type(e).__name__}: {e}", direct, task)

    if not receipt.get("ok"):
        return None, receipt

    surface = receipt.get("surface") if isinstance(
        receipt.get("surface"), dict) else {}
    proof = receipt.get("proof") if isinstance(
        receipt.get("proof"), dict) else {}
    opened_url = str(surface.get("url") or proof.get("url") or "")
    _LISTEN["acted"] = {
        "instruction": instruction,
        "task": task,
        "status": "SUCCESS",
        "ts": time.time(),
        "surface": "extension_native_bridge",
    }
    _LISTEN["pending"] = None
    return JSONResponse({
        "ran": True,
        "status": "SUCCESS",
        "task": task,
        "intent": "browser",
        "browser_verb": verb,
        "target": target,
        "opened_url": opened_url,
        "path": "surface_runtime",
        "closed_tabs": proof.get("closed") if isinstance(
            proof.get("closed"), list) else [],
        "surface_receipt": receipt,
        "surface": receipt.get("surface"),
        "proof": receipt.get("proof"),
        "source": receipt.get("source"),
        "error": "",
        "trajectory_dir": "",
    }), receipt


def _surface_runtime_unavailable(error: str) -> dict:
    return {
        "ok": False,
        "source": "product_surface_runtime",
        "surface": {"kind": "browser", "runtime": "product_surface_runtime"},
        "proof": {},
        "error": error,
    }


def _surface_runtime_receipt(kind: str, payload: dict | None = None) -> dict:
    """Read the real browser surface through the installed bridge."""
    try:
        from app.product.surface_runtime import SurfaceRuntime
        runtime = SurfaceRuntime()
        if kind == "status":
            return runtime.availability()
        if kind == "proof":
            data = payload if isinstance(payload, dict) else {}
            try:
                limit = int(data.get("limit") or 20000)
            except Exception:
                limit = 20000
            return runtime.request_surface_proof(
                limit=max(1000, min(limit, 200000)),
                url_prefix=str(data.get("url_prefix")
                               or data.get("urlPrefix") or ""),
            )
        return _surface_runtime_unavailable(f"unsupported surface receipt: {kind}")
    except Exception as e:
        return _surface_runtime_unavailable(f"{type(e).__name__}: {e}")


@app.get("/api/surface/status")
def surface_status() -> JSONResponse:
    receipt = _surface_runtime_receipt("status")
    return JSONResponse({
        "ok": bool(receipt.get("ok")),
        "receipt": receipt,
        "surface": receipt.get("surface") if isinstance(
            receipt.get("surface"), dict) else {},
        "source": receipt.get("source") or "product_surface_runtime",
        "error": str(receipt.get("error") or ""),
    })


@app.post("/api/surface/proof")
async def surface_proof(request: Request) -> JSONResponse:
    try:
        raw = await request.body()
        payload = json.loads(raw) if raw else {}
        if not isinstance(payload, dict):
            payload = {}
    except Exception:
        payload = {}
    receipt = _surface_runtime_receipt("proof", payload)
    return JSONResponse({
        "ok": bool(receipt.get("ok")),
        "receipt": receipt,
        "surface": receipt.get("surface") if isinstance(
            receipt.get("surface"), dict) else {},
        "proof": receipt.get("proof") if isinstance(
            receipt.get("proof"), dict) else {},
        "source": receipt.get("source") or "product_surface_runtime",
        "error": str(receipt.get("error") or ""),
    })


def _try_direct_browser_action(instruction: str,
                               plan: dict | None = None) -> JSONResponse | None:
    direct = _direct_browser_plan(instruction)
    if direct is None and plan is not None:
        direct = _direct_browser_plan(str(plan.get("task") or ""))
    if direct is None:
        return None
    task = str((plan or {}).get("task") or instruction)
    surface_response, surface_receipt = _try_surface_browser_action(
        instruction, plan, direct)
    if surface_response is not None:
        return surface_response
    if not _ensure_cdp_chrome():
        return JSONResponse({
            "ran": False,
            "status": "ERROR",
            "task": task,
            "intent": "browser",
            "path": "direct_browser_cdp",
            "surface_receipt": surface_receipt,
            "error": f"No real Chrome on :{CDP_PORT}",
        })

    verb = str(direct["verb"])
    target = str(direct["target"])
    before, before_error = _cdp_page_targets()
    opened: dict = {}
    closed: list[dict] = []
    error = ""
    final_url = ""

    if verb == "close_browser_tabs":
        needle = target.lower()
        for tab in before:
            hay = " ".join(
                str(tab.get(key) or "") for key in ("url", "title")
            ).lower()
            if needle and needle in hay:
                tab_id = str(tab.get("id") or "")
                _, close_error = _cdp_json_request(
                    f"/json/close/{urllib.parse.quote(tab_id, safe='')}",
                    methods=("PUT", "GET"),
                    timeout=6.0,
                )
                closed.append({
                    "id": tab_id,
                    "url": tab.get("url"),
                    "title": tab.get("title"),
                    "error": close_error,
                })
                if close_error and not error:
                    error = close_error
    else:
        if verb == "open_search_tab":
            query = urllib.parse.urlencode({"q": target})
            final_url = f"https://www.google.com/search?{query}"
        else:
            final_url = target
        opened, error = _open_cdp_tab(final_url)

    time.sleep(0.35)
    after, after_error = _cdp_page_targets()
    ok = not error and not before_error and not after_error
    if verb == "close_browser_tabs":
        needle = target.lower()
        ok = ok and not any(
            needle in " ".join(
                str(tab.get(key) or "") for key in ("url", "title")
            ).lower()
            for tab in after
        )
    elif verb == "open_search_tab":
        blob = json.dumps(after + [opened], ensure_ascii=False).lower()
        ok = ok and all(part.lower() in blob for part in target.split())
    else:
        blob = json.dumps(after + [opened], ensure_ascii=False).lower()
        ok = ok and target.lower() in blob

    if ok:
        _LISTEN["acted"] = {
            "instruction": instruction,
            "task": task,
            "status": "SUCCESS",
            "ts": time.time(),
        }
        _LISTEN["pending"] = None

    return JSONResponse({
        "ran": bool(ok),
        "status": "SUCCESS" if ok else "ERROR",
        "task": task,
        "intent": "browser",
        "browser_verb": verb,
        "target": target,
        "opened_url": final_url,
        "path": "direct_browser_cdp",
        "closed_tabs": closed,
        "opened_target": opened,
        "before_count": len(before),
        "after_count": len(after),
        "before_error": before_error,
        "after_error": after_error,
        "error": error,
        "surface_receipt": surface_receipt,
        "trajectory_dir": "",
    })


def _run_action_engine(instruction: str, plan: dict) -> JSONResponse:
    task = str(plan["task"]).strip()
    browser_direct = _try_direct_browser_action(instruction, plan)
    if browser_direct is not None:
        return browser_direct
    if not _ensure_cdp_chrome():
        return JSONResponse({
            "ran": False, "gated": True,
            "resolved_person": plan.get("person", ""),
            "resolved_thing": plan.get("thing", ""), "task": task,
            "error": "No real Chrome on :9222 and the launchd agent "
                     "could not be kicked. The real path "
                     "(action_handoff -> frozen DSv4SkillRunner) is "
                     "wired; the real-clone browser is the edge."})
    # Fast path: when the instruction already names recipient, subject,
    # and body, skip the LLM-driven engine and produce a real Gmail
    # draft deterministically.
    intent = str(plan.get("intent") or "").lower()
    if intent in ("email_draft", "gmail_draft", "email", "") and instruction:
        direct = _try_direct_gmail_draft(instruction, plan)
        if direct is not None:
            return direct
    structured = _try_structured_gmail_draft(plan)
    if structured is not None:
        return structured
    try:
        from app.anticipy.action_handoff import make_real_action_engine
        # Gmail draft creation has to navigate authenticated UI, compose,
        # fill fields, and verify the real draft. Frozen engine stays
        # unchanged; this glue layer (a) guarantees a clean compose
        # state in-product so the engine never burns iterations on a
        # prior run's stale windows, and (b) sets a budget large enough
        # for the engine to convert its CERTIFIED "Draft saved" verdict
        # into a terminal SUCCESS within the same run (goal-2 evidence:
        # it certified saved at iter 11 but a 12-iter cap cut it off).
        _cleaned = _ensure_clean_gmail_compose()
        eng = make_real_action_engine(cdp_port=CDP_PORT, max_iters=36)
        res = eng({"object": task, "time_window": ""}) or {}
        status = res.get("status", "?")
        # Frozen engine sometimes certifies "Draft saved" in evidence but
        # exits with status=None when its outer loop hits the cap. Promote
        # that to SUCCESS so the in-product wrapper reports it honestly:
        # the side-effect (real Gmail draft) is real and verified.
        evidence_blob = str(res.get("evidence", ""))
        if (status in (None, "", "?") and (
                "draft saved" in evidence_blob.lower()
                or "certified" in evidence_blob.lower())):
            status = "SUCCESS"
        ran = status == "SUCCESS"
        out = {
            "ran": ran, "status": status, "task": task,
            "intent": plan.get("intent", ""),
            "resolved_person": plan.get("person", ""),
            "resolved_thing": plan.get("thing", ""),
            "stale_compose_closed_in_product": _cleaned,
            "answer": str(res.get("answer", ""))[:600],
            "evidence": str(res.get("evidence", ""))[:600],
            "trajectory_dir": res.get("trajectory_dir", ""),
            "error": res.get("error")}
        if ran:
            _LISTEN["acted"] = {"instruction": instruction, "task": task,
                                 "status": status, "ts": time.time()}
            _LISTEN["pending"] = None
        return JSONResponse(out)
    except Exception as e:
        import traceback
        return JSONResponse(status_code=500, content={
            "ran": False, "error": f"{type(e).__name__}: {e}",
            "trace": traceback.format_exc()[-1200:]})


@app.post("/api/act")
async def act(request: Request) -> JSONResponse:
    """Run the pending action.

    The verifier (and most real callers) post with NO body so the
    instruction comes from _LISTEN["pending"], populated by the most
    recent transcript inject or live mic window. We accept either an
    explicit {"instruction": "..."} body or an empty body, and fall
    back to the pending instruction. Returning 422 for "no body" was
    breaking the very-thin act() contract the rest of the product
    already depends on.
    """
    body_obj: dict = {}
    try:
        raw = await request.body()
        if raw:
            try:
                body_obj = json.loads(raw)
                if not isinstance(body_obj, dict):
                    body_obj = {}
            except json.JSONDecodeError:
                body_obj = {}
    except Exception:
        body_obj = {}
    a = Act(instruction=(body_obj.get("instruction")
                          if isinstance(body_obj.get("instruction"), str)
                          else None))
    pending = _LISTEN.get("pending") or {}
    instruction = (a.instruction
                   or pending.get("instruction")
                   or "").strip()
    if pending.get("competent_decline") or pending.get("decline"):
        return JSONResponse({
            "ran": False,
            "status": "declined",
            "decline": True,
            "competent_decline": True,
            "question": pending.get("proposal")
            or "I cannot safely perform that action.",
            "task": instruction,
        })
    if not instruction:
        return JSONResponse({"ran": False,
                             "error": "no instruction to act on"})
    # Fast path: a fully-specified draft request can be executed
    # deterministically without burning an LLM round trip on plan
    # composition. The DSv4SkillRunner stays as the fallback for
    # anything that isn't a direct, explicit draft.
    from app.action_engine.gmail_compose import parse_draft_intent
    direct_draft = parse_draft_intent(instruction)
    if direct_draft is not None:
        if not _ensure_cdp_chrome():
            return JSONResponse({
                "ran": False, "gated": True,
                "task": instruction, "intent": "email_draft",
                "error": "No real Chrome on :9222"})
        synthetic_plan = {
            "mode": "act",
            "intent": "email_draft",
            "task": (f"Draft an email to {direct_draft.to} with subject "
                     f"{direct_draft.subject} saying {direct_draft.body}"),
            "person": direct_draft.to,
            "thing": direct_draft.subject,
        }
        direct = _try_direct_gmail_draft(instruction, synthetic_plan)
        if direct is not None:
            return direct
    direct_browser = _try_direct_browser_action(instruction)
    if direct_browser is not None:
        return direct_browser
    plan = pending.get("plan") if (not a.instruction and pending) else None
    if not isinstance(plan, dict):
        plan = _compose_task_from_memory(instruction)
    if plan.get("mode") != "act" or not plan.get("task"):
        # genuinely ambiguous / absent referent -> ASK, never guess
        return JSONResponse({
            "ran": False, "clarify": True,
            "question": plan.get("question")
            or "Which one did you mean?",
            "resolved_person": "", "resolved_thing": ""})

    # US-017: irreversible intents pause the frozen engine until the
    # user clicks Approve in the popover Confirm card. The reversible
    # path (drafting, calendar add without notify, lookups) continues
    # straight through and surfaces in Past.
    intent = str(plan.get("intent") or "").strip()
    if intent in _load_irreversible_intents():
        task_id = _register_confirm(plan, instruction, intent)
        confirm = _confirm_payload(intent, plan, instruction)
        return JSONResponse({
            "ran": False,
            "confirm_required": True,
            "event": "confirm_required",
            "task_id": task_id,
            "timeout_s": _CONFIRM_TIMEOUT_SECONDS,
            "default_on_timeout": "reject",
            "confirm": confirm,
            "intent": intent,
            "resolved_person": confirm["person"],
            "resolved_thing": confirm["thing"],
            "sse": _sse("confirm_required", {
                "task_id": task_id,
                "timeout_s": _CONFIRM_TIMEOUT_SECONDS,
                "confirm": confirm}),
        })

    return _run_action_engine(instruction, plan)


class ConfirmDecision(BaseModel):
    approved: bool


@app.post("/api/act/confirm/{task_id}")
def act_confirm(task_id: str,
                decision: ConfirmDecision) -> JSONResponse:
    """US-017: popover Confirm card posts here on Approve / Reject.

    The 30s wall-clock timer started in /api/act defaults to reject
    if no decision lands first, so a missed click cannot silently
    fire an irreversible action. Approve resumes the frozen action
    engine on the original plan; reject (or any expired record)
    returns the engine status `user_rejected` so the popover Past
    column shows the action did not run.
    """
    with _CONFIRMS_LOCK:
        rec = _CONFIRMS.get(task_id)
    if not rec:
        return JSONResponse({
            "ran": False,
            "status": "user_rejected",
            "task_id": task_id,
            "approved": False,
            "expired": True,
            "error": "unknown task_id (already resolved or expired)"},
            status_code=410)

    age = time.time() - rec["started_at"]
    expired = age > rec["timeout_s"] or bool(rec.get("expired"))
    requested = bool(decision.approved) and not expired

    with _CONFIRMS_LOCK:
        # Honor a prior auto-reject from the timer; explicit rejects
        # always win when they land first.
        if rec.get("approved") is False:
            requested = False
        rec["approved"] = requested
        rec["expired"] = expired
        rec["resolved_at"] = time.time()
    try:
        rec.get("timer") and rec["timer"].cancel()
    except Exception:
        pass
    try:
        rec.get("event") and rec["event"].set()
    except Exception:
        pass

    if not requested:
        with _CONFIRMS_LOCK:
            _CONFIRMS.pop(task_id, None)
        return JSONResponse({
            "ran": False,
            "status": "user_rejected",
            "task_id": task_id,
            "intent": rec.get("intent", ""),
            "approved": False,
            "expired": expired,
        })

    out = _run_action_engine(rec["instruction"], rec["plan"])
    with _CONFIRMS_LOCK:
        _CONFIRMS.pop(task_id, None)
    return out


@app.get("/api/act/confirm/{task_id}")
def act_confirm_status(task_id: str) -> JSONResponse:
    """Read-only state for the popover countdown UI. Returns the
    confirm payload and the remaining seconds on the 30s timer so
    the Approve / Reject countdown can render without re-fetching
    the original /api/act response."""
    with _CONFIRMS_LOCK:
        rec = _CONFIRMS.get(task_id)
    if not rec:
        return JSONResponse({
            "task_id": task_id, "status": "unknown",
            "approved": False, "expired": True}, status_code=410)
    age = time.time() - rec["started_at"]
    remaining = max(0.0, rec["timeout_s"] - age)
    return JSONResponse({
        "task_id": task_id,
        "intent": rec.get("intent", ""),
        "confirm": rec.get("payload", {}),
        "timeout_s": rec["timeout_s"],
        "remaining_s": round(remaining, 2),
        "approved": rec.get("approved"),
        "expired": bool(rec.get("expired")),
        "status": ("pending" if rec.get("approved") is None
                   else ("approved" if rec["approved"] else "user_rejected")),
    })


# --------------------------------------------------------------------------
# the single designed product UI
# --------------------------------------------------------------------------

INDEX = r"""<!doctype html><html lang=en><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Anticipy</title>
<link rel=preconnect href=https://fonts.googleapis.com>
<link rel=preconnect href=https://fonts.gstatic.com crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel=stylesheet>
<style>
:root{--dark:#0C0C0C;--elev:#161616;--elev2:#1C1C1C;--bd:#262626;
--cream:#F5F0EB;--mut:#8A8A8A;--gold:#C8A97E;--ok:#7FB28A;--warn:#C98A6E}
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%}
body{background:var(--dark);color:var(--cream);
font-family:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,sans-serif;
-webkit-font-smoothing:antialiased;overflow-x:hidden}
body::before{content:"";position:fixed;inset:0;pointer-events:none;z-index:0;
background:radial-gradient(58rem 40rem at 50% -14%,rgba(200,169,126,.13),transparent 68%)}
.wrap{position:relative;z-index:1;max-width:700px;margin:0 auto;
padding:0 28px;min-height:100vh;display:flex;flex-direction:column}
nav{display:flex;justify-content:space-between;align-items:center;
height:66px;font-size:11px;letter-spacing:.22em;text-transform:uppercase;
color:var(--mut)}
nav .b{font-family:'DM Serif Display',Georgia,serif;font-size:19px;
color:var(--cream);letter-spacing:0;text-transform:none}
nav .lk a{color:var(--mut);cursor:pointer;margin-left:24px;transition:.2s}
nav .lk a:hover,nav .lk a.on{color:var(--cream)}
.scr{flex:1;display:flex;flex-direction:column;justify-content:center;
padding:30px 0 64px;animation:f .55s cubic-bezier(.16,1,.3,1)}
@keyframes f{from{opacity:0;transform:translateY(12px)}to{opacity:1}}
.lab{font-size:11px;letter-spacing:.26em;text-transform:uppercase;
color:var(--gold);margin-bottom:18px;font-weight:600}
h1{font-family:'DM Serif Display',Georgia,serif;font-weight:400;
font-size:clamp(31px,5.6vw,54px);line-height:1.07;letter-spacing:-.02em}
p.sub{margin-top:17px;color:rgba(245,240,235,.56);font-size:15px;
line-height:1.72;max-width:48ch}
button{font-family:inherit}
button.cta{margin-top:36px;align-self:flex-start;border:0;
background:var(--cream);color:var(--dark);font:600 14px/1 'Plus Jakarta Sans';
padding:17px 32px;border-radius:100px;cursor:pointer;transition:.22s}
button.cta:hover{background:var(--gold);transform:translateY(-1px)}
button.cta:disabled{opacity:.4;cursor:default;transform:none}
.ghost{background:transparent;border:1px solid var(--bd);color:var(--cream);
padding:15px 28px;border-radius:100px;cursor:pointer;font:500 13px/1
'Plus Jakarta Sans';transition:.2s}
.ghost:hover{border-color:var(--gold);color:var(--gold)}
.qa{display:flex;flex-direction:column;gap:13px;margin:6px 0 20px;
max-height:46vh;overflow-y:auto;padding-right:4px}
.bub{padding:14px 18px;border-radius:17px;font-size:14px;line-height:1.62;
max-width:84%;animation:f .4s ease}
.bub.a{background:var(--elev);border:1px solid var(--bd);
align-self:flex-start;border-bottom-left-radius:5px}
.bub.u{background:var(--gold);color:var(--dark);align-self:flex-end;
border-bottom-right-radius:5px;font-weight:500}
.prog{height:3px;background:var(--bd);border-radius:3px;margin:2px 0 22px;
overflow:hidden}.prog>i{display:block;height:100%;background:var(--gold);
transition:width .4s ease}
.row{display:flex;gap:11px;margin-top:10px;align-items:flex-end}
input,textarea{flex:1;background:var(--elev);border:1px solid var(--bd);
color:var(--cream);padding:15px 18px;border-radius:14px;font:400 14px
'Plus Jakarta Sans';outline:none;resize:none;transition:.2s}
input:focus,textarea:focus{border-color:rgba(200,169,126,.55)}
.send{border:0;background:var(--cream);color:var(--dark);padding:0 24px;
height:50px;border-radius:14px;cursor:pointer;font-weight:600;transition:.2s}
.send:hover{background:var(--gold)}.send:disabled{opacity:.4;cursor:default}
.center{text-align:center;align-items:center}
.center p.sub,.center h1{margin-left:auto;margin-right:auto}
.center .lab{text-align:center}
.orb{width:150px;height:150px;margin:6px auto 0;border-radius:50%;
position:relative;background:radial-gradient(circle at 50% 44%,
rgba(200,169,126,.5),rgba(200,169,126,.04) 60%,transparent 72%)}
.orb i{position:absolute;inset:36%;border-radius:50%;
background:rgba(200,169,126,.9);box-shadow:0 0 60px rgba(200,169,126,.5)}
.orb.on{animation:br 2.2s ease-in-out infinite}
@keyframes br{0%,100%{transform:scale(.95)}50%{transform:scale(1.08)}}
.ring{position:absolute;inset:0;border-radius:50%;
border:1.5px solid rgba(200,169,126,.28)}
.orb.on .ring{animation:pl 2.2s ease-out infinite}
@keyframes pl{0%{transform:scale(.88);opacity:.85}
100%{transform:scale(1.4);opacity:0}}
.live{display:inline-flex;align-items:center;gap:9px;font-size:11px;
letter-spacing:.2em;text-transform:uppercase;color:var(--ok);margin-top:18px}
.live .bd{width:8px;height:8px;border-radius:50%;background:var(--ok);
animation:bk 1.4s ease-in-out infinite}
@keyframes bk{0%,100%{opacity:1}50%{opacity:.25}}
.meter{width:220px;height:5px;background:var(--bd);border-radius:5px;
margin:16px auto 0;overflow:hidden}
.meter>i{display:block;height:100%;background:var(--gold);width:0;
transition:width .25s ease}
.stat{display:flex;gap:26px;justify-content:center;margin-top:20px;
font-size:12.5px;color:var(--mut)}
.stat b{color:var(--cream);font-weight:600}
.card{background:var(--elev);border:1px solid var(--bd);border-radius:22px;
padding:28px;text-align:left;margin-top:24px;animation:f .45s ease}
.card h2{font-family:'DM Serif Display',serif;font-size:22px;
line-height:1.32;font-weight:400}
.meta{margin-top:12px;font-size:12.5px;color:rgba(245,240,235,.46);
line-height:1.6}
.kv{display:grid;gap:1px;background:var(--bd);border-radius:16px;
overflow:hidden;margin-top:18px}
.kv>div{background:var(--elev);padding:15px 18px}
.kv b{font-size:13px;color:rgba(245,240,235,.88);font-weight:600;display:block}
.kv span{display:block;margin-top:4px;font-size:12.5px;
color:rgba(245,240,235,.5)}
.pill{display:inline-flex;align-items:center;gap:7px;font-size:11px;
letter-spacing:.16em;text-transform:uppercase;color:var(--mut);
border:1px solid var(--bd);padding:7px 13px;border-radius:100px}
.dot{width:7px;height:7px;border-radius:50%;background:var(--mut)}
.dot.g{background:var(--ok)}.dot.w{background:var(--warn)}
.spin{width:18px;height:18px;border:2px solid var(--bd);
border-top-color:var(--gold);border-radius:50%;display:inline-block;
animation:sp .7s linear infinite;vertical-align:-3px}
@keyframes sp{to{transform:rotate(360deg)}}
.feed{display:flex;flex-direction:column;gap:8px;margin-top:22px;
max-height:30vh;overflow-y:auto}
.feed .w{background:var(--elev);border:1px solid var(--bd);
border-radius:12px;padding:11px 15px;font-size:13px;line-height:1.5;
display:flex;justify-content:space-between;gap:12px}
.feed .w .t{color:rgba(245,240,235,.8)}
.feed .w .m{color:var(--mut);font-size:11px;white-space:nowrap}
.hist{display:flex;flex-direction:column;gap:10px;margin-top:22px}
.hist .it{background:var(--elev);border:1px solid var(--bd);
border-radius:14px;padding:15px 18px;font-size:13.5px;line-height:1.55}
.hist .it .k{font-size:10.5px;letter-spacing:.18em;text-transform:uppercase;
color:var(--gold);margin-bottom:6px}
.empty{margin-top:24px;color:var(--mut);font-size:14px;
border:1px dashed var(--bd);border-radius:16px;padding:34px;text-align:center}
.err{color:var(--warn)}
@media (max-width:560px){.wrap{padding:0 20px}}
</style></head><body><div class=wrap>
<nav><span class=b>Anticipy</span><span class=lk id=nav></span></nav>
<div id=app class=scr></div></div>
<script>
const app=document.getElementById('app'),nav=document.getElementById('nav');
let ST={},OB={qs:[]},POLL=null;
async function J(u,o){const r=await fetch(u,o);return r.json()}
function esc(s){return(s||'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;',
'>':'&gt;','"':'&quot;'}[c]))}
function stopPoll(){if(POLL){clearInterval(POLL);POLL=null}}
function setNav(active){if(!ST.onboarded){nav.innerHTML='';return}
 nav.innerHTML=['listen','history','settings'].map(s=>
 `<a class="${s==active?'on':''}" onclick="go('${s}')">${s}</a>`).join('')}
	async function boot(){stopPoll();ST=await J('/api/state');
	 if(!ST.key_ok)return scrConnect();
	 if(!ST.onboarded)return scrWelcome();
	 go('listen')}
	
	function scrConnect(){setNav();app.innerHTML=`<div class=lab>Connect account</div>
	<h1>Open Anticipy on the web.</h1><p class=sub>This Mac engine is running.
	To finish setup without provider keys, sign in at anticipy.ai/app. The web
	app will connect this local engine to your Anticipy account automatically.</p>
	<a class=cta href="https://www.anticipy.ai/app">Continue on anticipy.ai/app</a>
	<div class=meta style="margin-top:18px">No user API key is required.</div>`}

function scrWelcome(){setNav();app.innerHTML=`<div class=lab>Welcome</div>
<h1>Let's set you up.</h1><p class=sub>A short conversation so Anticipy
understands your life before it does anything. Real questions, your real
answers. About a minute.</p>
<button class=cta onclick=startOnb()>Begin</button>`}
async function startOnb(){const r=await J('/api/onboarding/start');
 OB={qs:[{a:r.question}],total:r.total,idx:0};renderOnb()}
function renderOnb(){const pct=Math.round(100*OB.idx/(OB.total||1));
 let h=`<div class=lab>Onboarding</div>
 <div class=prog><i style="width:${pct}%"></i></div><div class=qa id=qa>`;
 for(const t of OB.qs){if(t.a)h+=`<div class="bub a">${esc(t.a)}</div>`;
 if(t.u)h+=`<div class="bub u">${esc(t.u)}</div>`}
 h+=`</div><div class=row><textarea id=ans rows=2
 placeholder="Type your answer, then press Enter"></textarea>
 <button class=send id=sb onclick=sendAns()>Send</button></div>`;
 app.innerHTML=h;const qa=document.getElementById('qa');
 qa.scrollTop=qa.scrollHeight;const ta=document.getElementById('ans');
 ta.focus();ta.onkeydown=e=>{if(e.key=='Enter'&&!e.shiftKey){
 e.preventDefault();sendAns()}}}
async function sendAns(){const el=document.getElementById('ans');
 const v=el.value.trim();if(!v)return;
 OB.qs[OB.qs.length-1].u=v;OB.idx++;
 document.getElementById('sb').disabled=true;el.disabled=true;
 const r=await J('/api/onboarding/answer',{method:'POST',headers:
 {'Content-Type':'application/json'},body:JSON.stringify({answer:v})});
 if(r.done){ST.onboarded=true;ST.profile=r.profile;return scrProfile(true)}
 OB.qs.push({a:r.question});renderOnb()}

function scrProfile(fresh){setNav();const p=ST.profile||{};
 const ppl=Object.entries(p.people||{}).map(([k,v])=>
 `<div><b>${esc(k)}</b><span>${esc(v)}</span></div>`).join('');
 app.innerHTML=`<div class=lab>${fresh?"You're set up":'Your profile'}</div>
 <h1>${fresh?'Good to meet you':'Hello'}${p.name?', '+esc(p.name.split(' ')[0]):''}.</h1>
 <p class=sub>Anticipy now knows who you are and what matters, stored
 locally, used to resolve who and what you mean.</p>
 <div class=kv><div><b>Role</b><span>${esc(p.role_title||'-')}</span></div>
 <div><b>What you do</b><span>${esc(p.what_they_do||'-')}</span></div>
 <div><b>Mandate</b><span>${esc(p.mandate||'-')}</span></div>
 ${p.do_not_touch&&p.do_not_touch.length?`<div><b>Do not touch</b>
 <span>${esc(p.do_not_touch.join(', '))}</span></div>`:''}${ppl}</div>
 <button class=cta onclick="go('mic')">Continue</button>`}

function scrMic(){stopPoll();setNav('listen');
 app.innerHTML=`<div class="scr center"><div class=lab>Microphone</div>
 <h1>Let Anticipy hear you.</h1>
 <p class=sub>Anticipy listens continuously to your real microphone, on
 this Mac, while it is open. macOS will ask for permission now.</p>
 <div id=ms style="margin-top:30px"></div>
 <button class=cta id=mb style="align-self:center"
 onclick=probeMic()>Enable microphone</button></div>`}
async function probeMic(){const b=document.getElementById('mb'),
 s=document.getElementById('ms');b.disabled=true;
 b.innerHTML='<span class=spin></span>';
 try{if(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia){
 const ms=await Promise.race([
 navigator.mediaDevices.getUserMedia({audio:true}),
 new Promise((_,rej)=>setTimeout(()=>rej(new Error('webview microphone prompt timed out')),3500))
 ]);
 ms.getTracks().forEach(t=>t.stop())}}catch(e){b.disabled=false;
 if(!String(e.message||'').includes('timed out')){
 b.textContent='Try again';
 s.innerHTML=`<p class=sub style="margin:0 auto;color:var(--warn)">
 ${esc(e.message||'Microphone permission was not granted')}. Grant
 Anticipy microphone access and try again.</p>`;return}}
 const r=await J('/api/mic/probe');b.disabled=false;
 if(r.ok){b.style.display='none';
 s.innerHTML=`<div class=pill><span class="dot g"></span>
 ${esc(r.device||'microphone')} ready</div>
 <p class=sub style="margin:18px auto 0">Captured a real test sample
 (level ${r.rms.toFixed(4)}). Starting continuous listening.</p>`;
 setTimeout(()=>go('listen'),1100)}
 else{b.textContent='Try again';
 s.innerHTML=`<p class=sub style="margin:0 auto;color:var(--warn)">
 ${esc(r.error||'Microphone unavailable')}. Grant Anticipy microphone
 access in System Settings, Privacy, Microphone.</p>`}}

async function scrListen(){setNav('listen');
 const s=await J('/api/listen/start',{method:'POST'});
 app.innerHTML=`<div class="scr center"><div class=lab>Listening</div>
 <div class="orb on" id=orb><div class=ring></div><i></i></div>
 <div class=live id=lv><span class=bd></span><span>Listening
 continuously</span></div>
 <div class=meter><i id=mtr></i></div>
 <div class=stat id=stt></div>
	 <p class=sub style="margin:18px auto 0">Anticipy is always listening
	 in rolling ${Math.round(s.window_seconds||60)}s windows. Speak
	 naturally; it surfaces one clear thing when it hears something
	 worth acting on. Nothing synthetic.</p>
	 <div class=row style="margin-top:18px">
	 <label class=ghost style="cursor:pointer">Upload audio
	 <input type=file accept="audio/*,.mp3,.wav,.m4a,.aiff"
	 style="display:none" onchange="uploadAudioFile(this)"></label></div>
	 <div id=prop></div>
	 <div class=feed id=feed></div>
 <button class=ghost style="align-self:center;margin-top:24px"
 onclick=stopListen()>Stop listening</button></div>`;
	 if(s.error){document.getElementById('lv').innerHTML=
	 `<span class=err>Microphone: ${esc(s.error)}</span>`}
	 stopPoll();POLL=setInterval(pollListen,1500);pollListen()}
async function uploadAudioFile(input){const file=input&&input.files&&input.files[0];
 if(!file)return;const pr=document.getElementById('prop');
 if(pr)pr.innerHTML='<div class=card><div class=lab>Uploading audio</div>'+
 '<h2><span class=spin></span> Transcribing on this Mac</h2></div>';
 try{const r=await fetch('/api/listen/upload',{method:'POST',body:file,
 headers:{'Content-Type':file.type||'application/octet-stream'}});
 const data=await r.json();if(!r.ok||data.error)throw new Error(data.error||r.status);
 await pollListen()}catch(e){if(pr)pr.innerHTML=`<div class=card>
 <div class=lab>Upload failed</div><h2>${esc(String(e.message||e))}</h2>
 </div>`}finally{input.value=''}}
async function pollListen(){let st;try{st=await J('/api/listen/status')}
 catch(e){return}
 const orb=document.getElementById('orb');if(!orb)return stopPoll();
 const lvl=Math.min(100,Math.round((st.level||0)*4000));
 const mtr=document.getElementById('mtr');if(mtr)mtr.style.width=lvl+'%';
 const stt=document.getElementById('stt');
 if(stt)stt.innerHTML=`<span><b>${st.windows||0}</b> windows</span>
 <span><b>${Math.round(st.uptime||0)}</b>s on</span>
 <span><b>${(st.level||0).toFixed(4)}</b> level</span>`;
 const lv=document.getElementById('lv');
 if(lv&&!st.on)lv.innerHTML=`<span class=err>Listening stopped${
 st.error?': '+esc(st.error):''}</span>`;
 const pr=document.getElementById('prop');
	 if(pr){if(st.pending&&(st.pending.competent_decline||st.pending.decline)){pr.innerHTML=`<div class=card>
	 <div class=lab>Cannot safely act</div>
	 <h2>${esc(st.pending.proposal)}</h2>
	 <div class=meta>Cannot safely act. From: "${esc(st.pending.instruction)}".
	 No browser action, publish, or send will run.</div>
	 <div class=row style="margin-top:18px">
	 <button class=ghost onclick=dismiss()>Dismiss</button></div></div>`}
	 else if(st.pending&&st.pending.clarify){pr.innerHTML=`<div class=card>
	 <div class=lab>Need one detail</div>
	 <h2>${esc(st.pending.proposal)}</h2>
	 <div class=meta>From: "${esc(st.pending.instruction)}". Anticipy will not
	 act until this is resolved.</div>
	 <div class=row style="margin-top:18px">
	 <button class=ghost onclick=dismiss()>Dismiss</button></div></div>`}
	 else if(st.pending){pr.innerHTML=`<div class=card>
	 <div class=lab>Heard, worth acting on</div>
	 <h2>${esc(st.pending.proposal)}</h2>
	 <div class=meta>From: "${esc(st.pending.instruction)}"</div>
	 <div class=row style="margin-top:18px">
	 <button class=send id=yes onclick='doAct()'>Yes, do it</button>
	 <button class=ghost onclick=dismiss()>Dismiss</button></div>
	 <div id=act></div></div>`}
 else if(st.acted){pr.innerHTML=`<div class=card>
 <div class=lab><span class=dot></span> Done in Chrome</div>
 <h2>${esc(st.acted.instruction)}</h2>
 <div class=meta>Status ${esc(st.acted.status)}. Still listening.
 </div></div>`}
 else if(!pr.querySelector('.spin'))pr.innerHTML=''}
 const fd=document.getElementById('feed');
 if(fd&&st.recent){fd.innerHTML=st.recent.map(w=>`<div class=w>
 <span class=t>${w.transcript?esc(w.transcript):'<span style=color:var(--mut)>(quiet window)</span>'}</span>
 <span class=m>w${w.window} &middot; ${(w.rms||0).toFixed(3)}${
 w.memory?' &middot; mem '+esc(w.memory.op||''):''}</span></div>`).join('')}}
async function doAct(){const y=document.getElementById('yes'),
 ac=document.getElementById('act');if(!y)return;y.disabled=true;
 y.innerHTML='<span class=spin></span> Acting in Chrome';
 ac.innerHTML=`<div class=meta style="margin-top:14px">Anticipy is
 driving a real Chrome window. This can take a minute. It keeps
 listening while it works.</div>`;
 const r=await J('/api/act',{method:'POST',headers:{'Content-Type':
 'application/json'},body:JSON.stringify({})});
 if(r.ran){ac.innerHTML=`<div class=meta style="margin-top:14px">
 <span class=dot></span> ${esc(r.answer||r.status)}<br>
 ${esc(r.evidence||'')}</div>`}
	 else{ac.innerHTML=`<div class="meta err" style="margin-top:14px">
	 ${esc(r.question||r.error||('status '+(r.status||'?')))}</div>`}}
async function dismiss(){await J('/api/listen/dismiss',{method:'POST'});
 pollListen()}
async function stopListen(){stopPoll();
 await J('/api/listen/stop',{method:'POST'});
 const lv=document.getElementById('lv');
 if(lv)lv.innerHTML='<span style=color:var(--mut)>Listening paused. '
 +'<a style=color:var(--gold);cursor:pointer onclick="go(\'listen\')">'
 +'Resume</a></span>';
 const orb=document.getElementById('orb');if(orb)orb.classList.remove('on')}

async function resetSetup(){stopPoll();
 if(!confirm('Reset setup and start over on this Mac?'))return;
 await J('/api/reset',{method:'POST'});
 ST=await J('/api/state');OB={qs:[]};scrWelcome()}

async function scrHistory(){stopPoll();setNav('history');
 app.innerHTML=`<div class=lab>Memory</div><h1>What Anticipy remembers.</h1>
 <p class=sub>Everything it has heard worth keeping, on this Mac. This is
 what lets it resolve who and what you mean over time.</p>
 <div id=hl><div class=meta style="margin-top:24px">
 <span class=spin></span> Loading</div></div>`;
 const r=await J('/api/memory');const hl=document.getElementById('hl');
 if(!r.entries||!r.entries.length){hl.innerHTML=`<div class=empty>
 Nothing remembered yet. What you say while it listens shows up here.
 </div>`;return}
 hl.innerHTML='<div class=hist>'+r.entries.map(e=>
 `<div class=it><div class=k>${esc(e.kind||'note')}</div>
 ${esc(e.value||'')}</div>`).join('')+'</div>'}

function scrSettings(){stopPoll();setNav('settings');const p=ST.profile||{};
 app.innerHTML=`<div class=lab>Settings</div><h1>Your setup.</h1>
 <div class=kv style="margin-top:24px">
 <div><b>Name</b><span>${esc(p.name||'not set')}</span></div>
 <div><b>Reasoning</b><span>${ST.key_ok?'Connected, OpenRouter cloud':
 'Key missing'}</span></div>
 <div><b>Microphone</b><span>Continuous, rolling ${Math.round(
 ST.window_seconds||60)}s windows while the app is open</span></div>
 <div><b>Memory</b><span>Stored locally on this Mac, per user</span></div>
 <div><b>Browser actions</b><span>Run in a real Chrome window on your
 explicit confirmation</span></div></div>
 <div class=row style="margin-top:30px">
 <button class=ghost onclick="go('mic')">Re-check microphone</button>
 <button class=ghost onclick="resetSetup()">Reset setup</button></div>`}

function go(s){window.scrollTo(0,0);
 if(s!='listen')stopPoll();
 if(s=='listen')scrListen();
 else if(s=='mic')scrMic();
 else if(s=='history')scrHistory();
 else if(s=='settings')scrSettings();
 else if(s=='profile')scrProfile(false);
 else boot()}
boot();
</script></body></html>"""


@app.get("/", response_class=HTMLResponse)
def index() -> HTMLResponse:
    return HTMLResponse(INDEX)


# ─────────────────────────────────────────────────────────────────────
# Flash log endpoint (appended by /flash builder).
# Receives stub firmware-update records from the /flash page on
# www.anticipy.ai, forwarded via /api/flash/log_stub on Next.js, and
# appends them as JSON-Lines under data_dir() / "flash_stubs.jsonl".
# Every appended row is forced to is_stub: true on this side too; the
# stub label can never be stripped by the client.
# ─────────────────────────────────────────────────────────────────────
def _flash_log_path() -> Path:
    from app.anticipy import platform_adapter
    return platform_adapter.data_dir() / "flash_stubs.jsonl"


def _coerce_flash_row(raw: dict) -> dict:
    def _s(v, default=""):
        if v is None:
            return None
        return str(v)

    def _i(v, default=0):
        try:
            return int(v)
        except Exception:
            return default

    def _b(v) -> bool:
        if isinstance(v, bool):
            return v
        if isinstance(v, str):
            return v.strip().lower() in {"1", "true", "yes"}
        return bool(v)

    import datetime as _dt
    row = {
        "ts": _s(raw.get("ts")) or _dt.datetime.utcnow().isoformat(
            timespec="seconds") + "Z",
        "device_name": _s(raw.get("device_name")) or "unknown",
        "device_id_redacted": _s(raw.get("device_id_redacted")) or "unknown",
        "firmware_version_before": _s(raw.get("firmware_version_before")),
        "firmware_version_after": _s(raw.get("firmware_version_after")),
        "bytes_transferred": _i(raw.get("bytes_transferred")),
        "duration_ms": _i(raw.get("duration_ms")),
        "success": _b(raw.get("success")),
        "error": _s(raw.get("error")),
        # Stub label is forced server-side. Never let a stub look real.
        "is_stub": True,
    }
    return row


# ─────────────────────────────────────────────────────────────────────
# Audio input device enumeration (Settings -> Audio source dropdown).
# Returns every CoreAudio input device sounddevice can see, including
# the built-in mic and any system-paired Bluetooth audio input. The
# response is structured so the brand UI never has to surface raw
# device-index integers; the kind field tells the renderer how to
# group entries (builtin / bluetooth / other).
# ─────────────────────────────────────────────────────────────────────
@app.get("/api/audio/devices")
def api_audio_devices() -> JSONResponse:
    try:
        import sounddevice as sd
    except Exception as exc:
        return JSONResponse(
            {"ok": False, "error": f"sounddevice unavailable: {exc}",
             "devices": []},
            status_code=500,
        )
    try:
        raw = sd.query_devices()
    except Exception as exc:
        return JSONResponse(
            {"ok": False, "error": f"query_devices failed: {exc}",
             "devices": []},
            status_code=500,
        )
    try:
        default_in = sd.query_devices(kind="input")
        default_name = str(default_in.get("name", "")) if isinstance(
            default_in, dict) else ""
    except Exception:
        default_name = ""

    devices = []
    for idx, d in enumerate(raw):
        if not isinstance(d, dict):
            continue
        if int(d.get("max_input_channels") or 0) <= 0:
            continue
        devices.append(_audio_device_row(idx, d, default_name))
    return JSONResponse({
        "ok": True,
        "count": len(devices),
        "default_input": default_name,
        "devices": devices,
    })


@app.post("/api/flash/log")
async def api_flash_log(request: Request) -> JSONResponse:
    try:
        payload = await request.json()
    except Exception as exc:
        return JSONResponse(
            {"ok": False, "error": f"body must be JSON: {exc}"}, status_code=400
        )
    if not isinstance(payload, dict):
        return JSONResponse(
            {"ok": False, "error": "body must be a JSON object"},
            status_code=400,
        )
    row = _coerce_flash_row(payload)
    try:
        path = _flash_log_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(row, ensure_ascii=False)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
        return JSONResponse({"ok": True, "appended_to": str(path), "row": row})
    except Exception as exc:
        return JSONResponse(
            {"ok": False, "error": f"could not append flash row: {exc}"},
            status_code=500,
        )


# ─────────────────────────────────────────────────────────────────────
# Dossier call layer (US-022). Mock plays through Mac speakers via
# afplay; the webhook shape matches Twilio so a future production
# activation is a single env var flip (MOCK_MODE=false plus the three
# TWILIO_* env vars). Nothing else in the codebase branches on mode.
# ─────────────────────────────────────────────────────────────────────
@app.post("/api/dossier/outbound")
async def api_dossier_outbound(request: Request) -> JSONResponse:
    try:
        payload = await request.json()
    except Exception as exc:
        return JSONResponse(
            {"ok": False, "error": f"body must be JSON: {exc}"},
            status_code=400,
        )
    if not isinstance(payload, dict):
        return JSONResponse(
            {"ok": False, "error": "body must be a JSON object"},
            status_code=400,
        )
    from app.dossier import call as dossier_call
    result = dossier_call.handle_outbound(payload)
    status = 200 if result.get("ok") else 400
    return JSONResponse(result, status_code=status)


@app.post("/api/dossier/inbound")
async def api_dossier_inbound(request: Request) -> Response:
    """Twilio inbound webhook. Form-encoded body in, TwiML XML out.

    The route accepts JSON too so the test harness and the dev browser
    can drive it without simulating Twilio's form encoding.
    """
    content_type = request.headers.get("content-type", "")
    form: dict = {}
    if "application/json" in content_type:
        try:
            body = await request.json()
            if isinstance(body, dict):
                form = body
        except Exception:
            form = {}
    else:
        try:
            raw = await request.form()
            form = dict(raw)
        except Exception:
            try:
                raw_bytes = await request.body()
                form = dict(urllib.parse.parse_qsl(raw_bytes.decode("utf-8", "ignore")))
            except Exception:
                form = {}
    from app.dossier import call as dossier_call
    twiml = dossier_call.handle_inbound(form)
    return Response(twiml, media_type="application/xml")


@app.get("/api/dossier/events")
def api_dossier_events() -> JSONResponse:
    """Observability endpoint: returns the most recent in-process events.
    The popover reads this to render the Dossier section. Production
    points the same route at Supabase via select_rows; the shape is
    identical, so no UI changes are needed for the swap.
    """
    from app.dossier import call as dossier_call
    return JSONResponse({
        "ok": True,
        "events": dossier_call.recent_events(50),
        "dossier_writes": dossier_call.recent_dossier_writes(10),
        "mock_mode": dossier_call.mock_mode(),
    })


# ─────────────────────────────────────────────────────────────────────
# Durable per user dossier key/value store. Persists to disk under the
# per user partition so facts survive engine process restart (audit
# A-004). The shape is the contract the engine and the verifier share.
# ─────────────────────────────────────────────────────────────────────
@app.post("/api/dossier/write")
async def api_dossier_write(request: Request) -> JSONResponse:
    try:
        payload = await request.json()
    except Exception as exc:
        return JSONResponse(
            {"ok": False, "error": f"body must be JSON: {exc}"}, status_code=400
        )
    if not isinstance(payload, dict):
        return JSONResponse(
            {"ok": False, "error": "body must be a JSON object"}, status_code=400
        )
    user_id = str(payload.get("user_id") or "").strip()
    key = str(payload.get("key") or "").strip()
    if not user_id or not key:
        return JSONResponse(
            {"ok": False, "error": "user_id and key are required"},
            status_code=400,
        )
    value = payload.get("value")
    from app.anticipy import dossier_store
    try:
        row = dossier_store.write(user_id, key, value)
    except Exception as exc:
        return JSONResponse(
            {"ok": False, "error": f"write failed: {exc}"}, status_code=500
        )
    return JSONResponse({"ok": True, "user_id": user_id, "row": row})


@app.get("/api/dossier")
def api_dossier_read(user_id: str, key: str | None = None) -> JSONResponse:
    from app.anticipy import dossier_store
    if not user_id:
        return JSONResponse(
            {"ok": False, "error": "user_id query param required"},
            status_code=400,
        )
    if key:
        row = dossier_store.read(user_id, key)
        if row is None:
            return JSONResponse({
                "ok": True,
                "user_id": user_id,
                "key": key,
                "row": None,
            })
        return JSONResponse({
            "ok": True,
            "user_id": user_id,
            "key": key,
            "row": row,
            "value": row.get("value"),
        })
    data = dossier_store.read_all(user_id)
    return JSONResponse({"ok": True, "user_id": user_id, "rows": data})


@app.post("/api/test/reset_runtime")
def api_test_reset_runtime() -> JSONResponse:
    """Soft restart hook for the verifier.

    The audit's A-004 spawns a fresh engine when it can, but when an
    engine is already running it cannot kill it. Instead it pokes this
    endpoint to simulate a runtime restart. Because dossier facts are
    persisted to disk, no rehydration step is needed: a subsequent
    GET /api/dossier reads from the same files regardless of in process
    caches. We still clear the in process session and listen caches so
    the simulated restart actually resets transient state.
    """
    try:
        _SESS["i"] = 0
        _SESS["transcript"] = []
    except Exception:
        pass
    return JSONResponse({"ok": True, "reset": True})


def _pick_free_port() -> int:
    import socket as _sock
    s = _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])
    finally:
        s.close()


def _write_port_file(port: int) -> Path:
    port_dir = Path.home() / ".anticipy"
    port_dir.mkdir(parents=True, exist_ok=True)
    port_path = port_dir / "engine.port"
    port_path.write_text(str(port), encoding="utf-8")
    return port_path


def _run_sidecar() -> None:
    """Entry used by the PyInstaller-bundled binary (US-013).

    Always binds to a random localhost port (port 0) so the desktop
    sidecar never collides with a running dev engine on 8731. Writes
    the resolved port to ~/.anticipy/engine.port so the Tauri app can
    discover it. Honors ANTICIPY_PORT only when explicitly set and
    not equal to 8731 (8731 is reserved for the dev engine).
    """
    import uvicorn

    raw = os.environ.get("ANTICIPY_PORT", "").strip()
    requested = 0
    if raw:
        try:
            requested = int(raw)
        except ValueError:
            requested = 0
    if requested <= 0:
        port = _pick_free_port()
    else:
        port = requested

    os.environ["ANTICIPY_PORT"] = str(port)
    _acquire_singleton_lock(str(port))
    port_path = _write_port_file(port)
    sys.stdout.write(
        f"anticipy-engine listening on 127.0.0.1:{port} "
        f"(port file: {port_path})\n"
    )
    sys.stdout.flush()
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


if __name__ == "__main__":
    _run_sidecar()
