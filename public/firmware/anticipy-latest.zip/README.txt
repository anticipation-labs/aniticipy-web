Anticipy Placeholder Firmware
version 0.0.0-stub
is_stub: true
This is a development build. Real firmware will replace this placeholder.
